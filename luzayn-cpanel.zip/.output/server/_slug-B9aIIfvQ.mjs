import { o as __toESM } from "./_runtime.mjs";
import { i as SITE, r as CLAIM_DISCLAIMER, t as CDN_PATHS } from "./_ssr/cms-Bdb4agUA.mjs";
import { B as require_react, _ as Link, v as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { D as ArrowRight, a as ShieldCheck, b as CircleAlert, d as Minus, n as Truck, s as Plus, u as Package, w as Check } from "./_libs/lucide-react.mjs";
import { _ as mediaUrl, g as formatPrice, h as cn, m as useCatalog, r as Route$1 } from "./_ssr/router-dqPFFXFI.mjs";
import { a as SectionTitle, r as KickerRuled, t as Disclaimer } from "./_ssr/typography-YgNHFb6n.mjs";
import { t as AddToCart } from "./_ssr/add-to-cart-CNuvZoGo.mjs";
import { t as useIsMobile } from "./_ssr/use-is-mobile-BjC0fk4G.mjs";
import { t as useShopifyCheckout } from "./_ssr/use-shopify-checkout-DeH8SGWB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-B9aIIfvQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Fotoğraf + video slaytları; scroll-snap, dot göstergesi, kod rozeti. */
function ProductGallery({ product }) {
	const isMobile = useIsMobile();
	const railRef = (0, import_react.useRef)(null);
	const [active, setActive] = (0, import_react.useState)(0);
	const slides = [
		{
			kind: "image",
			src: CDN_PATHS.cover(product.slug)
		},
		{
			kind: "video",
			src: isMobile ? CDN_PATHS.videoMobile(product.slug) : CDN_PATHS.videoDesktop(product.slug)
		},
		{
			kind: "image",
			src: CDN_PATHS.image(product.slug)
		}
	];
	(0, import_react.useEffect)(() => {
		const rail = railRef.current;
		if (!rail) return;
		let frame = 0;
		const onScroll = () => {
			cancelAnimationFrame(frame);
			frame = requestAnimationFrame(() => {
				setActive(Math.round(rail.scrollLeft / rail.clientWidth));
			});
		};
		rail.addEventListener("scroll", onScroll, { passive: true });
		return () => {
			rail.removeEventListener("scroll", onScroll);
			cancelAnimationFrame(frame);
		};
	}, []);
	const goTo = (i) => {
		const rail = railRef.current;
		if (!rail) return;
		rail.scrollTo({
			left: i * rail.clientWidth,
			behavior: "smooth"
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: railRef,
				className: "no-scrollbar flex snap-x snap-mandatory overflow-x-auto rounded-3xl border",
				style: { borderColor: `${product.accent}30` },
				children: slides.map((slide, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "aspect-[4/5] w-full shrink-0 snap-start bg-[#0a0a12]",
					children: slide.kind === "image" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: mediaUrl(slide.src),
						alt: `${product.name} — görsel ${i + 1}`,
						loading: i === 0 ? "eager" : "lazy",
						className: "h-full w-full object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						src: mediaUrl(slide.src),
						muted: true,
						loop: true,
						playsInline: true,
						autoPlay: true,
						preload: "none",
						className: "h-full w-full object-cover"
					})
				}, `${slide.kind}-${slide.src}`))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute left-4 top-4 rounded-full px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] backdrop-blur-md",
				style: {
					backgroundColor: `${product.accent}1f`,
					color: product.accent,
					border: `1px solid ${product.accent}30`
				},
				children: product.slug
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex items-center justify-center gap-2",
				children: slides.map((slide, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => goTo(i),
					"aria-label": `${i + 1}. görsel`,
					"aria-current": i === active,
					className: cn("h-1.5 rounded-full transition-all", i === active ? "w-8" : "w-3 bg-border hover:bg-muted-foreground/40"),
					style: i === active ? { backgroundColor: product.accent } : void 0
				}, `dot-${slide.kind}-${slide.src}`))
			})
		]
	});
}
function ProductPage() {
	const { product } = Route$1.useLoaderData();
	const [qty, setQty] = (0, import_react.useState)(1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopSection, {
			product,
			qty,
			setQty
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompositionSection, { product }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoAccordion, { product }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HighlightsSection, { product }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CrossSell, { current: product }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickyBuyBar, {
			product,
			qty
		})
	] });
}
function TopSection({ product, qty, setQty }) {
	const { commerce } = useCatalog();
	const { checkout, pending, error } = useShopifyCheckout();
	const buyNow = () => void checkout([{
		slug: product.slug,
		qty
	}]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-background pb-16 pt-10 md:pb-20 md:pt-14",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container mx-auto px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "mb-8 flex items-center gap-2 text-sm text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "hover:text-foreground",
						children: "Ana Sayfa"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						children: "/"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/urunler",
						className: "hover:text-foreground",
						children: "Ürünler"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						children: "/"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-foreground",
						children: product.shortName
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-10 lg:grid-cols-2 lg:gap-14",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGallery, { product }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-3xl font-bold leading-tight tracking-tight text-foreground md:text-4xl",
						children: product.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-base font-medium",
						style: { color: product.accent },
						children: product.subtitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-base leading-relaxed text-muted-foreground",
						children: product.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-7 flex flex-wrap gap-1.5",
						children: product.keyIngredients.map((ing) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full border px-3 py-1.5 text-xs font-medium",
							style: {
								borderColor: `${product.accent}30`,
								backgroundColor: `${product.accent}0c`,
								color: product.accent
							},
							children: ing
						}, ing))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap items-end gap-x-6 gap-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-4xl font-bold text-foreground",
							children: formatPrice(product.price)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "pb-1.5 text-sm text-muted-foreground",
							children: [
								product.unit,
								" · ",
								product.form
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QtyPicker, {
								qty,
								setQty,
								accent: product.accent
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: buyNow,
								disabled: pending,
								className: "inline-flex flex-1 items-center justify-center gap-2 rounded-full px-7 py-3.5 text-sm font-semibold text-white shadow-lg transition-transform hover:scale-[1.02] disabled:opacity-50 sm:flex-none",
								style: {
									backgroundImage: `linear-gradient(120deg, ${product.accent}, ${product.accent}bb)`,
									boxShadow: `0 14px 38px -16px ${product.accent}`
								},
								children: [pending ? "Yönlendiriliyor…" : "Hemen Satın Al", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddToCart, {
								product,
								qty,
								variant: "ghost",
								className: "flex-1 sm:flex-none"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrustBadge, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "h-4 w-4" }),
								title: "Aynı gün kargo",
								detail: "15:00'e kadar verilen siparişlerde"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrustBadge, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-4 w-4" }),
								title: "GMP & HACCP",
								detail: `Menşei: ${SITE.origin}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrustBadge, {
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "h-4 w-4" }),
								title: `${commerce.returnDays} gün iade`,
								detail: "Ambalajı açılmamış ürünlerde"
							})
						]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						role: "alert",
						className: "mt-6 flex items-start gap-3 rounded-2xl border border-red-200 bg-red-50 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "mt-0.5 h-4 w-4 shrink-0 text-red-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed text-red-800",
							children: error
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Disclaimer, {
						className: "mt-7",
						children: CLAIM_DISCLAIMER
					})
				] })]
			})]
		})
	});
}
function QtyPicker({ qty, setQty, accent }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "inline-flex items-center rounded-full border",
		style: { borderColor: `${accent}30` },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setQty(Math.max(1, qty - 1)),
				"aria-label": "Adet azalt",
				disabled: qty <= 1,
				className: "inline-flex h-12 w-12 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-muted disabled:opacity-40",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "h-4 w-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-8 text-center text-sm font-semibold tabular-nums text-foreground",
				children: qty
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setQty(Math.min(20, qty + 1)),
				"aria-label": "Adet artır",
				disabled: qty >= 20,
				className: "inline-flex h-12 w-12 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-muted disabled:opacity-40",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" })
			})
		]
	});
}
function TrustBadge({ icon, title, detail }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-border bg-card px-4 py-3.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-accent",
				children: icon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs font-semibold text-foreground",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-[11px] leading-snug text-muted-foreground",
				children: detail
			})
		]
	});
}
/**
* İçerik bilgisi tablosu + ürün özellikleri.
* Miktarlar etiketten birebir alınır; %BRD yalnızca etikette verilmişse
* gösterilir — hesaplanıp uydurulmaz.
*/
function CompositionSection({ product }) {
	const hasNrv = product.composition.some((row) => row.nrv);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-background pb-16 md:pb-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "container mx-auto px-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-start gap-8 lg:grid-cols-2 lg:gap-14",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-bold tracking-tight text-foreground md:text-2xl",
						children: "İçerik Bilgisi"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1.5 text-sm text-muted-foreground",
						children: [product.servingSize, " için"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 overflow-hidden rounded-3xl border border-border bg-card",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border bg-muted/50",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-5 py-3 text-left text-[11px] font-semibold uppercase tracking-wider text-muted-foreground",
										children: "Bileşen"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-5 py-3 text-right text-[11px] font-semibold uppercase tracking-wider text-muted-foreground",
										children: "Miktar"
									}),
									hasNrv ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-5 py-3 text-right text-[11px] font-semibold uppercase tracking-wider text-muted-foreground",
										children: "%BRD"
									}) : null
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
								className: "divide-y divide-border",
								children: product.composition.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-3 text-foreground",
										children: row.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-3 text-right font-semibold tabular-nums text-foreground",
										children: row.amount
									}),
									hasNrv ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-3 text-right tabular-nums text-muted-foreground",
										children: row.nrv ?? "–"
									}) : null
								] }, row.name))
							})]
						})
					}),
					hasNrv ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-muted-foreground/70",
						children: "BRD: Beslenme Referans Değeri"
					}) : null
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-bold tracking-tight text-foreground md:text-2xl",
						children: "Ürün Özellikleri"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1.5 text-sm text-muted-foreground",
						children: [
							product.unit,
							" · ",
							product.form
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-5 space-y-3",
						children: product.features.map((feature) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full",
								style: { backgroundColor: product.accent }
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm leading-relaxed text-muted-foreground",
								children: feature
							})]
						}, feature))
					})
				] })]
			})
		})
	});
}
function InfoAccordion({ product }) {
	const rows = [
		{
			title: "Kullanım",
			body: product.usage
		},
		{
			title: "Saklama koşulları",
			body: product.storage
		},
		{
			title: "Beyan dayanağı",
			body: product.claimBasis.length > 0 ? `Bu üründeki sağlık beyanları şu besin ögelerine aittir: ${product.claimBasis.join(", ")}. Formüldeki diğer bileşenler yalnızca bileşim olarak tanımlanır.` : "Bu üründe yer alan bileşenler için yetkilendirilmiş bir sağlık beyanı bulunmamaktadır; bileşenler yalnızca bileşim olarak tanımlanır."
		},
		{
			title: "Uyarılar",
			body: "Tavsiye edilen günlük porsiyonu aşmayınız. Takviye edici gıdalar normal beslenmenin yerine geçmez. Hamilelik ve emzirme döneminde, ilaç kullanıyorsanız veya kronik bir rahatsızlığınız varsa hekiminize danışınız. 4 yaş altı çocuklarda hekim önerisi olmadan kullanmayınız. Bileşenlerden herhangi birine alerjiniz varsa kullanmayınız."
		},
		{
			title: "Parti ve tüketim tarihi",
			body: "Tavsiye edilen tüketim tarihi (TETT) ve parti numarası ambalaj üzerindedir."
		}
	];
	const [open, setOpen] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-y border-border bg-muted/30 py-14 md:py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container mx-auto max-w-3xl px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: mediaUrl(CDN_PATHS.image(product.slug)),
				alt: product.name,
				loading: "lazy",
				className: "mb-10 aspect-[16/9] w-full rounded-3xl object-cover",
				style: { boxShadow: `0 30px 70px -45px ${product.accent}` }
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y divide-border overflow-hidden rounded-3xl border border-border bg-card",
				children: rows.map((row, i) => {
					const isOpen = open === i;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setOpen(isOpen ? null : i),
						"aria-expanded": isOpen,
						className: "flex w-full items-center justify-between gap-4 px-6 py-5 text-left transition-colors hover:bg-muted/60 md:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-base font-semibold text-foreground",
							children: row.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
							className: `h-5 w-5 shrink-0 text-muted-foreground transition-transform duration-300 ${isOpen ? "rotate-45" : ""}`,
							style: isOpen ? { color: product.accent } : void 0
						})]
					}), isOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "animate-[showcase-fade-in_0.25s_ease-out] px-6 pb-6 text-sm leading-relaxed text-muted-foreground md:px-8",
						children: row.body
					}) : null] }, row.title);
				})
			})]
		})
	});
}
function HighlightsSection({ product }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden py-20 md:py-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: mediaUrl(CDN_PATHS.cover(product.slug)),
				alt: "",
				"aria-hidden": true,
				loading: "lazy",
				className: "absolute inset-0 h-full w-full object-cover opacity-40"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "absolute inset-0 bg-gradient-to-b from-[#0a0a12]/95 via-[#0a0a12]/85 to-[#0a0a12]/95"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container relative mx-auto px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-2xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KickerRuled, { children: "Bileşen & Dayanak" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
							dark: true,
							className: "mt-5",
							children: "Formülde ne var, hangi ifade neye ait?"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid items-start gap-4 md:grid-cols-2 lg:grid-cols-3",
						children: product.highlights.map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "animate-[showcase-rise-in_0.5s_ease-out_both] rounded-3xl border bg-white/[0.04] p-7 backdrop-blur-md",
							style: {
								borderColor: `${product.accent}30`,
								animationDelay: `${i * 100}ms`
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "inline-flex h-8 w-8 items-center justify-center rounded-full",
									style: { backgroundColor: `${product.accent}1f` },
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
										className: "h-4 w-4",
										style: { color: product.accent }
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-4 text-base font-bold text-white",
									children: h.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-white/60",
									children: h.detail
								})
							]
						}, h.title))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Disclaimer, {
						dark: true,
						className: "mt-8 max-w-3xl",
						children: CLAIM_DISCLAIMER
					})
				]
			})
		]
	});
}
function CrossSell({ current }) {
	const { products } = useCatalog();
	const others = products.filter((p) => p.slug !== current.slug).slice(0, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-background py-16 pb-28 md:py-24 md:pb-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container mx-auto px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
					className: "text-2xl md:text-3xl",
					children: "Seriden diğerleri"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/urunler",
					className: "inline-flex items-center gap-2 text-sm font-semibold text-accent hover:underline",
					children: ["Tümünü Gör", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: others.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/urunler/$slug",
					params: { slug: p.slug },
					className: "group overflow-hidden rounded-2xl border border-border bg-card transition-shadow hover:shadow-lg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: mediaUrl(CDN_PATHS.cover(p.slug)),
						alt: p.name,
						loading: "lazy",
						className: "aspect-[4/3] w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-bold text-foreground",
							children: p.shortName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-sm text-muted-foreground",
							children: formatPrice(p.price)
						})]
					})]
				}, p.slug))
			})]
		})
	});
}
/** Mobilde alta sabitlenen satın alma barı */
function StickyBuyBar({ product, qty }) {
	const { checkout, pending } = useShopifyCheckout();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-x-0 bottom-0 z-30 border-t border-border bg-white/95 px-4 py-3 backdrop-blur-md md:hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate text-xs text-muted-foreground",
						children: product.shortName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-base font-bold text-foreground",
						children: formatPrice(product.price * qty)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddToCart, {
					product,
					qty,
					variant: "ghost",
					label: "Sepete",
					className: "ml-auto shrink-0 px-4 py-3 text-xs"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: pending,
					onClick: () => void checkout([{
						slug: product.slug,
						qty
					}]),
					className: "shrink-0 rounded-full px-5 py-3 text-xs font-semibold text-white disabled:opacity-50",
					style: { backgroundColor: product.accent },
					children: pending ? "…" : "Satın Al"
				})
			]
		})
	});
}
//#endregion
export { ProductPage as component };
