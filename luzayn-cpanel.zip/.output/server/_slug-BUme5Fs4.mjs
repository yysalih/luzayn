import { l as NotFoundPage } from "./_ssr/router-dqPFFXFI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-BUme5Fs4.js
/** Tüm yasal sayfalar bu tek düzenden render edilir — açık tema, max-w-3xl. */
var SplitNotFoundComponent = NotFoundPage;
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
