import { _ as Link, v as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as Route, u as LEGAL_NAV } from "./_ssr/router-D6WmJc6q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-Bk-4X6_-.js
var import_jsx_runtime = require_jsx_runtime();
/** Tüm yasal sayfalar bu tek düzenden render edilir — açık tema, max-w-3xl. */
function LegalPage() {
	const { page } = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: "bg-background py-14 md:py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container mx-auto max-w-3xl px-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-semibold uppercase tracking-[0.35em] text-accent",
					children: "Yasal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-5 text-3xl font-bold leading-tight tracking-tight text-foreground md:text-4xl",
					children: page.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-base leading-relaxed text-muted-foreground",
					children: page.intro
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 space-y-10",
					children: page.sections.map((section, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-lg font-bold tracking-tight text-foreground md:text-xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mr-2 tabular-nums text-accent",
							children: String(i + 1).padStart(2, "0")
						}), section.heading]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 space-y-2.5",
						children: section.body.map((line, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed text-muted-foreground",
							children: line
						}, j))
					})] }, section.heading))
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-t border-border bg-muted/30 py-12",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container mx-auto max-w-3xl px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-semibold uppercase tracking-wider text-muted-foreground",
				children: "Diğer Yasal Sayfalar"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: LEGAL_NAV.filter((p) => p.slug !== page.slug).map((other) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/yasal/$slug",
					params: { slug: other.slug },
					className: "rounded-full border border-border bg-card px-4 py-2 text-sm text-foreground transition-colors hover:bg-muted",
					children: other.title
				}, other.slug))
			})]
		})
	})] });
}
//#endregion
export { LegalPage as component };
