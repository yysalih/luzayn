import { r as CLAIM_DISCLAIMER } from "./_ssr/cms-CSbzslKe.mjs";
import { _ as Link, v as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { O as ArrowLeft } from "./_libs/lucide-react.mjs";
import { i as Route$4, y as mediaUrl } from "./_ssr/router-D6WmJc6q.mjs";
import { t as Disclaimer } from "./_ssr/typography-1iJfy8Yl.mjs";
import { t as formatBlogDate } from "./_ssr/content-Z140g0m_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-C0r0CB31.js
var import_jsx_runtime = require_jsx_runtime();
function BlogPostPage() {
	const { post, all } = Route$4.useLoaderData();
	const others = all.filter((p) => p.slug !== post.slug).slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: "bg-background py-14 md:py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container mx-auto max-w-3xl px-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/blog",
					className: "inline-flex items-center gap-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), "Tüm yazılar"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-8 inline-block rounded-full px-3 py-1 text-[11px] font-medium uppercase tracking-wider",
					style: {
						backgroundColor: `${post.categoryAccent}1f`,
						color: post.categoryAccent
					},
					children: post.category
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-5 text-3xl font-bold leading-[1.15] tracking-tight text-foreground md:text-5xl",
					children: post.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-sm text-muted-foreground",
					children: [
						formatBlogDate(post.date),
						" · ",
						post.readingMinutes,
						" dk okuma"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: mediaUrl(post.cover),
					alt: "",
					"aria-hidden": true,
					className: "mt-9 aspect-[16/10] w-full rounded-3xl object-cover",
					style: { boxShadow: `0 30px 70px -40px ${post.categoryAccent}` }
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-10 text-lg leading-relaxed text-foreground/80",
					children: post.excerpt
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 space-y-10",
					children: post.sections.map((section) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-bold tracking-tight text-foreground md:text-2xl",
						children: section.heading
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 space-y-4",
						children: section.body.map((paragraph, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-base leading-relaxed text-muted-foreground",
							children: paragraph
						}, i))
					})] }, section.heading))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Disclaimer, {
					className: "mt-12 rounded-2xl border border-border bg-muted/40 p-5",
					children: CLAIM_DISCLAIMER
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-t border-border bg-muted/30 py-16 md:py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container mx-auto px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl font-bold tracking-tight text-foreground",
				children: "Diğer Yazılar"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid items-start gap-8 md:grid-cols-3 md:gap-6",
				children: others.map((other) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/blog/$slug",
					params: { slug: other.slug },
					className: "group block",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: mediaUrl(other.cover),
							alt: "",
							"aria-hidden": true,
							loading: "lazy",
							className: "aspect-[4/3] w-full rounded-xl object-cover transition-transform duration-300 group-hover:scale-[1.02]"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-4 block text-[11px] font-semibold uppercase tracking-[0.18em]",
							style: { color: other.categoryAccent },
							children: other.category
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-1.5 text-base font-bold leading-snug tracking-tight text-foreground",
							children: other.title
						})
					]
				}, other.slug))
			})]
		})
	})] });
}
//#endregion
export { BlogPostPage as component };
