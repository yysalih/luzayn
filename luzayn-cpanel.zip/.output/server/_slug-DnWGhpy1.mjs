import { l as NotFoundPage } from "./_ssr/router-D6WmJc6q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-DnWGhpy1.js
/** Tüm yasal sayfalar bu tek düzenden render edilir — açık tema, max-w-3xl. */
var SplitNotFoundComponent = NotFoundPage;
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
