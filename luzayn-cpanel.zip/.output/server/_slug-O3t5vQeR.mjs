import { l as NotFoundPage } from "./_ssr/router-D6WmJc6q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-O3t5vQeR.js
var SplitNotFoundComponent = NotFoundPage;
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
