import { l as NotFoundPage } from "./_ssr/router-dqPFFXFI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-XnqTcN9u.js
var SplitNotFoundComponent = NotFoundPage;
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
