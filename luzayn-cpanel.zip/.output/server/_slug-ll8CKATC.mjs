import { l as NotFoundPage } from "./_ssr/router-D6WmJc6q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-ll8CKATC.js
/**
* İçerik bilgisi tablosu + ürün özellikleri.
* Miktarlar etiketten birebir alınır; %BRD yalnızca etikette verilmişse
* gösterilir — hesaplanıp uydurulmaz.
*/
/** Mobilde alta sabitlenen satın alma barı */
var SplitNotFoundComponent = NotFoundPage;
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
