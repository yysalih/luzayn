import { o as __toESM } from "../_runtime.mjs";
import { B as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as ShoppingBag, s as Plus, w as Check } from "../_libs/lucide-react.mjs";
import { f as useCart, h as cn, p as useCartHydrated } from "./router-dqPFFXFI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/add-to-cart-CNuvZoGo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Sepete ekleme; eklendikten sonra 1.8 sn "Eklendi" durumunda kalır.
* Sepet localStorage'dan hydrate olduğu için hydration bitene kadar buton
* devre dışıdır — aksi hâlde ilk tıklama boş state üzerine yazardı.
*/
function AddToCart({ product, qty = 1, variant = "solid", label = "Sepete Ekle", className }) {
	const hydrated = useCartHydrated();
	const add = useCart((s) => s.add);
	const [added, setAdded] = (0, import_react.useState)(false);
	const timer = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => () => {
		if (timer.current) clearTimeout(timer.current);
	}, []);
	const onClick = () => {
		add(product.slug, qty);
		setAdded(true);
		if (timer.current) clearTimeout(timer.current);
		timer.current = setTimeout(() => setAdded(false), 1800);
	};
	if (variant === "icon") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		disabled: !hydrated,
		"aria-label": `${product.shortName} sepete ekle`,
		className: cn("inline-flex h-10 w-10 items-center justify-center rounded-full text-white transition-transform hover:scale-110 disabled:opacity-50", className),
		style: { backgroundColor: added ? "#16a34a" : product.accent },
		children: added ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" })
	});
	if (variant === "ghost") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		disabled: !hydrated,
		className: cn("inline-flex items-center justify-center gap-2 rounded-full border px-6 py-3.5 text-sm font-semibold transition-colors disabled:opacity-50", className),
		style: {
			borderColor: `${product.accent}66`,
			color: added ? "#16a34a" : product.accent
		},
		children: [added ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), added ? "Sepete Eklendi" : label]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		disabled: !hydrated,
		className: cn("inline-flex items-center justify-center gap-2 rounded-full px-7 py-3.5 text-sm font-semibold text-white shadow-lg transition-transform hover:scale-105 disabled:opacity-50", className),
		style: {
			backgroundColor: added ? "#16a34a" : product.accent,
			boxShadow: `0 12px 34px -14px ${product.accent}`
		},
		children: [added ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "h-4 w-4" }), added ? "Sepete Eklendi" : label]
	});
}
//#endregion
export { AddToCart as t };
