import { _ as Link, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Route$5, y as mediaUrl } from "./router-D6WmJc6q.mjs";
import { t as formatBlogDate } from "./content-Z140g0m_.mjs";
import { t as ProductRail } from "./product-rail-1S_Qn-Sf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/blog-B0EtqNWa.js
var import_jsx_runtime = require_jsx_runtime();
function BlogIndexPage() {
	const posts = Route$5.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-background pb-14 pt-16 md:pb-16 md:pt-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container mx-auto max-w-3xl px-4 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-semibold uppercase tracking-[0.35em] text-accent",
						children: "Yazılar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-5 text-4xl font-bold leading-tight tracking-tight text-foreground md:text-5xl",
						children: "Etiketi birlikte okuyalım."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-5 max-w-xl text-base leading-relaxed text-muted-foreground md:text-lg",
						children: "Pazarlama cümlesi değil, etiket satırı. Bir takviyenin gerçekte ne söylediğini anlamanız için yazıyoruz."
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-background pb-20 md:pb-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "container mx-auto px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid items-start gap-10 md:grid-cols-3 md:gap-8",
					children: posts.map((post) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/blog/$slug",
						params: { slug: post.slug },
						className: "group block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-hidden rounded-2xl",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: mediaUrl(post.cover),
									alt: "",
									"aria-hidden": true,
									loading: "lazy",
									className: "aspect-[4/3] w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-5 inline-block rounded-full px-3 py-1 text-[11px] font-medium uppercase tracking-wider",
								style: {
									backgroundColor: `${post.categoryAccent}1f`,
									color: post.categoryAccent
								},
								children: post.category
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-3 block text-xs text-muted-foreground",
								children: [
									formatBlogDate(post.date),
									" · ",
									post.readingMinutes,
									" dk okuma"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 text-xl font-bold leading-snug tracking-tight text-foreground",
								children: post.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2.5 text-sm leading-relaxed text-muted-foreground",
								children: post.excerpt
							})
						]
					}) }, post.slug))
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductRail, {})
		})
	] });
}
//#endregion
export { BlogIndexPage as component };
