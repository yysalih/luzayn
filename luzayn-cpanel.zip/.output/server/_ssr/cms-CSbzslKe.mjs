import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cms-CSbzslKe.js
/**
* Beyan uyarısı. Mevzuat referansı luzayn.com ürün sayfalarında da
* dipnot olarak kullanılan kaynaktır.
*/
var CLAIM_DISCLAIMER = "Beyanlar yalnızca ürünün içerdiği vitamin, mineral ve yağ asitlerine ait, mevzuatça izin verilen ifadelerdir (Gıda ve Takviye Edici Gıdalarda Sağlık Beyanı Kullanımı Hakkında Yönetmelik — 32169 sayılı, 20.04.2023 tarihli Resmî Gazete). Takviye edici gıdalar normal beslenmenin yerine geçmez; hastalıkların önlenmesi veya tedavisi amacıyla kullanılmaz. Tavsiye edilen günlük porsiyonu aşmayınız.";
var CDN_PATHS = {
	cover: (slug) => `/covers/${slug}.jfif`,
	image: (slug) => `/images/${slug}.jfif`,
	videoDesktop: (slug) => `/videos/desktop/${slug}.mp4`,
	videoMobile: (slug) => `/videos/mobile/${slug}.mp4`
};
/**
* Şirket bilgileri. Ambalajdan okunabilen alanlar doldurulmuştur; render'da
* net okunamayan kayıt numaraları BOŞ bırakıldı — asla uydurulmaz.
* Yasal sayfalar ve mesafeli satış sözleşmesi bunları kullanır.
*/
var SITE = {
	name: "Luzayn",
	legalName: "Luzayn Vitamin Sağlık Ürn. San. Tic. A.Ş.",
	tagline: "Bilimin ölçtüğü, doğanın verdiği",
	description: "Luzayn; vitamin, mineral ve bitkisel bileşenlerden oluşan takviye edici gıda serisi. Her formülün içeriği, miktarı ve dayanağı açıkça yazılıdır.",
	email: "info@luzayn.com",
	phone: "+90 533 412 53 42",
	/** Uluslararası format, boşluksuz — wa.me linki için */
	whatsapp: "905334125342",
	address: "Üsküdar, İstanbul",
	fullAddress: "Aziz Mahmut Hüdayi Mah. Gülfem Sk. Erkmen Han No: 5/12 Üsküdar / İstanbul",
	/**
	* HÂLÂ EKSİK — müşteriden gelecek. Boş oldukları sürece arayüzde hiç
	* gösterilmezler (yer tutucu metin basmak yerine satır gizlenir).
	* Mesafeli satış sözleşmesi bunlar olmadan hukuken eksiktir.
	*/
	businessRegNo: "",
	supplementApprovalNo: "",
	mersis: "",
	taxOffice: "",
	taxNumber: "",
	origin: "Türkiye",
	url: "https://luzayn.com",
	/** Yalnızca var olan hesaplar listelenir. */
	social: { instagram: "https://www.instagram.com/luzayntr/" }
};
/** Ambalaj üzerindeki sertifika işaretleri */
var CERTIFICATIONS = [
	{
		code: "GMP",
		label: "İyi Üretim Uygulamaları"
	},
	{
		code: "ISO",
		label: "Kalite Yönetim Sistemi"
	},
	{
		code: "HACCP",
		label: "Gıda Güvenliği Yönetimi"
	},
	{
		code: "FDA",
		label: "Tesis Kaydı"
	}
];
/**
* Supabase istemcisi — içerik yönetimi panelinin yazdığı verileri okur.
*
* ANON ANAHTAR BİLEREK: yetki anahtardan değil RLS politikalarından geliyor.
* Storefront hiçbir zaman giriş yapmaz, dolayısıyla yalnızca "public reads
* published" politikalarının açtığı satırları görür — taslak ürünler,
* yayınlanmamış yazılar ve iletişim mesajları bu anahtarla okunamaz.
*
* service_role anahtarı bu projede YOK ve olmamalı: RLS'i tamamen bypass
* eder, yani panelde yazılmış bütün politikaları etkisiz kılar.
*/
var url = "https://tlxrscnsmppycbwlhwzx.supabase.co".trim().replace(/\/+$/, "");
var anonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRseHJzY25zbXBweWNid2xod3p4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODcwNTcyNDEsImV4cCI6MjEwMjYzMzI0MX0.9M4tdtM7l_PVUcQvM2wIFtajkQICxeZu2EYESVXqiaE".trim();
var isSupabaseConfigured = Boolean(url && anonKey);
/**
* Ham REST erişimi için kök ve anahtar.
*
* Olay ölçümü (src/lib/track.ts) SDK yerine düz `fetch` kullanıyor: sekme
* kapanırken gönderim yapabilmek için `keepalive` gerekiyor ve SDK bu seçeneği
* geçirmiyor. Bunlar zaten tarayıcı paketinin içinde olan değerler, dışa
* vermek yeni bir şey açmıyor.
*/
var SUPABASE_REST_URL = url ? `${url}/rest/v1` : "";
var SUPABASE_ANON_KEY = anonKey;
/**
* Yapılandırılmamışken null döner — throw etmez.
*
* Sebep: site iyzico ve Resend eksikken de ayakta kalıyor ve kullanıcıya
* nazik bir mesaj gösteriyor. Aynı davranışı burada da koruyoruz ki
* .env'i doldurmamış bir geliştirici beyaz ekran değil, ne eksik olduğunu
* söyleyen bir hata görsün.
*/
var supabase = isSupabaseConfigured ? createClient(url, anonKey, { auth: {
	persistSession: false,
	autoRefreshToken: false
} }) : null;
var SUPABASE_MISSING = "İçerik veritabanı yapılandırılmamış: VITE_SUPABASE_URL ve VITE_SUPABASE_ANON_KEY tanımlı olmalı.";
/** Yapılandırma yoksa açıklayıcı hata fırlatır, varsa istemciyi verir. */
function requireSupabase() {
	if (!supabase) throw new Error(SUPABASE_MISSING);
	return supabase;
}
function toProduct(row) {
	return {
		slug: row.slug,
		name: row.name,
		shortName: row.short_name,
		category: row.category,
		tagline: row.tagline,
		subtitle: row.subtitle,
		accent: row.accent,
		price: Number(row.price),
		unit: row.unit,
		form: row.form,
		servingSize: row.serving_size,
		featured: row.featured,
		inStock: row.in_stock,
		motto: row.motto,
		description: row.description,
		features: row.features ?? [],
		composition: row.composition ?? [],
		keyIngredients: row.key_ingredients ?? [],
		highlights: row.highlights ?? [],
		usage: row.usage_text,
		storage: row.storage_text,
		claimBasis: row.claim_basis ?? [],
		shopifyVariantId: row.shopify_variant_id,
		cover: row.cover_url || CDN_PATHS.cover(row.slug),
		image: row.image_url || CDN_PATHS.image(row.slug)
	};
}
var PRODUCT_COLUMNS = "slug, name, short_name, category, tagline, subtitle, accent, price, unit, form, serving_size, motto, description, usage_text, storage_text, features, key_ingredients, composition, highlights, claim_basis, shopify_variant_id, cover_url, image_url, featured, in_stock, sort_order";
/**
* Katalog önbelleği.
*
* Kök route ve sayfa loader'ları aynı katalogu istiyor. Önbellek olmadan tek
* bir sayfa yüklemesi aynı sekiz satırı iki kez çekerdi.
*
* DEĞER DEĞİL PROMISE saklanıyor: iki loader aynı anda çağırdığında ikisi de
* aynı isteği bekler, iki paralel sorgu açılmaz. Bu, ilk isteğin en sık
* karşılaşılan durum olduğu SSR'da fark yaratır.
*
* Hata durumunda önbellek TEMİZLENİR — başarısız bir okumayı 30 saniye
* boyunca tekrar tekrar döndürmek, geçici bir kesintiyi kalıcı hataya
* çevirirdi.
*
* Süre panelde yapılan bir değişikliğin sitede görünmesini en fazla bu kadar
* geciktirir. Yalnızca yayınlanmış içerik önbelleklendiği için kullanıcıya
* özel veri sızma ihtimali yok.
*/
var CATALOG_TTL_MS = 3e4;
var catalogCache = null;
function loadCatalog() {
	const now = Date.now();
	if (catalogCache && now - catalogCache.at < CATALOG_TTL_MS) return catalogCache.promise;
	const promise = fetchCatalog().catch((err) => {
		catalogCache = null;
		throw err;
	});
	catalogCache = {
		at: now,
		promise
	};
	return promise;
}
async function fetchCatalog() {
	const db = requireSupabase();
	const [productsResult, settingsResult] = await Promise.all([db.from("products").select(PRODUCT_COLUMNS).order("sort_order"), db.from("commerce_settings").select("*").eq("id", 1).maybeSingle()]);
	if (productsResult.error) throw new Error(`Ürünler okunamadı: ${productsResult.error.message}`);
	if (settingsResult.error) throw new Error(`Ticari ayarlar okunamadı: ${settingsResult.error.message}`);
	const products = (productsResult.data ?? []).map(toProduct);
	const s = settingsResult.data;
	return {
		products,
		bySlug: Object.fromEntries(products.map((p) => [p.slug, p])),
		categories: [...new Set(products.map((p) => p.category))],
		featured: products.filter((p) => p.featured),
		commerce: {
			freeShippingThreshold: s?.free_shipping_threshold == null ? null : Number(s.free_shipping_threshold),
			standardShippingFee: Number(s?.standard_shipping_fee ?? 0),
			returnDays: Number(s?.return_days ?? 14)
		},
		bundle: {
			name: s?.bundle_name ?? "",
			tagline: s?.bundle_tagline ?? "",
			slugs: s?.bundle_slugs ?? [],
			discountRate: Number(s?.bundle_discount_rate ?? 0)
		}
	};
}
/**
* Set teklifinin fiyat matematiği.
*
* brand.ts'teki bundleTotals()'un katalog alan hali. Setteki bir ürün
* yayından kaldırılmışsa toplamdan da düşer — aksi halde sepete
* eklenemeyecek bir ürünün fiyatı toplamda görünürdü.
*
* discountRate 0 olduğu sürece saving 0 kalır ve site üstü çizili fiyat
* göstermez; uydurma çapa fiyat kurulmaz.
*/
function bundleTotals(catalog) {
	const items = catalog.bundle.slugs.flatMap((slug) => catalog.bySlug[slug] ?? []);
	const listTotal = items.reduce((sum, p) => sum + p.price, 0);
	const total = Math.round(listTotal * (1 - catalog.bundle.discountRate));
	return {
		items,
		listTotal,
		total,
		saving: listTotal - total
	};
}
/**
* Vitrin tabloları ürün verisini tekrarlamaz; başlık, renk ve video
* ürünün kendi satırından okunur. Bu yüzden katalog parametre olarak
* geliyor — iki kez çekilmesin diye.
*/
async function loadHome(catalog) {
	const db = requireSupabase();
	const [slides, tags, videos, stats, philosophy] = await Promise.all([
		db.from("hero_slides").select("product_slug, line").order("sort_order"),
		db.from("hero_tags").select("label, product_slug").order("sort_order"),
		db.from("video_wall_items").select("product_slug").order("sort_order"),
		db.from("evidence_stats").select("product_slug, ring, value, unit, title, context").order("sort_order"),
		db.from("philosophy").select("*").eq("id", 1).maybeSingle()
	]);
	const firstError = [
		slides,
		tags,
		videos,
		stats,
		philosophy
	].find((r) => r.error);
	if (firstError?.error) throw new Error(`Vitrin okunamadı: ${firstError.error.message}`);
	return {
		heroSlides: (slides.data ?? []).flatMap((row) => {
			const p = catalog.bySlug[row.product_slug];
			if (!p) return [];
			return [{
				id: p.slug,
				title: p.motto,
				description: row.line,
				accent: p.accent,
				videoDesktop: CDN_PATHS.videoDesktop(p.slug),
				videoMobile: CDN_PATHS.videoMobile(p.slug),
				poster: p.cover,
				ctaLabel: `${p.shortName} İncele`
			}];
		}),
		heroTags: (tags.data ?? []).map((row) => ({
			label: row.label,
			accent: row.product_slug ? catalog.bySlug[row.product_slug]?.accent ?? "" : ""
		})),
		videoWallSlugs: (videos.data ?? []).map((row) => row.product_slug).filter((slug) => Boolean(catalog.bySlug[slug])),
		evidenceStats: (stats.data ?? []).flatMap((row) => {
			if (!catalog.bySlug[row.product_slug]) return [];
			return [{
				slug: row.product_slug,
				ring: row.ring,
				value: row.value,
				unit: row.unit || void 0,
				title: row.title,
				context: row.context
			}];
		}),
		philosophy: philosophy.data ? {
			kicker: philosophy.data.kicker,
			title: philosophy.data.title,
			intro: philosophy.data.intro,
			values: philosophy.data.principles ?? []
		} : null
	};
}
async function loadFaq() {
	const { data, error } = await requireSupabase().from("faq_items").select("question, answer").order("sort_order");
	if (error) throw new Error(`SSS okunamadı: ${error.message}`);
	return data ?? [];
}
/**
* Panelde bölüm gövdesi tek bir metin kutusu, sitede paragraf dizisi.
* Boş satır ayracıyla bölüyoruz — seed de aynı ayraçla birleştirmişti.
*/
function toPost(row) {
	return {
		slug: row.slug,
		category: row.category,
		categoryAccent: row.accent ?? "",
		title: row.title,
		excerpt: row.excerpt,
		date: row.published_at,
		readingMinutes: row.read_minutes ?? 0,
		cover: row.cover ?? "",
		sections: (row.sections ?? []).map((s) => ({
			heading: s.heading ?? "",
			body: s.body.split(/\n{2,}/).map((p) => p.trim()).filter(Boolean)
		}))
	};
}
var BLOG_COLUMNS = "slug, title, excerpt, category, published_at, read_minutes, cover, accent, sections";
async function loadBlogPosts() {
	const { data, error } = await requireSupabase().from("blog_posts").select(BLOG_COLUMNS).order("published_at", { ascending: false });
	if (error) throw new Error(`Blog yazıları okunamadı: ${error.message}`);
	return (data ?? []).map(toPost);
}
async function loadBlogPost(slug) {
	const { data, error } = await requireSupabase().from("blog_posts").select(BLOG_COLUMNS).eq("slug", slug).maybeSingle();
	if (error) throw new Error(`Yazı okunamadı: ${error.message}`);
	return data ? toPost(data) : null;
}
/**
* Mesajı gelen kutusuna yazar.
*
* Hata FIRLATMAZ, sonuç döndürür: bu çağrı e-posta gönderiminin yanında
* ikinci bir kayıt yolu. Veritabanı yazımı başarısız diye kullanıcıya
* "mesajınız gönderilemedi" demek yanlış olur — e-posta gitmiş olabilir.
*/
async function recordContactMessage(input) {
	if (!supabaseAvailable()) return {
		ok: false,
		error: "yapılandırılmamış"
	};
	const { error } = await requireSupabase().from("contact_messages").insert({
		name: input.name,
		email: input.email,
		phone: input.phone || null,
		order_ref: input.orderRef || null,
		subject: input.subject,
		message: input.message,
		status: "new"
	});
	return error ? {
		ok: false,
		error: error.message
	} : { ok: true };
}
function supabaseAvailable() {
	try {
		requireSupabase();
		return true;
	} catch {
		return false;
	}
}
//#endregion
export { SUPABASE_ANON_KEY as a, loadBlogPost as c, loadFaq as d, loadHome as f, SITE as i, loadBlogPosts as l, CERTIFICATIONS as n, SUPABASE_REST_URL as o, recordContactMessage as p, CLAIM_DISCLAIMER as r, bundleTotals as s, CDN_PATHS as t, loadCatalog as u };
