import { o as __toESM } from "../_runtime.mjs";
import { i as SITE, p as recordContactMessage } from "./cms-CSbzslKe.mjs";
import { n as createServerFn } from "./ssr.mjs";
import { a as string, i as object, t as _enum } from "../_libs/zod.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-ycV5B13R.js
/**
* İletişim formu → kendi SMTP sunucunuz (DirectAdmin / cPanel).
*
* Üçüncü taraf bir e-posta servisi yerine doğrudan alan adınızın posta
* sunucusu kullanılıyor. Site kendi sunucunuzda barındırılıyorsa SMTP_HOST
* olarak 'localhost' vermek en hızlısıdır — posta aynı makinede.
*
* Gönderen HER ZAMAN kendi alan adınızdaki bir kutu olmalı (örn.
* noreply@luzayn.com). Ziyaretçinin adresini From'a koymak SPF/DKIM'i
* bozar ve postayı spam'e düşürür; ziyaretçi adresi Reply-To'ya konur.
*/
var contactInputSchema = object({
	name: string().trim().min(2, "Adınızı girin."),
	email: string().trim().email("Geçerli bir e-posta girin."),
	phone: string().trim().max(20).optional(),
	orderRef: string().trim().max(40).optional(),
	subject: _enum([
		"genel",
		"siparis",
		"urun",
		"toptan",
		"kvkk"
	]),
	message: string().trim().min(10, "Mesajınızı biraz açar mısınız?").max(4e3)
});
var SUBJECT_LABELS = {
	genel: "Genel Soru",
	siparis: "Sipariş / Kargo",
	urun: "Ürün ve İçerik Sorusu",
	toptan: "Toptan / İş Birliği",
	kvkk: "KVKK / Veri Talebi"
};
var FALLBACK = `Mesajınız gönderilemedi. Lütfen doğrudan ${SITE.email} adresine yazın.`;
function getSmtpConfig() {
	const host = process.env.SMTP_HOST?.trim();
	const user = process.env.SMTP_USER?.trim();
	const pass = process.env.SMTP_PASS;
	const to = process.env.CONTACT_TO_EMAIL?.trim() || SITE.email;
	if (!host || !user || !pass) return null;
	const port = Number(process.env.SMTP_PORT ?? 465);
	return {
		host,
		port,
		secure: port === 465,
		user,
		pass,
		from: process.env.SMTP_FROM?.trim() || `${SITE.name} <${user}>`,
		to
	};
}
/** HTML e-postada kullanıcı metnini gömerken kaçış şart */
function escapeHtml(value) {
	return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
var sendContactMessage_createServerFn_handler = createServerRpc({
	id: "f54981346a2987ec7c9440352519056da116b4953a994af19f6d8ca685253e80",
	name: "sendContactMessage",
	filename: "src/server/contact.ts"
}, (opts) => sendContactMessage.__executeServer(opts));
var sendContactMessage = createServerFn({ method: "POST" }).validator((data) => contactInputSchema.parse(data)).handler(sendContactMessage_createServerFn_handler, async ({ data }) => {
	/**
	* ÖNCE gelen kutusuna yaz, SONRA e-posta gönder.
	*
	* Sıra bilinçli: e-posta gidemezse (SMTP eksik, kota dolu, spam
	* klasörü) mesaj yine de panelde durur. Tersi sırada, gönderim
	* başarısız olduğunda mesaj hiçbir yerde kalmazdı — bugünkü davranış
	* buydu.
	*
	* Yazma hatası kullanıcıya YANSITILMAZ: e-posta gitmiş olabilir ve
	* "mesajınız gönderilemedi" demek yanlış olurdu. Sunucu günlüğüne
	* düşürüp devam ediyoruz.
	*/
	const recorded = await recordContactMessage({
		name: data.name,
		email: data.email,
		phone: data.phone,
		orderRef: data.orderRef,
		subject: data.subject,
		message: data.message
	});
	if (!recorded.ok) console.error("[iletişim] mesaj panele yazılamadı:", recorded.error);
	const config = getSmtpConfig();
	if (!config) {
		console.error("[iletişim] SMTP_HOST / SMTP_USER / SMTP_PASS eksik. Gelen mesaj:", {
			...data,
			message: `${data.message.slice(0, 200)}…`
		});
		if (recorded.ok) return { ok: true };
		return {
			ok: false,
			message: `E-posta gönderimi henüz yapılandırılmamış. Mesajınızı doğrudan ${SITE.email} adresine iletebilirsiniz.`
		};
	}
	const konu = SUBJECT_LABELS[data.subject];
	const satirlar = [
		["Ad Soyad", data.name],
		["E-posta", data.email],
		["Telefon", data.phone],
		["Sipariş Referansı", data.orderRef],
		["Konu", konu]
	].filter((row) => Boolean(row[1]));
	const text = [
		...satirlar.map(([k, v]) => `${k}: ${v}`),
		"",
		data.message
	].join("\n");
	const html = [
		"<div style=\"font-family:system-ui,sans-serif;font-size:14px;line-height:1.6\">",
		"<table cellpadding=\"6\" style=\"border-collapse:collapse\">",
		...satirlar.map(([k, v]) => `<tr><td style="color:#666">${escapeHtml(k)}</td><td><strong>${escapeHtml(v)}</strong></td></tr>`),
		"</table>",
		`<p style="white-space:pre-wrap;margin-top:16px">${escapeHtml(data.message)}</p>`,
		"</div>"
	].join("");
	try {
		await (await import("../_libs/nodemailer.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()))).createTransport({
			host: config.host,
			port: config.port,
			secure: config.secure,
			auth: {
				user: config.user,
				pass: config.pass
			},
			connectionTimeout: 1e4,
			greetingTimeout: 1e4,
			socketTimeout: 15e3
		}).sendMail({
			from: config.from,
			to: config.to,
			replyTo: `${data.name} <${data.email}>`,
			subject: `[Web Sitesi İletişim Formu] ${konu} — ${data.name}`,
			text,
			html
		});
		return { ok: true };
	} catch (err) {
		/**
		* Nodemailer hataları teşhis için gereken her şeyi taşır ama düz
		* basıldığında okunmuyor. Alanları ayrı ayrı yazıyoruz:
		*   EAUTH + 535  → kullanıcı adı/şifre yanlış ya da kutu yok
		*   ECONNECTION / ETIMEDOUT → porta ulaşılamıyor
		*   EENVELOPE    → gönderen/alıcı adresi reddedildi
		*/
		const e = err;
		console.error("[iletişim] SMTP hatası:", JSON.stringify({
			code: e.code,
			responseCode: e.responseCode,
			response: e.response,
			command: e.command,
			message: e.message,
			host: config.host,
			port: config.port,
			secure: config.secure,
			user: config.user
		}));
		return {
			ok: false,
			message: FALLBACK
		};
	}
});
//#endregion
export { sendContactMessage_createServerFn_handler };
