//#region node_modules/.nitro/vite/services/ssr/assets/content-Z140g0m_.js
function formatBlogDate(iso) {
	return new Intl.DateTimeFormat("tr-TR", {
		day: "numeric",
		month: "long",
		year: "numeric"
	}).format(new Date(iso));
}
//#endregion
export { formatBlogDate as t };
