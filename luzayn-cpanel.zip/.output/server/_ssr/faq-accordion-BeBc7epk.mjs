import { o as __toESM } from "../_runtime.mjs";
import { B as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as Plus } from "../_libs/lucide-react.mjs";
import { _ as cn } from "./router-D6WmJc6q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/faq-accordion-BeBc7epk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FaqAccordion({ items, dark = false }) {
	const [open, setOpen] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("divide-y rounded-3xl border", dark ? "divide-white/10 border-white/10 bg-white/[0.04] backdrop-blur-md" : "divide-border border-border bg-card"),
		children: items.map((item, i) => {
			const isOpen = open === i;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setOpen(isOpen ? null : i),
				"aria-expanded": isOpen,
				className: cn("flex w-full items-start justify-between gap-4 px-6 py-5 text-left transition-colors md:px-8", dark ? "hover:bg-white/[0.03]" : "hover:bg-muted/60"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("text-base font-semibold", dark ? "text-white" : "text-foreground"),
					children: item.question
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: cn("mt-0.5 h-5 w-5 shrink-0 transition-transform duration-300", isOpen && "rotate-45", dark ? "text-white/40" : "text-muted-foreground") })]
			}), isOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("animate-[showcase-fade-in_0.25s_ease-out] px-6 pb-6 text-sm leading-relaxed md:px-8", dark ? "text-white/60" : "text-muted-foreground"),
				children: item.answer
			}) : null] }, item.question);
		})
	});
}
//#endregion
export { FaqAccordion as t };
