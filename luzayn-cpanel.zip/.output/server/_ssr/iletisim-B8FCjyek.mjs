import { o as __toESM } from "../_runtime.mjs";
import { i as SITE } from "./cms-CSbzslKe.mjs";
import { B as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as CircleAlert, h as Mail, l as Phone, m as MapPin, o as Send, y as CircleCheck } from "../_libs/lucide-react.mjs";
import { s as Route$10 } from "./router-D6WmJc6q.mjs";
import { a as SectionTitle, n as KickerPill } from "./typography-1iJfy8Yl.mjs";
import { n as createServerFn } from "./ssr.mjs";
import { t as createSsrRpc } from "./createSsrRpc-C1p7zOu_.mjs";
import { a as string, i as object, t as _enum } from "../_libs/zod.mjs";
import { t as PageHero } from "./page-hero-CgaOIMi9.mjs";
import { t as FaqAccordion } from "./faq-accordion-BeBc7epk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/iletisim-B8FCjyek.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* İletişim formu → kendi SMTP sunucunuz (DirectAdmin / cPanel).
*
* Üçüncü taraf bir e-posta servisi yerine doğrudan alan adınızın posta
* sunucusu kullanılıyor. Site kendi sunucunuzda barındırılıyorsa SMTP_HOST
* olarak 'localhost' vermek en hızlısıdır — posta aynı makinede.
*
* Gönderen HER ZAMAN kendi alan adınızdaki bir kutu olmalı (örn.
* noreply@luzayn.com). Ziyaretçinin adresini From'a koymak SPF/DKIM'i
* bozar ve postayı spam'e düşürür; ziyaretçi adresi Reply-To'ya konur.
*/
var contactInputSchema = object({
	name: string().trim().min(2, "Adınızı girin."),
	email: string().trim().email("Geçerli bir e-posta girin."),
	phone: string().trim().max(20).optional(),
	orderRef: string().trim().max(40).optional(),
	subject: _enum([
		"genel",
		"siparis",
		"urun",
		"toptan",
		"kvkk"
	]),
	message: string().trim().min(10, "Mesajınızı biraz açar mısınız?").max(4e3)
});
var SUBJECT_LABELS = {
	genel: "Genel Soru",
	siparis: "Sipariş / Kargo",
	urun: "Ürün ve İçerik Sorusu",
	toptan: "Toptan / İş Birliği",
	kvkk: "KVKK / Veri Talebi"
};
/** HTML e-postada kullanıcı metnini gömerken kaçış şart */
var sendContactMessage = createServerFn({ method: "POST" }).validator((data) => contactInputSchema.parse(data)).handler(createSsrRpc("f54981346a2987ec7c9440352519056da116b4953a994af19f6d8ca685253e80"));
function ContactForm() {
	const [status, setStatus] = (0, import_react.useState)({ kind: "idle" });
	const onSubmit = async (event) => {
		event.preventDefault();
		const form = event.currentTarget;
		const data = new FormData(form);
		setStatus({ kind: "sending" });
		try {
			const result = await sendContactMessage({ data: {
				name: String(data.get("name") ?? ""),
				email: String(data.get("email") ?? ""),
				phone: String(data.get("phone") ?? "") || void 0,
				orderRef: String(data.get("orderRef") ?? "") || void 0,
				subject: String(data.get("subject") ?? "genel"),
				message: String(data.get("message") ?? "")
			} });
			if (result.ok) {
				setStatus({ kind: "sent" });
				form.reset();
				return;
			}
			setStatus({
				kind: "error",
				message: result.message
			});
		} catch (err) {
			console.error("[iletişim formu] hata:", err);
			setStatus({
				kind: "error",
				message: `Mesajınız gönderilemedi. Lütfen ${SITE.email} adresine doğrudan yazın.`
			});
		}
	};
	if (status.kind === "sent") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-3xl border border-emerald-200 bg-emerald-50 p-8 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mx-auto h-10 w-10 text-emerald-600" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-4 text-lg font-bold text-emerald-900",
				children: "Mesajınız bize ulaştı."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-emerald-800",
				children: "En kısa sürede dönüş yapacağız."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setStatus({ kind: "idle" }),
				className: "mt-6 text-sm font-semibold text-emerald-700 hover:underline",
				children: "Yeni mesaj yaz"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "rounded-3xl border border-border bg-card p-6 md:p-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						name: "name",
						label: "Ad Soyad",
						required: true,
						autoComplete: "name"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						name: "email",
						label: "E-posta",
						type: "email",
						required: true,
						autoComplete: "email"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						name: "phone",
						label: "Telefon (isteğe bağlı)",
						type: "tel",
						autoComplete: "tel"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						name: "orderRef",
						label: "Sipariş referansı (varsa)"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium text-muted-foreground",
					children: "Konu"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					name: "subject",
					defaultValue: "genel",
					className: "mt-1.5 w-full rounded-xl border border-border bg-background px-4 py-3 text-sm text-foreground outline-none transition-colors focus:border-accent",
					children: Object.entries(SUBJECT_LABELS).map(([value, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value,
						children: label
					}, value))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium text-muted-foreground",
					children: "Mesaj"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					name: "message",
					rows: 6,
					required: true,
					minLength: 10,
					className: "mt-1.5 w-full rounded-xl border border-border bg-background px-4 py-3 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-accent",
					placeholder: "Sorunuzu veya talebinizi yazın."
				})]
			}),
			status.kind === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				role: "alert",
				className: "mt-4 flex items-start gap-3 rounded-2xl border border-red-200 bg-red-50 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "mt-0.5 h-4 w-4 shrink-0 text-red-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-relaxed text-red-800",
					children: status.message
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "submit",
				disabled: status.kind === "sending",
				className: "mt-6 inline-flex items-center justify-center gap-2 rounded-full bg-accent px-7 py-3.5 text-sm font-semibold text-white shadow-lg shadow-accent/25 transition-transform hover:scale-105 disabled:opacity-60",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-4 w-4" }), status.kind === "sending" ? "Gönderiliyor…" : "Mesajı Gönder"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs leading-relaxed text-muted-foreground",
				children: "Gönderdiğiniz bilgiler yalnızca talebinizi yanıtlamak için işlenir. Ayrıntı için KVKK Aydınlatma Metni’ne bakabilirsiniz."
			})
		]
	});
}
function Field({ name, label, ...rest }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-medium text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			name,
			className: "mt-1.5 w-full rounded-xl border border-border bg-background px-4 py-3 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-accent",
			...rest
		})]
	});
}
function ContactPage() {
	const faq = Route$10.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			kicker: "İletişim",
			title: "Sorunuzu yazın.",
			lead: "Ürün içeriği, sipariş durumu, toptan alım veya veri talepleri — hepsi için aynı formu kullanabilirsiniz."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-background py-16 md:py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "container mx-auto px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-10 lg:grid-cols-[1fr_1.3fr] lg:gap-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KickerPill, { children: "Bize Ulaşın" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
							className: "mt-4 text-2xl md:text-3xl",
							children: "Doğrudan iletişim"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-8 space-y-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactRow, {
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4" }),
									label: "E-posta",
									value: SITE.email,
									href: `mailto:${SITE.email}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactRow, {
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-4 w-4" }),
									label: "Telefon",
									value: SITE.phone,
									href: `tel:${SITE.phone.replace(/\s/g, "")}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactRow, {
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4" }),
									label: "Adres",
									value: SITE.fullAddress
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-10 rounded-2xl border border-border bg-muted/40 p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-sm font-semibold text-foreground",
									children: SITE.legalName
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs leading-relaxed text-muted-foreground",
									children: SITE.fullAddress
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
									className: "mt-3 space-y-1.5 text-xs text-muted-foreground",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoLine, {
											label: "MERSİS No",
											value: SITE.mersis
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoLine, {
											label: "Vergi Dairesi",
											value: SITE.taxOffice
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoLine, {
											label: "Vergi No",
											value: SITE.taxNumber
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoLine, {
											label: "İşletme Kayıt No",
											value: SITE.businessRegNo
										})
									]
								})
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactForm, {})]
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-border bg-muted/30 py-16 md:py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container mx-auto max-w-3xl px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
					className: "text-2xl md:text-3xl",
					children: "Önce buraya bakın"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqAccordion, { items: faq.slice(0, 5) })
				})]
			})
		})
	] });
}
function ContactRow({ icon, label, value, href }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-start gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-0.5 inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-accent/10 text-accent",
			children: icon
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-xs font-medium uppercase tracking-wider text-muted-foreground",
			children: label
		}), href ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href,
			className: "mt-0.5 block text-sm font-medium text-foreground hover:text-accent",
			children: value
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-0.5 block text-sm font-medium text-foreground",
			children: value
		})] })]
	});
}
/** Değeri boş olan satır hiç render edilmez — canlı sitede yer tutucu metin göstermeyiz. */
function InfoLine({ label, value }) {
	if (!value) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dt", {
			className: "shrink-0",
			children: [label, ":"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: value })]
	});
}
//#endregion
export { ContactPage as component };
