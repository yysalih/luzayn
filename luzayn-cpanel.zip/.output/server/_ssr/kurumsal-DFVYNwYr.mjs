import { o as __toESM } from "../_runtime.mjs";
import { i as SITE, n as CERTIFICATIONS, r as CLAIM_DISCLAIMER, t as CDN_PATHS } from "./cms-CSbzslKe.mjs";
import { B as require_react, _ as Link, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as ArrowRight, S as ChevronLeft, c as Play, x as ChevronRight } from "../_libs/lucide-react.mjs";
import { m as useCatalog, o as Route$9, v as formatPrice, y as mediaUrl } from "./router-D6WmJc6q.mjs";
import { a as SectionTitle, i as SectionLead, n as KickerPill, r as KickerRuled, t as Disclaimer } from "./typography-1iJfy8Yl.mjs";
import { t as AddToCart } from "./add-to-cart-C3MadfcY.mjs";
import { t as PageHero } from "./page-hero-CgaOIMi9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kurumsal-DFVYNwYr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Seri gezgini — pill'e tıklanınca hemen altında seçilen ürün açılır:
* solda dikey klip, sağda kimlik + porsiyon başına bileşim.
*
* Panel key={slug} ile remount edilir; hem metin hem video baştan girer.
* Videolar sessizdir (ürün render'ı), bu yüzden ses kontrolü yok.
*/
function SeriesExplorer() {
	const [active, setActive] = (0, import_react.useState)(0);
	const { products } = useCatalog();
	const product = products[active];
	const go = (dir) => setActive((i) => (i + dir + products.length) % products.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden bg-[#0a0a12] py-20 md:py-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "pointer-events-none absolute -left-24 top-16 h-[26rem] w-[26rem] rounded-full blur-[140px] transition-colors duration-700",
				style: { backgroundColor: `${product.accent}2e` }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "pointer-events-none absolute inset-0 opacity-[0.04]",
				style: {
					backgroundImage: "radial-gradient(circle, #fff 1px, transparent 1px)",
					backgroundSize: "28px 28px"
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container relative mx-auto px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-end justify-between gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-2xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KickerRuled, { children: "Seri Gezgini" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLead, {
								dark: true,
								className: "mt-5",
								children: "Bir formül seçin: klibini izleyin, porsiyon başına ne içerdiğini aynı ekranda görün."
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm tabular-nums text-white/40",
									children: [
										String(active + 1).padStart(2, "0"),
										" /",
										" ",
										String(products.length).padStart(2, "0")
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => go(-1),
									"aria-label": "Önceki formül",
									className: "inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/15 text-white transition-colors hover:bg-white/10",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => go(1),
									"aria-label": "Sonraki formül",
									className: "inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/15 text-white transition-colors hover:bg-white/10",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "no-scrollbar mt-10 flex gap-2 overflow-x-auto pb-1",
						role: "tablist",
						"aria-label": "Formüller",
						children: products.map((p, i) => {
							const isActive = i === active;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								role: "tab",
								"aria-selected": isActive,
								onClick: () => setActive(i),
								className: "flex shrink-0 items-center gap-2.5 rounded-full border py-1.5 pl-1.5 pr-4 text-sm font-medium transition-all",
								style: {
									borderColor: isActive ? `${p.accent}80` : "rgba(255,255,255,0.1)",
									backgroundColor: isActive ? `${p.accent}1f` : "transparent",
									color: isActive ? "#ffffff" : "rgba(255,255,255,0.55)",
									boxShadow: isActive ? `0 10px 30px -12px ${p.accent}` : void 0
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: mediaUrl(p.cover),
									alt: "",
									"aria-hidden": true,
									loading: "lazy",
									className: "h-7 w-7 rounded-full object-cover transition-opacity",
									style: { opacity: isActive ? 1 : .5 }
								}), p.shortName]
							}, p.slug);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 animate-[showcase-fade-in_0.45s_ease-out] overflow-hidden rounded-3xl border border-white/10 bg-white/[0.04] backdrop-blur-md",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid lg:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative aspect-[4/5] overflow-hidden lg:aspect-auto lg:min-h-[32rem]",
								style: { backgroundImage: `linear-gradient(160deg, ${product.accent}26, transparent 60%)` },
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: mediaUrl(product.cover),
										alt: "",
										"aria-hidden": true,
										className: "absolute inset-0 h-full w-full object-cover"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
										src: mediaUrl(CDN_PATHS.videoMobile(product.slug)),
										autoPlay: true,
										muted: true,
										loop: true,
										playsInline: true,
										preload: "metadata",
										className: "absolute inset-0 h-full w-full object-cover"
									}, `${product.slug}-video`),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										"aria-hidden": true,
										className: "absolute inset-0 bg-gradient-to-t from-[#0a0a12]/70 via-transparent to-transparent lg:bg-gradient-to-r lg:from-transparent lg:via-transparent lg:to-[#0a0a12]/45"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "absolute left-4 top-4 inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[11px] font-medium text-white backdrop-blur-md",
										style: {
											backgroundColor: `${product.accent}26`,
											border: `1px solid ${product.accent}4d`
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-3 w-3" }), product.category]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col p-7 md:p-10",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-2xl font-bold tracking-tight text-white md:text-3xl",
										children: product.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm font-medium",
										style: { color: product.accent },
										children: product.subtitle
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-sm leading-relaxed text-white/60",
										children: product.description
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-7",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[11px] font-semibold uppercase tracking-[0.2em] text-white/40",
											children: [
												"İçerik · ",
												product.servingSize,
												" için"
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
											className: "mt-3 divide-y divide-white/[0.07] border-y border-white/[0.07]",
											children: product.composition.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-baseline justify-between gap-4 py-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
													className: "text-sm text-white/70",
													children: row.name
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
													className: "shrink-0 text-sm font-semibold tabular-nums text-white",
													children: [row.amount, row.nrv ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "ml-2 text-xs font-normal text-white/40",
														children: [
															"%",
															row.nrv,
															" BRD"
														]
													}) : null]
												})]
											}, row.name))
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-auto flex flex-wrap items-center gap-4 pt-8",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-2xl font-bold text-white",
											children: formatPrice(product.price)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-xs text-white/40",
											children: product.unit
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "ml-auto flex flex-wrap items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddToCart, {
												product,
												variant: "ghost"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/urunler/$slug",
												params: { slug: product.slug },
												className: "inline-flex items-center gap-2 rounded-full px-6 py-3.5 text-sm font-semibold text-white transition-transform hover:scale-105",
												style: {
													backgroundColor: product.accent,
													boxShadow: `0 14px 38px -16px ${product.accent}`
												},
												children: ["Ürünü İncele", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
											})]
										})]
									})
								]
							})]
						})
					}, product.slug),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Disclaimer, {
						dark: true,
						className: "mt-6 max-w-3xl",
						children: CLAIM_DISCLAIMER
					})
				]
			})
		]
	});
}
function AboutPage() {
	const { bySlug } = useCatalog();
	const { philosophy } = Route$9.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			kicker: "Kurumsal",
			title: "Bir kutunun içinde ne olduğunu bilme hakkı.",
			lead: SITE.description
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-background py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "container mx-auto px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KickerPill, { children: philosophy?.kicker }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
							className: "mt-5 max-w-md text-4xl md:text-5xl",
							children: philosophy?.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLead, {
							className: "mt-5 max-w-md",
							children: philosophy?.intro
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 rounded-2xl border border-border bg-muted/40 p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-sm font-semibold text-foreground",
									children: SITE.legalName
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-muted-foreground",
									children: SITE.fullAddress
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-sm text-muted-foreground",
									children: ["Menşei: ", SITE.origin]
								})
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-px overflow-hidden rounded-3xl bg-border sm:grid-cols-2",
						children: (philosophy?.values ?? []).map((value, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "bg-card p-7 md:p-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-semibold tabular-nums text-accent",
									children: String(i + 1).padStart(2, "0")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-3 text-lg font-bold tracking-tight text-foreground",
									children: value.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2.5 text-sm leading-relaxed text-muted-foreground",
									children: value.detail
								})
							]
						}, value.title))
					})]
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative overflow-hidden py-20 md:py-28",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: mediaUrl(bySlug.xsls?.cover ?? CDN_PATHS.cover("xsls")),
					alt: "",
					"aria-hidden": true,
					loading: "lazy",
					className: "absolute inset-0 h-full w-full object-cover opacity-40"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					"aria-hidden": true,
					className: "absolute inset-0 bg-gradient-to-b from-[#0a0a12]/95 via-[#0a0a12]/85 to-[#0a0a12]/95"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container relative mx-auto px-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-2xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KickerRuled, { children: "Üretim ve Kalite" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
									dark: true,
									className: "mt-5",
									children: "Belgesi olanı yazıyoruz."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLead, {
									dark: true,
									className: "mt-4",
									children: "Seri, iyi üretim uygulamaları ve gıda güvenliği yönetimi kapsamında üretilir. Ambalajda işaretli olan belgeler bunlardır; işaretli olmayan hiçbir belgeyi sitede iddia etmiyoruz."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-12 grid items-start gap-4 sm:grid-cols-2 lg:grid-cols-4",
							children: CERTIFICATIONS.map((cert, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "animate-[showcase-rise-in_0.5s_ease-out_both] rounded-3xl border border-white/10 bg-white/[0.04] p-7 backdrop-blur-md",
								style: { animationDelay: `${i * 90}ms` },
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-2xl font-bold tracking-tight text-white",
									children: cert.code
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2.5 text-sm leading-relaxed text-white/55",
									children: cert.label
								})]
							}, cert.code))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Disclaimer, {
							dark: true,
							className: "mt-8 max-w-3xl",
							children: "İşletme kayıt numarası ve takviye edici gıda onay numarası her ürünün ambalajında yer alır. Bu numaralar teyit edildikçe sitede de yayımlanacaktır."
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-background py-20 md:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container mx-auto max-w-3xl px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KickerPill, { children: "İddia Politikası" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
						className: "mt-5",
						children: "Hangi cümleyi neye dayanarak kuruyoruz?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 space-y-6 text-base leading-relaxed text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Sağlık beyanı, mevzuatın yetkilendirdiği besin ögeleri için ve yalnızca o besin ögesine atfen kurulur. Örneğin “magnezyum yorgunluk ve bitkinliğin azalmasına katkıda bulunur” ifadesi magnezyuma aittir; ürüne değil." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Bitkisel bileşenlerin büyük bölümü için yetkilendirilmiş bir beyan bulunmamaktadır. Reishi, kordiseps, safran, rodiola, valerian ve karahindiba içeren formüllerimizde bu bileşenleri yalnızca bileşim olarak tanımlıyor, onlara fayda atfetmiyoruz." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Sitede yer alan her rakam ya doğrudan ürün etiketinden okunur ya da etiket verisinden hesaplanır. Kaynağı gösterilemeyen bir istatistik yayımlanmaz." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Disclaimer, {
						className: "mt-8",
						children: CLAIM_DISCLAIMER
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeriesExplorer, {})
	] });
}
//#endregion
export { AboutPage as component };
