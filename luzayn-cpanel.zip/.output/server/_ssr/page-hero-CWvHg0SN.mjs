import { v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as cn } from "./router-dqPFFXFI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/page-hero-CWvHg0SN.js
var import_jsx_runtime = require_jsx_runtime();
/** Alt sayfaların ortak koyu hero'su — ortalanmış kicker + başlık + intro. */
function PageHero({ kicker, title, lead, accent, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("relative overflow-hidden bg-[#0a0a12] pb-16 pt-20 md:pb-20 md:pt-28", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "pointer-events-none absolute -top-24 left-1/2 h-[26rem] w-[26rem] -translate-x-1/2 rounded-full blur-[130px]",
				style: { backgroundColor: accent ? `${accent}33` : void 0 }
			}),
			!accent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "pointer-events-none absolute -top-24 left-1/2 h-[26rem] w-[26rem] -translate-x-1/2 rounded-full bg-accent/20 blur-[130px]"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "pointer-events-none absolute inset-0 opacity-[0.04]",
				style: {
					backgroundImage: "radial-gradient(circle, #fff 1px, transparent 1px)",
					backgroundSize: "28px 28px"
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container relative mx-auto max-w-3xl px-4 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-semibold uppercase tracking-[0.35em]",
						style: { color: accent },
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: accent ? void 0 : "text-accent",
							children: kicker
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-5 text-4xl font-bold leading-[1.08] tracking-tight text-white sm:text-5xl md:text-6xl",
						children: title
					}),
					lead ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-5 max-w-2xl text-base leading-relaxed text-white/60 md:text-lg",
						children: lead
					}) : null,
					children
				]
			})
		]
	});
}
//#endregion
export { PageHero as t };
