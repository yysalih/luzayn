import { o as __toESM } from "../_runtime.mjs";
import { t as CDN_PATHS } from "./cms-Bdb4agUA.mjs";
import { B as require_react, _ as Link, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as ArrowRight } from "../_libs/lucide-react.mjs";
import { _ as mediaUrl, g as formatPrice, m as useCatalog } from "./router-dqPFFXFI.mjs";
import { a as SectionTitle } from "./typography-YgNHFb6n.mjs";
import { t as AddToCart } from "./add-to-cart-CNuvZoGo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product-rail-Wvefvn3_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProductRail() {
	const { products } = useCatalog();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-background py-16 md:py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container mx-auto px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: "Sekiz formül, sekiz ayrı amaç." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/urunler",
					className: "inline-flex items-center gap-2 rounded-full border border-border px-5 py-2.5 text-sm font-semibold text-foreground transition-colors hover:bg-muted",
					children: ["Tümünü Gör", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "no-scrollbar -mx-4 mt-10 flex snap-x snap-mandatory scroll-px-4 gap-4 overflow-x-auto px-4 py-3 md:mt-12",
				children: products.map((product, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RailCard, {
					product,
					index
				}, product.slug))
			})]
		})
	});
}
function RailCard({ product, index }) {
	const videoRef = (0, import_react.useRef)(null);
	const [hovered, setHovered] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		onMouseEnter: () => {
			setHovered(true);
			videoRef.current?.play().catch(() => void 0);
		},
		onMouseLeave: () => {
			setHovered(false);
			videoRef.current?.pause();
		},
		className: "group relative w-[78%] shrink-0 snap-start overflow-hidden rounded-3xl transition-transform duration-300 hover:-translate-y-1.5 sm:w-72 md:w-80",
		style: {
			minHeight: 480,
			boxShadow: hovered ? `0 30px 70px -30px ${product.accent}` : void 0
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: mediaUrl(CDN_PATHS.cover(product.slug)),
				alt: product.name,
				loading: "lazy",
				className: "absolute inset-0 h-full w-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				ref: videoRef,
				src: mediaUrl(CDN_PATHS.videoDesktop(product.slug)),
				muted: true,
				loop: true,
				playsInline: true,
				preload: "none",
				className: "absolute inset-0 h-full w-full object-cover opacity-0 transition-opacity duration-500 group-hover:opacity-100"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-black/10"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-hidden": true,
				className: "pointer-events-none absolute -right-2 top-2 font-black leading-none text-white/[0.07]",
				style: { fontSize: "9rem" },
				children: String(index + 1).padStart(2, "0")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/urunler/$slug",
				params: { slug: product.slug },
				className: "absolute inset-0 z-10",
				"aria-label": `${product.name} sayfasına git`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none relative z-20 flex h-full flex-col justify-end p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-xl font-bold leading-tight text-white",
						children: product.shortName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1.5 text-sm leading-snug text-white/60",
						children: product.subtitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex flex-wrap gap-1.5",
						children: product.keyIngredients.slice(0, 3).map((ing) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full border px-2.5 py-1 text-[11px] text-white/70",
							style: {
								borderColor: `${product.accent}30`,
								backgroundColor: `${product.accent}1f`
							},
							children: ing
						}, ing))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-lg font-bold text-white",
							children: formatPrice(product.price)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-[11px] text-white/45",
							children: product.unit
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddToCart, {
								product,
								variant: "icon",
								className: "pointer-events-auto"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/urunler/$slug",
								params: { slug: product.slug },
								"aria-label": `${product.shortName} incele`,
								className: "pointer-events-auto inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/15 text-white backdrop-blur-md transition-colors hover:bg-white/10",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })
							})]
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { ProductRail as t };
