import { o as __toESM } from "../_runtime.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as SUPABASE_ANON_KEY, c as loadBlogPost, d as loadFaq, f as loadHome, i as SITE, l as loadBlogPosts, n as CERTIFICATIONS, o as SUPABASE_REST_URL, u as loadCatalog } from "./cms-CSbzslKe.mjs";
import { B as require_react, I as redirect, _ as Link, d as useRouterState, g as createRootRoute, h as createFileRoute, l as Scripts, m as lazyRouteComponent, p as createRouter, u as HeadContent, v as require_jsx_runtime, z as notFound } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as ChevronDown, O as ArrowLeft, f as MessageCircle, h as Mail, i as ShoppingBag, l as Phone, m as MapPin, p as Menu, t as X } from "../_libs/lucide-react.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-CH__uXky.js
/**
* BOM (﻿) ve boşluk temizliği şart: env değeri bazı kabuklardan BOM ile
* yazılabiliyor ve o hâlde `﻿https://…` göreli yol sayılıp tüm görseller
* 404 veriyor.
*/
var CDN_BASE = "https://luzayn.b-cdn.net".replace(/^﻿/, "").trim().replace(/\/+$/, "");
/**
* Tüm görsel/video kaynakları bu fonksiyondan geçmelidir — fallback <img>'ler dahil.
* CDN tanımlı değilse yol olduğu gibi döner (public/ altındaki yerel dosyalar için).
*/
function mediaUrl(path) {
	if (/^https?:\/\//.test(path)) return path;
	return `${CDN_BASE}${path.startsWith("/") ? path : `/${path}`}`;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatPrice(value) {
	return new Intl.NumberFormat("tr-TR", {
		style: "currency",
		currency: "TRY",
		maximumFractionDigits: 0
	}).format(value);
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/track-CFw7LNHG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/**
* Çerez onayı — analitik betikleri YALNIZCA onay verildikten sonra yüklenir.
*
* Çerez Politikası sayfası "analitik çerezler yalnızca onayınızla çalışır"
* diyor; bu dosya o sözü teknik olarak tutar. Zorunlu çerezler (sepet)
* onaydan bağımsızdır, zaten localStorage'da tutuluyor.
*/
var KEY = "luzayn-consent";
function readConsent() {
	if (typeof window === "undefined") return null;
	const raw = window.localStorage.getItem(KEY);
	return raw === "accepted" || raw === "rejected" ? raw : null;
}
function writeConsent(value) {
	window.localStorage.setItem(KEY, value);
	window.dispatchEvent(new CustomEvent("luzayn-consent", { detail: value }));
}
/**
* SSR'da her zaman null döner; karar yalnızca istemcide okunur.
* Böylece sunucu ve ilk istemci render'ı aynı kalır (hydration uyuşmazlığı yok).
*/
function useConsent() {
	const [consent, setConsent] = (0, import_react.useState)(null);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setConsent(readConsent());
		setReady(true);
		const onChange = (e) => {
			setConsent(e.detail);
		};
		window.addEventListener("luzayn-consent", onChange);
		return () => window.removeEventListener("luzayn-consent", onChange);
	}, []);
	return {
		consent,
		ready
	};
}
/**
* Buton/olay ölçümü — yönetim panelindeki "Olaylar" ekranını besleyen taraf.
*
* TOPLU GÖNDERİM ŞART. Her tıklamada tek istek atmak, ölçmek istediğimiz
* etkileşimin kendisini yavaşlatır. Olaylar bir tampona yazılıyor ve
* aşağıdaki üç durumdan biriyle boşaltılıyor: zamanlayıcı, tampon dolması,
* sekmenin gizlenmesi.
*
* ZAMAN PENCERESİ TASARIMI BELİRLİYOR. `ui_events` üzerindeki insert
* politikası occurred_at'i `now() - 5 dakika` ile `now() + 1 dakika` arasına
* kilitliyor (geçmişe sahte sayı yazılmasın diye). Bu yüzden:
*
*   1. occurred_at'i BİZ GÖNDERMİYORUZ — veritabanının `now()` varsayılanı
*      kullanılıyor, yani kontrol her zaman geçer.
*   2. Tampon süresi kısa tutuluyor. Özet gün bazında toplandığı için
*      tıklama ile yazma arasındaki saniyeler zaten önemsiz; önemli olan
*      olayın kaybolmaması.
*
* ONAY KAPISI. Bu bir analitik ölçüm ve Çerez Politikası sayfası "analitik
* yalnızca onayınızla çalışır" diyor. Onay verilmemişse hiçbir şey
* gönderilmez — o sözü teknik olarak tutmayan bir ölçüm, sayfayı yanlış
* beyana çevirir.
*/
var FLUSH_MS = 5e3;
var BUFFER_LIMIT = 20;
/** name kolonu 60, path 200 karakterle sınırlı; kırpma burada yapılıyor. */
var NAME_MAX = 60;
var PATH_MAX = 200;
var buffer = [];
var timer = null;
var listenersBound = false;
function canTrack() {
	return typeof window !== "undefined" && Boolean(SUPABASE_REST_URL) && readConsent() === "accepted";
}
/**
* Tamponu boşaltır.
*
* keepalive: sekme kapanırken bile isteğin tamamlanmasını sağlar. sendBeacon
* da bunu yapardı ama başlık geçirmeye izin vermiyor ve PostgREST apikey
* başlığı istiyor.
*
* Hata YUTULUYOR ve tekrar denenmiyor. Ölçüm kaybı kabul edilebilir; ölçüm
* yüzünden konsolu kirletmek veya arayüzü bekletmek değil.
*/
function flush() {
	if (timer !== null) {
		clearTimeout(timer);
		timer = null;
	}
	if (buffer.length === 0) return;
	const rows = buffer;
	buffer = [];
	try {
		fetch(`${SUPABASE_REST_URL}/ui_events`, {
			method: "POST",
			keepalive: true,
			headers: {
				"Content-Type": "application/json",
				apikey: SUPABASE_ANON_KEY,
				Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
				Prefer: "return=minimal"
			},
			body: JSON.stringify(rows)
		}).catch(() => {});
	} catch {}
}
function bindListeners() {
	if (listenersBound || typeof document === "undefined") return;
	listenersBound = true;
	document.addEventListener("visibilitychange", () => {
		if (document.visibilityState === "hidden") flush();
	});
	window.addEventListener("pagehide", flush);
}
/**
* Bir olayı kuyruğa alır.
*
* @param name  Kısa, sabit bir ad ("add_to_cart"). Panel bu ada göre grupluyor,
*              yani sonradan değiştirmek geçmişi ikiye böler.
* @param path  Olayın geçtiği yol. Verilmezse o anki adres kullanılır —
*              aynı düğmenin hangi sayfada tıklandığını ayırt etmeyi sağlar.
*/
function trackEvent(name, path) {
	if (!canTrack()) return;
	bindListeners();
	buffer.push({
		name: name.trim().slice(0, NAME_MAX),
		path: (path ?? window.location.pathname).slice(0, PATH_MAX)
	});
	if (buffer.length >= BUFFER_LIMIT) {
		flush();
		return;
	}
	if (timer === null) timer = setTimeout(flush, FLUSH_MS);
}
/** Panelin 404 monitörünü besleyen olay. Adı şemayla sabit: "not_found". */
function trackNotFound(path) {
	trackEvent("not_found", path);
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-D6WmJc6q.js
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var styles_default = "/assets/styles-CSusYjYM.css";
/**
* Logo CDN'de. null yapılırsa ambalajdaki kelime markası kilidi render edilir
* (Wordmark). Her iki durumda da kaynak mediaUrl()'den geçer.
*/
var LOGO_FILE = "/logo.png";
function Logo({ inverted = false, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: mediaUrl(LOGO_FILE),
		alt: "Luzayn",
		className: cn("h-7 w-auto md:h-8", inverted && "brightness-0 invert", className)
	});
}
/**
* Katalog okunamadığında sitenin tamamını düşürmemek için boş katalog.
*
* Kök route'ta hata fırlatmak, Supabase'in bir dakikalık kesintisinde
* iletişim ve yasal sayfaları da kapatırdı. Bunun yerine katalog boş kalıyor
* ve ekranda görünür bir uyarı çıkıyor — SESSİZCE boş göstermek daha
* kötüsü olurdu: "ürünlerimiz tükendi" gibi okunur.
*/
var EMPTY_CATALOG = {
	products: [],
	bySlug: {},
	categories: [],
	featured: [],
	commerce: {
		freeShippingThreshold: null,
		standardShippingFee: 0,
		returnDays: 14
	},
	bundle: {
		name: "",
		tagline: "",
		slugs: [],
		discountRate: 0
	}
};
var CatalogContext = (0, import_react.createContext)(null);
function CatalogProvider({ value, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatalogContext.Provider, {
		value,
		children
	});
}
function useCatalogState() {
	const state = (0, import_react.useContext)(CatalogContext);
	if (!state) throw new Error("useCatalog yalnızca CatalogProvider içinde çağrılabilir. Sağlayıcı kök route’ta (__root.tsx) kuruluyor.");
	return state;
}
function useCatalog() {
	return useCatalogState().catalog;
}
function useScrolled(threshold = 80) {
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > threshold);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, [threshold]);
	return scrolled;
}
var MAX_QTY = 20;
var useCart = create()(persist((set) => ({
	lines: [],
	add: (slug, qty = 1) => set((state) => {
		if (!state.lines.find((l) => l.slug === slug)) return { lines: [...state.lines, {
			slug,
			qty
		}] };
		return { lines: state.lines.map((l) => l.slug === slug ? {
			...l,
			qty: Math.min(MAX_QTY, l.qty + qty)
		} : l) };
	}),
	setQty: (slug, qty) => set((state) => ({ lines: qty <= 0 ? state.lines.filter((l) => l.slug !== slug) : state.lines.map((l) => l.slug === slug ? {
		...l,
		qty: Math.min(MAX_QTY, qty)
	} : l) })),
	remove: (slug) => set((state) => ({ lines: state.lines.filter((l) => l.slug !== slug) })),
	clear: () => set({ lines: [] })
}), {
	name: "luzayn-cart",
	storage: createJSONStorage(() => localStorage),
	skipHydration: true,
	/**
	* Katalog artık veritabanından geliyor ve hydration anında elimizde
	* OLMUYOR — bu yüzden burada slug doğrulaması yapılamıyor. Bilinmeyen
	* slug'lar resolveCart() içinde düşürülüyor: orada katalog var.
	*
	* Pratik sonucu aynı: kaldırılmış bir ürün sepette görünmez. Farkı,
	* localStorage'da satırın durmaya devam etmesi — zararsız.
	*/
	merge: (persisted, current) => {
		const saved = persisted?.lines ?? [];
		return {
			...current,
			lines: saved.filter((l) => l.qty > 0)
		};
	}
}));
/**
* SSR ile istemci ilk render'ı aynı olmalı; sepet yalnızca hydration
* tamamlandıktan sonra gerçek değerini gösterir. Bu hook'u sepet sayısı,
* sepet sayfası gibi persist verisine bağlı her yerde kullanın.
*/
function useCartHydrated() {
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		useCart.persist.rehydrate();
		setHydrated(true);
	}, []);
	return hydrated;
}
/**
* Sepet matematiği.
*
* `shipping` null olabilir: Shopify'da ücretsiz kargo eşiği tanımlı değil ve
* müşteri Standart/Hızlı seçimini checkout'ta yapıyor. Bu durumda sepette
* kargo tutarı gösterilmez, "ödeme adımında hesaplanır" denir — sitede
* gerçekleşmeyecek bir toplam göstermemek için.
*/
/**
* Sepet satırlarını katalogla eşleştirip tutarları hesaplar.
*
* Katalog PARAMETRE olarak geliyor, modülden okunmuyor: fiyatlar artık
* veritabanından ve zustand store'u asenkron veri bekleyemez. Çağıran taraf
* katalogu bağlamdan alıp veriyor.
*/
function resolveCart(catalog, lines) {
	const items = lines.flatMap((line) => {
		const product = catalog.bySlug[line.slug];
		if (!product) return [];
		return [{
			product,
			qty: line.qty,
			lineTotal: product.price * line.qty
		}];
	});
	const subtotal = items.reduce((sum, item) => sum + item.lineTotal, 0);
	const count = items.reduce((sum, item) => sum + item.qty, 0);
	const threshold = catalog.commerce.freeShippingThreshold;
	if (threshold === null) return {
		items,
		count,
		subtotal,
		shipping: null,
		total: subtotal,
		freeShipping: false,
		remainingForFreeShipping: 0,
		shippingKnown: false
	};
	const freeShipping = subtotal >= threshold;
	const shipping = items.length === 0 || freeShipping ? 0 : catalog.commerce.standardShippingFee;
	return {
		items,
		count,
		subtotal,
		shipping,
		total: subtotal + shipping,
		freeShipping,
		remainingForFreeShipping: Math.max(0, threshold - subtotal),
		shippingKnown: true
	};
}
/**
* Menü artık katalogdan kuruluyor, o yüzden modül seviyesinde sabit olamaz:
* ürünler istek anında veritabanından geliyor.
*/
function buildNav(products) {
	return [
		{
			label: "Ürünler",
			to: "/urunler",
			childPattern: "/urunler/$slug",
			children: products.map((p) => ({
				label: p.shortName,
				slug: p.slug,
				accent: p.accent,
				hint: p.subtitle,
				image: p.cover
			}))
		},
		{
			label: "Kurumsal",
			to: "/kurumsal"
		},
		{
			label: "Blog",
			to: "/blog"
		},
		{
			label: "İletişim",
			to: "/iletisim"
		}
	];
}
function Header() {
	const { products } = useCatalog();
	const NAV = (0, import_react.useMemo)(() => buildNav(products), [products]);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const isHome = pathname === "/";
	const scrolled = useScrolled(80);
	const [openDropdown, setOpenDropdown] = (0, import_react.useState)(null);
	const [mobileOpen, setMobileOpen] = (0, import_react.useState)(false);
	const [mobileSection, setMobileSection] = (0, import_react.useState)(null);
	const navRef = (0, import_react.useRef)(null);
	const transparent = isHome && !scrolled;
	(0, import_react.useEffect)(() => {
		setMobileOpen(false);
		setOpenDropdown(null);
	}, [pathname]);
	(0, import_react.useEffect)(() => {
		if (!openDropdown) return;
		const onClick = (e) => {
			if (navRef.current && !navRef.current.contains(e.target)) setOpenDropdown(null);
		};
		document.addEventListener("mousedown", onClick);
		return () => document.removeEventListener("mousedown", onClick);
	}, [openDropdown]);
	(0, import_react.useEffect)(() => {
		document.body.style.overflow = mobileOpen ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [mobileOpen]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: cn("z-50 w-full transition-all duration-300", isHome ? "fixed top-0 left-0" : "sticky top-0", transparent ? "bg-transparent" : "border-b border-border bg-white/90 backdrop-blur-md"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container mx-auto flex h-16 items-center justify-between gap-4 px-4 md:h-18",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "shrink-0",
					"aria-label": "Luzayn ana sayfa",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { inverted: transparent })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					ref: navRef,
					className: "hidden items-center gap-1 lg:flex",
					children: NAV.map((item) => item.children ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: cn("flex items-center rounded-full transition-colors", transparent ? "hover:bg-white/10" : "hover:bg-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: item.to,
								className: cn("py-2 pl-3.5 pr-1 text-sm font-medium transition-colors", transparent ? "text-white/85 hover:text-white" : "text-foreground/75 hover:text-foreground"),
								children: item.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setOpenDropdown(openDropdown === item.to ? null : item.to),
								"aria-expanded": openDropdown === item.to,
								"aria-label": `${item.label} alt menüsü`,
								className: cn("py-2 pl-0.5 pr-3 transition-colors", transparent ? "text-white/70 hover:text-white" : "text-foreground/60 hover:text-foreground"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("h-3.5 w-3.5 transition-transform", openDropdown === item.to && "rotate-180") })
							})]
						}), openDropdown === item.to ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute left-0 top-full mt-2 grid w-[34rem] grid-cols-2 gap-0.5 animate-[showcase-fade-in_0.18s_ease-out] rounded-2xl border border-border bg-white p-2 shadow-xl shadow-black/5",
							children: [item.children.map((child) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.childPattern,
								params: { slug: child.slug },
								className: "flex items-center gap-3 rounded-xl p-2 transition-colors hover:bg-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: mediaUrl(child.image),
									alt: "",
									"aria-hidden": true,
									loading: "lazy",
									className: "h-12 w-12 shrink-0 rounded-lg object-cover",
									style: { boxShadow: `inset 0 0 0 1px ${child.accent}30` }
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-sm font-medium text-foreground",
										children: child.label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-xs text-muted-foreground",
										children: child.hint
									})]
								})]
							}, child.slug)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: item.to,
								className: "col-span-2 mt-1 block rounded-xl px-3 py-2 text-xs font-semibold uppercase tracking-wider text-accent hover:bg-muted",
								children: "Tümünü Gör"
							})]
						}) : null]
					}, item.to) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						className: cn("rounded-full px-3.5 py-2 text-sm font-medium transition-colors", transparent ? "text-white/85 hover:bg-white/10 hover:text-white" : "text-foreground/75 hover:bg-muted hover:text-foreground"),
						children: item.label
					}, item.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartButton, { transparent }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/urunler",
							className: cn("hidden rounded-full px-5 py-2.5 text-sm font-semibold shadow-lg transition-transform hover:scale-105 sm:inline-flex", transparent ? "bg-white text-black shadow-black/20" : "bg-accent text-white shadow-accent/25"),
							children: "Ürünleri Keşfet"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setMobileOpen((v) => !v),
							"aria-label": mobileOpen ? "Menüyü kapat" : "Menüyü aç",
							className: cn("inline-flex h-10 w-10 items-center justify-center rounded-full transition-colors lg:hidden", transparent ? "text-white hover:bg-white/10" : "text-foreground hover:bg-muted"),
							children: mobileOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-5 w-5" })
						})
					]
				})
			]
		})
	}), mobileOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-x-0 top-16 bottom-0 z-50 animate-[showcase-fade-in_0.2s_ease-out] overflow-y-auto border-t border-border bg-white px-4 pb-10 pt-4 lg:hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "flex flex-col",
			children: NAV.map((item) => item.children ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-b border-border/70",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						className: "flex-1 py-4 text-base font-medium text-foreground",
						children: item.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setMobileSection(mobileSection === item.to ? null : item.to),
						"aria-expanded": mobileSection === item.to,
						"aria-label": `${item.label} alt menüsü`,
						className: "-mr-2 p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("h-4 w-4 text-muted-foreground transition-transform", mobileSection === item.to && "rotate-180") })
					})]
				}), mobileSection === item.to ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pb-3",
					children: [item.children.map((child) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: item.childPattern,
						params: { slug: child.slug },
						className: "flex items-center gap-3 py-2 text-sm text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: mediaUrl(child.image),
							alt: "",
							"aria-hidden": true,
							loading: "lazy",
							className: "h-9 w-9 shrink-0 rounded-lg object-cover",
							style: { boxShadow: `inset 0 0 0 1px ${child.accent}30` }
						}), child.label]
					}, child.slug)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						className: "block py-2.5 text-xs font-semibold uppercase tracking-wider text-accent",
						children: "Tümünü Gör"
					})]
				}) : null]
			}, item.to) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: item.to,
				className: "border-b border-border/70 py-4 text-base font-medium text-foreground",
				children: item.label
			}, item.to))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/urunler",
			className: "mt-6 block rounded-full bg-accent px-6 py-3.5 text-center text-sm font-semibold text-white shadow-lg shadow-accent/25",
			children: "Ürünleri Keşfet"
		})]
	}) : null] });
}
function CartButton({ transparent }) {
	const catalog = useCatalog();
	const hydrated = useCartHydrated();
	const lines = useCart((s) => s.lines);
	const count = hydrated ? resolveCart(catalog, lines).count : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/sepet",
		"aria-label": count > 0 ? `Sepet — ${count} ürün` : "Sepet",
		className: cn("relative inline-flex h-10 w-10 items-center justify-center rounded-full transition-colors", transparent ? "text-white hover:bg-white/10" : "text-foreground hover:bg-muted"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "h-5 w-5" }), count > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute -right-0.5 -top-0.5 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-accent px-1 text-[11px] font-semibold text-white",
			children: count
		}) : null]
	});
}
/**
* Satıcı künyesi. Doğrulanmamış alanlar BOŞ bırakılır ve listeye hiç
* girmez — canlı bir ticari sayfada yer tutucu metin göstermeyiz.
* Eksik kalanlar mevzuat açısından hâlâ tamamlanmalıdır.
*/
var SELLER_BLOCK = [
	`Unvan: ${SITE.legalName}`,
	`Adres: ${SITE.fullAddress}`,
	`E-posta: ${SITE.email}`,
	`Telefon: ${SITE.phone}`,
	SITE.mersis ? `MERSİS No: ${SITE.mersis}` : null,
	SITE.taxOffice && SITE.taxNumber ? `Vergi Dairesi / No: ${SITE.taxOffice} / ${SITE.taxNumber}` : null
].filter((line) => line !== null);
/**
* Yasal sayfa metinleri.
*
* Kargo bedeli ve iade süresi metnin İÇİNDE geçiyor ve bu değerler artık
* yönetim panelinden yönetiliyor. Bu yüzden sayfalar modül seviyesinde sabit
* olamaz: ticari ayar parametre olarak geliyor ki mesafeli satış sözleşmesi
* ile sepetteki rakam ayrışmasın.
*/
function buildLegalPages(commerce) {
	return [
		{
			slug: "gizlilik",
			title: "Gizlilik Politikası",
			intro: "Bu politika, luzayn.com üzerinden topladığımız kişisel verilerin hangi amaçlarla işlendiğini ve nasıl korunduğunu açıklar.",
			sections: [
				{
					heading: "Veri sorumlusu",
					body: SELLER_BLOCK
				},
				{
					heading: "Toplanan veriler",
					body: [
						"Sipariş sürecinde: ad, soyad, e-posta, telefon, teslimat ve fatura adresi, T.C. kimlik numarası (fatura ve ödeme mevzuatı gereği).",
						"İletişim formunda: ad, e-posta, telefon (isteğe bağlı) ve mesaj içeriği.",
						"Teknik olarak: IP adresi, tarayıcı bilgisi ve sitede gezinme kayıtları.",
						"Ödeme kartı bilgileri tarafımızca görülmez ve saklanmaz; ödeme, iyzico altyapısı üzerinden alınır."
					]
				},
				{
					heading: "İşleme amaçları",
					body: [
						"Siparişin oluşturulması, ödemenin alınması, faturalandırma ve teslimatın sağlanması.",
						"İletişim taleplerinin yanıtlanması.",
						"Yasal saklama ve bilgi verme yükümlülüklerinin yerine getirilmesi."
					]
				},
				{
					heading: "Aktarım",
					body: ["Veriler yalnızca hizmetin sağlanması için gerekli olan ölçüde; ödeme kuruluşu (iyzico), kargo firması, muhasebe ve e-posta altyapısı sağlayıcılarıyla paylaşılır.", "Yasal olarak yetkili kamu kurumlarının talepleri saklıdır."]
				},
				{
					heading: "Saklama süresi",
					body: ["Sipariş ve fatura verileri, ilgili mevzuatın öngördüğü süre boyunca saklanır.", "İletişim formu kayıtları, talebin sonuçlanmasının ardından makul bir süre içinde silinir."]
				},
				{
					heading: "Haklarınız",
					body: [`6698 sayılı KVKK kapsamındaki haklarınızı kullanmak için ${SITE.email} adresine yazabilirsiniz. Ayrıntı için KVKK Aydınlatma Metni sayfasına bakın.`]
				}
			]
		},
		{
			slug: "kullanim-kosullari",
			title: "Kullanım Koşulları",
			intro: "luzayn.com’u kullanarak aşağıdaki koşulları kabul etmiş olursunuz.",
			sections: [
				{
					heading: "Sitenin amacı",
					body: ["Bu site, takviye edici gıda ürünlerinin tanıtımı ve satışı için kullanılır.", "Sitedeki içerikler bilgilendirme amaçlıdır; tıbbi tavsiye, teşhis veya tedavi yerine geçmez. Sağlığınızla ilgili kararlar için hekiminize danışın."]
				},
				{
					heading: "İçerik ve fikri mülkiyet",
					body: ["Sitedeki metin, görsel, video ve tasarım unsurları üzerindeki haklar saklıdır; izinsiz kopyalanamaz ve çoğaltılamaz."]
				},
				{
					heading: "Ürün bilgileri",
					body: ["Ürün açıklamalarındaki bileşen ve miktar bilgileri ambalaj üzerindeki bilgilere dayanır. Ambalaj bilgisi ile site bilgisi arasında farklılık olması hâlinde ambalaj esas alınır.", "Fiyatlar ve stok durumu önceden bildirilmeksizin değiştirilebilir. Sipariş anında geçerli olan fiyat uygulanır."]
				},
				{
					heading: "Sorumluluk",
					body: ["Ürünler tavsiye edilen porsiyonda kullanılmak üzere sunulur. Tavsiye edilen porsiyonun aşılması veya ambalajdaki uyarılara uyulmaması hâlinde doğabilecek sonuçlardan kullanıcı sorumludur."]
				}
			]
		},
		{
			slug: "mesafeli-satis",
			title: "Mesafeli Satış Sözleşmesi",
			intro: "6502 sayılı Tüketicinin Korunması Hakkında Kanun ve Mesafeli Sözleşmeler Yönetmeliği uyarınca düzenlenmiştir.",
			sections: [
				{
					heading: "Satıcı bilgileri",
					body: SELLER_BLOCK
				},
				{
					heading: "Sözleşmenin konusu",
					body: ["İşbu sözleşme, alıcının luzayn.com üzerinden elektronik ortamda sipariş verdiği ürünlerin satışı ve teslimine ilişkin tarafların hak ve yükümlülüklerini düzenler.", "Siparişe konu ürünlerin adı, adedi, satış fiyatı ve teslimat bilgileri sipariş özetinde ve fatura üzerinde yer alır."]
				},
				{
					heading: "Ödeme",
					body: ["Ödeme, Shopify ödeme sayfası üzerinden iyzico altyapısıyla kredi/banka kartı ile alınır. Kart bilgileri satıcı tarafından görülmez ve saklanmaz."]
				},
				{
					heading: "Teslimat",
					body: [`Kargo ücreti, seçilen teslimat yöntemine göre ödeme adımında hesaplanır ve sipariş özetinde gösterilir. Yurt içi standart teslimat ücreti ${commerce.standardShippingFee} TL'dir.`, "Ürün, sipariş onayının ardından anlaşmalı kargo firmasına teslim edilir. Teslimat süresi kargo firmasının bölgeye göre değişen takvimine bağlıdır."]
				},
				{
					heading: "Cayma hakkı",
					body: [
						`Alıcı, teslimattan itibaren ${commerce.returnDays} gün içinde hiçbir gerekçe göstermeksizin cayma hakkını kullanabilir.`,
						"Cayma hakkı, ambalajı açılmamış, kullanılmamış ve yeniden satılabilir durumdaki ürünler için geçerlidir.",
						"Mesafeli Sözleşmeler Yönetmeliği’nin 15. maddesi uyarınca, tesliminden sonra ambalajı açılmış olan ve sağlık ile hijyen açısından iadesi uygun olmayan ürünlerde cayma hakkı kullanılamaz.",
						`Cayma bildirimi ${SITE.email} adresine yapılabilir.`
					]
				},
				{
					heading: "Uyuşmazlık",
					body: ["Uyuşmazlıklarda, Ticaret Bakanlığı’nca ilan edilen parasal sınırlar çerçevesinde alıcının yerleşim yerindeki Tüketici Hakem Heyetleri ve Tüketici Mahkemeleri yetkilidir."]
				}
			]
		},
		{
			slug: "kvkk",
			title: "KVKK Aydınlatma Metni",
			intro: "6698 sayılı Kişisel Verilerin Korunması Kanunu’nun 10. maddesi kapsamında hazırlanmıştır.",
			sections: [
				{
					heading: "Veri sorumlusunun kimliği",
					body: SELLER_BLOCK
				},
				{
					heading: "İşleme amacı ve hukuki sebep",
					body: ["Kişisel verileriniz; sözleşmenin kurulması ve ifası (KVKK m.5/2-c), hukuki yükümlülüğün yerine getirilmesi (m.5/2-ç) ve meşru menfaat (m.5/2-f) hukuki sebeplerine dayanılarak işlenir.", "Pazarlama amaçlı iletişim yalnızca açık rızanız bulunması hâlinde yapılır."]
				},
				{
					heading: "Toplama yöntemi",
					body: ["Veriler; sipariş formu, iletişim formu ve site kullanımınız sırasında elektronik ortamda otomatik ve kısmen otomatik yollarla toplanır."]
				},
				{
					heading: "İlgili kişinin hakları",
					body: ["Kanun’un 11. maddesi uyarınca; verilerinizin işlenip işlenmediğini öğrenme, bilgi talep etme, işlenme amacını öğrenme, düzeltilmesini veya silinmesini isteme, aktarıldığı üçüncü kişileri bilme ve zararın giderilmesini talep etme haklarına sahipsiniz.", `Başvurularınızı ${SITE.email} adresine iletebilirsiniz. Başvurular en geç 30 gün içinde sonuçlandırılır.`]
				}
			]
		},
		{
			slug: "cerez-politikasi",
			title: "Çerez Politikası",
			intro: "Bu politika, luzayn.com’da kullanılan çerezleri ve tercihlerinizi nasıl yönetebileceğinizi açıklar.",
			sections: [
				{
					heading: "Kullanılan çerezler",
					body: [
						"Zorunlu çerezler: sepetinizin ve oturumunuzun çalışması için gereklidir; devre dışı bırakılamaz.",
						"Tercih çerezleri: dil ve görünüm gibi seçimlerinizi hatırlar.",
						"Analitik çerezler: sitenin nasıl kullanıldığını anlamamıza yardımcı olur ve yalnızca onayınızla çalışır."
					]
				},
				{
					heading: "Sepet verisi",
					body: ["Sepetiniz tarayıcınızın yerel depolamasında (localStorage) tutulur; sunucuya gönderilmez. Tarayıcı verilerinizi temizlediğinizde sepet de silinir."]
				},
				{
					heading: "Tercihlerinizi yönetme",
					body: ["Tarayıcı ayarlarınızdan çerezleri silebilir veya engelleyebilirsiniz. Zorunlu çerezleri engellemeniz hâlinde sepet ve ödeme adımları çalışmayabilir."]
				}
			]
		},
		{
			slug: "kargo-ve-teslimat",
			title: "Kargo ve Teslimat",
			intro: "Siparişinizin hazırlanması ve size ulaşması hakkında bilmeniz gerekenler.",
			sections: [
				{
					heading: "Hazırlama süresi",
					body: ["Saat 15:00’e kadar verilen ve ödemesi onaylanan siparişler aynı iş günü içinde hazırlanır. Hafta sonu ve resmî tatillerde verilen siparişler takip eden ilk iş gününde işleme alınır."]
				},
				{
					heading: "Kargo ücreti",
					body: [`Yurt içi standart teslimat ücreti ${commerce.standardShippingFee} TL'dir. Hızlı teslimat seçeneği farklı ücretlendirilir.`, "Geçerli kargo ücreti, teslimat adresiniz ve seçtiğiniz yöntem belirlendikten sonra ödeme adımında gösterilir."]
				},
				{
					heading: "Teslimat",
					body: ["Teslimat, anlaşmalı kargo firması aracılığıyla belirttiğiniz adrese yapılır. Teslimat süresi bölgeye göre değişir.", "Teslim alırken paketi kargo görevlisinin yanında kontrol edin. Hasarlı paketlerde tutanak tutturarak teslim almayın ve bizimle iletişime geçin."]
				},
				{
					heading: "İade",
					body: [`Ambalajı açılmamış ürünler için ${commerce.returnDays} gün içinde iade hakkınız vardır. Ambalajı açılmış takviye edici gıdalar, hijyen gerekçesiyle iade kapsamı dışındadır.`, `İade talebiniz için ${SITE.email} adresine sipariş numaranızla yazın.`]
				}
			]
		},
		{
			slug: "siparis-takibi",
			title: "Sipariş Takibi",
			intro: "Siparişinizin durumunu nasıl öğrenebileceğinizi anlatır.",
			sections: [
				{
					heading: "Sipariş referansınız",
					body: ["Ödeme tamamlandığında ekranda ve e-postanızda bir sipariş referansı görürsünüz. Tüm yazışmalarda bu referansı belirtin."]
				},
				{
					heading: "Kargo takip numarası",
					body: ["Siparişiniz kargoya verildiğinde takip numarası e-posta ile iletilir. Numarayı kargo firmasının sitesinde sorgulayabilirsiniz."]
				},
				{
					heading: "Yardım",
					body: [`Siparişinizle ilgili her konuda ${SITE.email} adresinden veya iletişim sayfasındaki formdan bize ulaşabilirsiniz.`]
				}
			]
		}
	];
}
var LEGAL_NAV = buildLegalPages({
	freeShippingThreshold: null,
	standardShippingFee: 0,
	returnDays: 0
}).map(({ slug, title }) => ({
	slug,
	title
}));
function Footer() {
	const { products } = useCatalog();
	const year = (/* @__PURE__ */ new Date()).getFullYear();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "relative overflow-hidden bg-[#0a0a12] text-white",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "pointer-events-none absolute -left-24 -top-24 h-72 w-72 rounded-full bg-accent/20 blur-[120px]"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "pointer-events-none absolute -bottom-32 right-0 h-80 w-80 rounded-full bg-accent-soft/15 blur-[120px]"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container relative mx-auto px-4 py-16 md:py-20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-12 md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {
									inverted: true,
									className: "h-9 md:h-10"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 max-w-sm text-sm leading-relaxed text-white/60",
									children: SITE.description
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
									className: "mt-6 space-y-2.5 text-sm text-white/60",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex items-start gap-2.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 h-4 w-4 shrink-0 text-white/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: SITE.fullAddress })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex items-center gap-2.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4 shrink-0 text-white/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												href: `mailto:${SITE.email}`,
												className: "hover:text-white",
												children: SITE.email
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex items-center gap-2.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-4 w-4 shrink-0 text-white/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												href: `tel:${SITE.phone.replace(/\s/g, "")}`,
												className: "hover:text-white",
												children: SITE.phone
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: SITE.social.instagram,
									target: "_blank",
									rel: "noopener noreferrer",
									className: "mt-6 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-4 py-2 text-sm text-white/70 transition-colors hover:bg-white/10 hover:text-white",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstagramGlyph, {}), "@luzayntr"]
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterColumn, {
								title: "Ürünler",
								children: products.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/urunler/$slug",
									params: { slug: p.slug },
									className: "flex items-center gap-2 py-1 text-white/60 transition-colors hover:text-white",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "h-1.5 w-1.5 shrink-0 rounded-full",
										style: { backgroundColor: p.accent }
									}), p.shortName]
								}) }, p.slug))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FooterColumn, {
								title: "Kurumsal",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterLink, {
										to: "/kurumsal",
										children: "Hakkımızda"
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterLink, {
										to: "/urunler",
										children: "Tüm Ürünler"
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterLink, {
										to: "/blog",
										children: "Blog"
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterLink, {
										to: "/iletisim",
										children: "İletişim"
									}) })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterColumn, {
								title: "Yasal",
								children: LEGAL_NAV.map((page) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/yasal/$slug",
									params: { slug: page.slug },
									className: "block py-1 text-white/60 transition-colors hover:text-white",
									children: page.title
								}) }, page.slug))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-12 flex flex-wrap items-center gap-2.5 border-t border-white/10 pt-8",
						children: [CERTIFICATIONS.map((cert) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							title: cert.label,
							className: "rounded-full border border-white/10 bg-white/[0.04] px-3.5 py-1.5 text-[11px] font-medium uppercase tracking-wider text-white/60 backdrop-blur-md",
							children: cert.code
						}, cert.code)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-full border border-white/10 bg-white/[0.04] px-3.5 py-1.5 text-[11px] font-medium uppercase tracking-wider text-white/60 backdrop-blur-md",
							children: ["Menşei: ", SITE.origin]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-8 text-xs leading-relaxed text-white/40",
						children: "Takviye edici gıdalar normal beslenmenin yerine geçmez; hastalıkların önlenmesi veya tedavisi amacıyla kullanılmaz. Tavsiye edilen günlük porsiyonu aşmayınız. Hamilelik ve emzirme döneminde, ilaç kullanımında veya kronik rahatsızlık varlığında hekiminize danışınız."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-col gap-2 border-t border-white/10 pt-6 text-xs text-white/40 sm:flex-row sm:items-center sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"© ",
							year,
							" ",
							SITE.legalName
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Tüm hakları saklıdır." })]
					})
				]
			})
		]
	});
}
function FooterColumn({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: "text-[11px] font-semibold uppercase tracking-[0.2em] text-white/40",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-4 space-y-0.5 text-sm",
		children
	})] });
}
function FooterLink({ to, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to,
		className: "block py-1 text-white/60 transition-colors hover:text-white",
		children
	});
}
/** lucide marka ikonlarını kaldırdı; Instagram glifi satır içi çizilir. */
function InstagramGlyph() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		"aria-hidden": true,
		className: "h-4 w-4",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "2",
				y: "2",
				width: "20",
				height: "20",
				rx: "5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "17.5",
				cy: "6.5",
				r: "1",
				fill: "currentColor",
				stroke: "none"
			})
		]
	});
}
/**
* WhatsApp numarası tanımlıysa doğrudan wa.me'ye, tanımlı değilse iletişim
* sayfasına gider — kırık bir wa.me linki üretmemek için.
*/
function FloatingContact() {
	const whatsapp = SITE.whatsapp;
	const hasWhatsapp = whatsapp.length > 0;
	const shared = "fixed bottom-5 right-5 z-40 inline-flex h-14 w-14 items-center justify-center rounded-full shadow-xl transition-transform hover:scale-110";
	if (hasWhatsapp) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href: `https://wa.me/${whatsapp}`,
		target: "_blank",
		rel: "noopener noreferrer",
		"aria-label": "WhatsApp'tan yazın",
		className: `${shared} bg-[#25D366] text-white shadow-[#25D366]/30`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-6 w-6" })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/iletisim",
		"aria-label": "İletişime geçin",
		className: `${shared} bg-accent text-white shadow-accent/30`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-6 w-6" })
	});
}
var PIXEL_ID = "";
/**
* Çerez onay bandı.
*
* Yalnızca izlenecek bir şey varken görünür: hiçbir analitik kimliği
* tanımlı değilse bant hiç çıkmaz — kullanıcıya onay soracak bir çerez
* yokken banner göstermek gereksiz sürtünmedir.
*
* Karar verilene kadar hiçbir analitik betik yüklenmez (bkz. analytics.tsx).
*/
function CookieConsent() {
	const { consent, ready } = useConsent();
	if (!ready || !Boolean(PIXEL_ID) || consent !== null) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "dialog",
		"aria-label": "Çerez tercihi",
		className: "fixed inset-x-0 bottom-0 z-50 animate-[showcase-rise-in_0.35s_ease-out] border-t border-white/10 bg-[#0a0a12]/95 backdrop-blur-md",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container mx-auto flex flex-col gap-4 px-4 py-5 md:flex-row md:items-center md:gap-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex-1 text-sm leading-relaxed text-white/70",
				children: [
					"Siteyi nasıl kullandığınızı anlamak için analitik çerezler kullanmak istiyoruz. Sepetin çalışması için gereken zorunlu çerezler her durumda aktiftir.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/yasal/$slug",
						params: { slug: "cerez-politikasi" },
						className: "font-medium text-accent hover:underline",
						children: "Çerez Politikası"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex shrink-0 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => writeConsent("rejected"),
					className: "rounded-full border border-white/15 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-white/10",
					children: "Yalnızca zorunlu"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => writeConsent("accepted"),
					className: "rounded-full bg-white px-5 py-2.5 text-sm font-semibold text-black transition-transform hover:scale-105",
					children: "Kabul et"
				})]
			})]
		})
	});
}
function Analytics() {
	const { consent } = useConsent();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const loaded = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (consent !== "accepted" || loaded.current) return;
		loaded.current = true;
	}, [consent]);
	(0, import_react.useEffect)(() => {
		if (consent !== "accepted") return;
	}, [pathname, consent]);
	return null;
}
function NotFoundPage() {
	(0, import_react.useEffect)(() => {
		trackNotFound();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		code: "404",
		title: "Aradığınız sayfa bulunamadı.",
		description: "Bağlantı taşınmış veya hiç var olmamış olabilir. Ürünlere göz atarak devam edebilirsiniz."
	});
}
function ErrorPage({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		code: "Hata",
		title: "Beklenmedik bir sorun oluştu.",
		description: error?.message ?? "Sayfa yüklenirken bir sorunla karşılaştık. Sayfayı yenilemeyi deneyebilirsiniz."
	});
}
function Shell({ code, title, description }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden bg-[#0a0a12] py-28 text-white md:py-36",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			"aria-hidden": true,
			className: "pointer-events-none absolute left-1/2 top-0 h-96 w-96 -translate-x-1/2 rounded-full bg-accent/20 blur-[120px]"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container relative mx-auto max-w-2xl px-4 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-semibold uppercase tracking-[0.35em] text-accent",
					children: code
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-5 text-3xl font-bold tracking-tight md:text-4xl",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-base leading-relaxed text-white/60",
					children: description
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-9 flex flex-wrap items-center justify-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "inline-flex items-center gap-2 rounded-full bg-white px-7 py-3.5 text-sm font-semibold text-black transition-transform hover:scale-105",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), "Ana Sayfa"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/urunler",
						className: "inline-flex items-center rounded-full border border-white/15 px-7 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-white/10",
						children: "Ürünler"
					})]
				})
			]
		})]
	});
}
var Route$12 = createRootRoute({
	/**
	* Katalog burada BİR KEZ okunur; başlık, altbilgi, ana sayfa ve ürün
	* sayfaları aynı veriyi bağlamdan alır.
	*
	* HATA YUTULUYOR ama SESSİZCE DEĞİL. Kök route'ta throw etmek, Supabase'in
	* kısa bir kesintisinde iletişim ve yasal sayfaları da kapatırdı. Bunun
	* yerine boş katalogla devam edip ekranda uyarı gösteriyoruz; ürün
	* sayfaları zaten 404'e düşer, yani yanlış fiyat gösterme riski yok.
	*/
	loader: async () => {
		try {
			return {
				catalog: await loadCatalog(),
				error: null
			};
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			console.error("[katalog] okunamadı:", message);
			return {
				catalog: EMPTY_CATALOG,
				error: message
			};
		}
	},
	staleTime: 6e4,
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: `${SITE.name} — ${SITE.tagline}` },
			{
				name: "description",
				content: SITE.description
			},
			{
				name: "theme-color",
				content: "#0a0a12"
			},
			{
				property: "og:site_name",
				content: SITE.name
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:title",
				content: `${SITE.name} — ${SITE.tagline}`
			},
			{
				property: "og:description",
				content: SITE.description
			},
			{
				property: "og:locale",
				content: "tr_TR"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				property: "og:image",
				content: "https://luzayn.b-cdn.net/medya-jpg/images/3lu.jpg"
			},
			{
				property: "og:image:width",
				content: "1024"
			},
			{
				property: "og:image:height",
				content: "572"
			},
			{
				property: "og:url",
				content: SITE.url
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				sizes: "48x48"
			},
			{
				rel: "icon",
				href: "/favicon-32.png",
				type: "image/png",
				sizes: "32x32"
			},
			{
				rel: "apple-touch-icon",
				href: "/apple-touch-icon.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Cinzel:wght@500;600&display=swap"
			}
		]
	}),
	shellComponent: RootDocument,
	notFoundComponent: NotFoundPage,
	errorComponent: ErrorPage
});
function RootDocument({ children }) {
	const { catalog, error } = Route$12.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "tr",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-background text-foreground antialiased",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatalogProvider, {
					value: {
						catalog,
						error
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-h-screen flex-col",
						children: [
							error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								role: "alert",
								className: "bg-amber-500 px-4 py-2 text-center text-sm font-medium text-black",
								children: "Ürün kataloğu şu anda yüklenemedi. Fiyat ve stok bilgisi eksik olabilir."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
								className: "flex-1",
								children
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FloatingContact, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CookieConsent, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Analytics, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
var $$splitComponentImporter$8 = () => import("./routes-4EoOg0-2.mjs");
var Route$11 = createFileRoute("/")({
	/**
	* Vitrin, SSS ve blog önizlemesi burada okunur.
	*
	* loadCatalog() kök route'ta da çağrılıyor ama ikinci bir sorgu açmıyor:
	* cms.ts kısa ömürlü bir önbellek tutuyor ve aynı promise'i döndürüyor.
	* Vitrin tabloları ürünün rengini, kapağını ve videosunu katalogdan
	* okuduğu için katalog burada da gerekli.
	*/
	loader: async () => {
		const catalog = await loadCatalog();
		const [home, faq, posts] = await Promise.all([
			loadHome(catalog),
			loadFaq(),
			loadBlogPosts()
		]);
		return {
			home,
			faq,
			posts
		};
	},
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
/**
* Dikkat eğrisi: heyecan → güven → detay → kanıt → dönüşüm.
* Koyu ve açık bölümler nöbetleşir; ritim scroll'da hissedilir.
*/
var $$splitComponentImporter$7 = () => import("./iletisim-B8FCjyek.mjs");
var Route$10 = createFileRoute("/iletisim")({
	loader: () => loadFaq(),
	head: () => ({ meta: [{ title: `İletişim — ${SITE.name}` }, {
		name: "description",
		content: "Ürünler, siparişler ve iş birlikleri için Luzayn ile iletişime geçin."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
/** Değeri boş olan satır hiç render edilmez — canlı sitede yer tutucu metin göstermeyiz. */
var $$splitComponentImporter$6 = () => import("./kurumsal-DFVYNwYr.mjs");
var Route$9 = createFileRoute("/kurumsal")({
	loader: async () => {
		const catalog = await loadCatalog();
		const { philosophy } = await loadHome(catalog);
		return { philosophy };
	},
	head: () => ({ meta: [{ title: `Kurumsal — ${SITE.name}` }, {
		name: "description",
		content: `${SITE.legalName} hakkında: üretim yaklaşımı, kalite belgeleri ve etiket şeffaflığı ilkesi.`
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
/**
* /robots.txt — statik dosya yerine rota, çünkü sitemap adresi SITE.url'den
* türüyor. Alan adı luzayn.com'a taşındığında burası kendiliğinden doğru olur.
*
* Sepet ve ödeme adımları indekslenmez: içerik değeri yok, kullanıcıya özel.
*/
var Route$8 = createFileRoute("/robots.txt")({ server: { handlers: { GET: () => new Response([
	"User-agent: *",
	"Allow: /",
	"Disallow: /sepet",
	"Disallow: /odeme",
	"",
	`Sitemap: ${SITE.url}/sitemap.xml`,
	""
].join("\n"), { headers: {
	"Content-Type": "text/plain; charset=utf-8",
	"Cache-Control": "public, max-age=3600"
} }) } } });
var $$splitComponentImporter$5 = () => import("./sepet-Cj8fZ6NO.mjs");
var Route$7 = createFileRoute("/sepet")({
	head: () => ({ meta: [{ title: `Sepet — ${SITE.name}` }] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
/**
* Site haritası artık veritabanından üretiliyor.
*
* Bunun görünmeyen ama önemli sonucu: panelden taslağa alınan bir ürün veya
* yazı haritadan da düşer. Statik listeyle, yayından kaldırılan bir sayfayı
* arama motorlarına önermeye devam ederdik.
*/
async function buildEntries() {
	const [catalog, posts] = await Promise.all([loadCatalog(), loadBlogPosts()]);
	return [
		{
			path: "/",
			priority: "1.0",
			changefreq: "weekly"
		},
		{
			path: "/urunler",
			priority: "0.9",
			changefreq: "weekly"
		},
		...catalog.products.map((p) => ({
			path: `/urunler/${p.slug}`,
			priority: "0.9",
			changefreq: "weekly"
		})),
		{
			path: "/kurumsal",
			priority: "0.6",
			changefreq: "monthly"
		},
		{
			path: "/blog",
			priority: "0.7",
			changefreq: "weekly"
		},
		...posts.map((post) => ({
			path: `/blog/${post.slug}`,
			priority: "0.6",
			changefreq: "monthly"
		})),
		{
			path: "/iletisim",
			priority: "0.5",
			changefreq: "yearly"
		},
		...LEGAL_NAV.map((page) => ({
			path: `/yasal/${page.slug}`,
			priority: "0.3",
			changefreq: "yearly"
		}))
	];
}
var Route$6 = createFileRoute("/sitemap.xml")({ server: { handlers: { GET: async () => {
	const base = SITE.url.replace(/\/+$/, "");
	const body = [
		"<?xml version=\"1.0\" encoding=\"UTF-8\"?>",
		"<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">",
		...(await buildEntries()).map((e) => [
			"  <url>",
			`    <loc>${base}${e.path}</loc>`,
			`    <changefreq>${e.changefreq}</changefreq>`,
			`    <priority>${e.priority}</priority>`,
			"  </url>"
		].join("\n")),
		"</urlset>",
		""
	].join("\n");
	return new Response(body, { headers: {
		"Content-Type": "application/xml; charset=utf-8",
		"Cache-Control": "public, max-age=3600"
	} });
} } } });
var $$splitComponentImporter$4 = () => import("./blog-B0EtqNWa.mjs");
var Route$5 = createFileRoute("/blog/")({
	loader: () => loadBlogPosts(),
	head: () => ({ meta: [{ title: `Blog — ${SITE.name}` }, {
		name: "description",
		content: "Takviye etiketi nasıl okunur, besin ögesi beyanları neye dayanır, magnezyum formları neden farklıdır — Luzayn yazıları."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("../_slug-C0r0CB31.mjs");
var $$splitNotFoundComponentImporter$2 = () => import("../_slug-O3t5vQeR.mjs");
var Route$4 = createFileRoute("/blog/$slug")({
	loader: async ({ params }) => {
		const [post, all] = await Promise.all([loadBlogPost(params.slug), loadBlogPosts()]);
		if (!post) throw notFound();
		return {
			post,
			all
		};
	},
	head: ({ loaderData }) => {
		const post = loaderData?.post;
		if (!post) return {};
		return { meta: [
			{ title: `${post.title} — ${SITE.name}` },
			{
				name: "description",
				content: post.excerpt
			},
			{
				property: "og:type",
				content: "article"
			},
			{
				property: "og:title",
				content: post.title
			},
			{
				property: "og:description",
				content: post.excerpt
			},
			{
				property: "og:image",
				content: mediaUrl(post.cover)
			}
		] };
	},
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter$2, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
/**
* Eski site-içi ödeme formu kaldırıldı.
*
* Ödeme artık Shopify checkout'unda tamamlanıyor: sepet sayfasındaki
* "Güvenli Ödemeye Geç" butonu Storefront API ile Shopify'da sepet oluşturup
* kullanıcıyı oraya yönlendiriyor (bkz. src/server/shopify.ts). Adres, kart
* ve fatura bilgilerini Shopify topluyor; ödemeyi ona bağlı iyzico alıyor.
*
* Bu rota, eski bağlantılar ve yer imleri kırılmasın diye sepete yönlendirir.
*/
var Route$3 = createFileRoute("/odeme/")({ beforeLoad: () => {
	throw redirect({ to: "/sepet" });
} });
var $$splitComponentImporter$2 = () => import("./urunler-J2OQ0pV2.mjs");
var Route$2 = createFileRoute("/urunler/")({
	head: () => ({ meta: [{ title: `Ürünler — ${SITE.name}` }, {
		name: "description",
		content: "Luzayn takviye edici gıda serisinin tamamı: magnezyum kompleksi, omega-3, C vitamini, D3K2 damla, koenzim Q10, reishi, RO ve XSLS."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("../_slug-BfFxBeNZ.mjs");
var $$splitNotFoundComponentImporter$1 = () => import("../_slug-ll8CKATC.mjs");
var Route$1 = createFileRoute("/urunler/$slug")({
	loader: async ({ params }) => {
		const product = (await loadCatalog()).bySlug[params.slug];
		if (!product) throw notFound();
		return { product };
	},
	head: ({ loaderData }) => {
		const product = loaderData?.product;
		if (!product) return {};
		return { meta: [
			{ title: `${product.name} — ${SITE.name}` },
			{
				name: "description",
				content: product.description
			},
			{
				property: "og:title",
				content: `${product.name} — ${SITE.name}`
			},
			{
				property: "og:description",
				content: product.description
			},
			{
				property: "og:image",
				content: mediaUrl(product.cover)
			}
		] };
	},
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter$1, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
/**
* İçerik bilgisi tablosu + ürün özellikleri.
* Miktarlar etiketten birebir alınır; %BRD yalnızca etikette verilmişse
* gösterilir — hesaplanıp uydurulmaz.
*/
/** Mobilde alta sabitlenen satın alma barı */
var $$splitComponentImporter = () => import("../_slug-Bk-4X6_-.mjs");
var $$splitNotFoundComponentImporter = () => import("../_slug-DnWGhpy1.mjs");
var Route = createFileRoute("/yasal/$slug")({
	loader: async ({ params }) => {
		const page = buildLegalPages((await loadCatalog()).commerce).find((p) => p.slug === params.slug);
		if (!page) throw notFound();
		return { page };
	},
	head: ({ loaderData }) => {
		const page = loaderData?.page;
		if (!page) return {};
		return { meta: [{ title: `${page.title} — ${SITE.name}` }, {
			name: "description",
			content: page.intro
		}] };
	},
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
/** Tüm yasal sayfalar bu tek düzenden render edilir — açık tema, max-w-3xl. */
var IndexRoute = Route$11.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$12
});
var IletisimRoute = Route$10.update({
	id: "/iletisim",
	path: "/iletisim",
	getParentRoute: () => Route$12
});
var KurumsalRoute = Route$9.update({
	id: "/kurumsal",
	path: "/kurumsal",
	getParentRoute: () => Route$12
});
var RobotsDottxtRoute = Route$8.update({
	id: "/robots.txt",
	path: "/robots.txt",
	getParentRoute: () => Route$12
});
var SepetRoute = Route$7.update({
	id: "/sepet",
	path: "/sepet",
	getParentRoute: () => Route$12
});
var SitemapDotxmlRoute = Route$6.update({
	id: "/sitemap.xml",
	path: "/sitemap.xml",
	getParentRoute: () => Route$12
});
var BlogIndexRoute = Route$5.update({
	id: "/blog/",
	path: "/blog/",
	getParentRoute: () => Route$12
});
var BlogSlugRoute = Route$4.update({
	id: "/blog/$slug",
	path: "/blog/$slug",
	getParentRoute: () => Route$12
});
var OdemeIndexRoute = Route$3.update({
	id: "/odeme/",
	path: "/odeme/",
	getParentRoute: () => Route$12
});
var UrunlerIndexRoute = Route$2.update({
	id: "/urunler/",
	path: "/urunler/",
	getParentRoute: () => Route$12
});
var rootRouteChildren = {
	IndexRoute,
	IletisimRoute,
	KurumsalRoute,
	RobotsDottxtRoute,
	SepetRoute,
	SitemapDotxmlRoute,
	BlogSlugRoute,
	UrunlerSlugRoute: Route$1.update({
		id: "/urunler/$slug",
		path: "/urunler/$slug",
		getParentRoute: () => Route$12
	}),
	YasalSlugRoute: Route.update({
		id: "/yasal/$slug",
		path: "/yasal/$slug",
		getParentRoute: () => Route$12
	}),
	BlogIndexRoute,
	OdemeIndexRoute,
	UrunlerIndexRoute
};
var routeTree = Route$12._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		scrollRestoration: true,
		defaultPreload: "intent",
		defaultPreloadStaleTime: 0
	});
}
//#endregion
export { cn as _, Route$5 as a, Route$11 as c, resolveCart as d, useCart as f, trackEvent as g, Logo as h, Route$4 as i, NotFoundPage as l, useCatalog as m, Route as n, Route$9 as o, useCartHydrated as p, Route$1 as r, Route$10 as s, router_exports as t, LEGAL_NAV as u, formatPrice as v, mediaUrl as y };
