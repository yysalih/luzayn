import { o as __toESM } from "../_runtime.mjs";
import { a as bundleTotals, i as SITE, n as CERTIFICATIONS, r as CLAIM_DISCLAIMER, t as CDN_PATHS } from "./cms-Bdb4agUA.mjs";
import { B as require_react, _ as Link, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as ArrowRight, E as ArrowUpRight, S as ChevronLeft, T as BadgeCheck, _ as FlaskConical, a as ShieldCheck, i as ShoppingBag, n as Truck, v as FileText, w as Check, x as ChevronRight } from "../_libs/lucide-react.mjs";
import { _ as mediaUrl, c as Route$11, f as useCart, g as formatPrice, h as cn, m as useCatalog, p as useCartHydrated } from "./router-dqPFFXFI.mjs";
import { a as SectionTitle, i as SectionLead, n as KickerPill, r as KickerRuled, t as Disclaimer } from "./typography-YgNHFb6n.mjs";
import { t as useIsMobile } from "./use-is-mobile-BjC0fk4G.mjs";
import { t as formatBlogDate } from "./content-Z140g0m_.mjs";
import { t as ProductRail } from "./product-rail-Wvefvn3_.mjs";
import { t as FaqAccordion } from "./faq-accordion-BVWVivMc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Bp0yk2ni.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var AUTO_MS$1 = 6500;
var SLIDE_MS = 1200;
var SWIPE_THRESHOLD = 40;
/**
* Tam ekran video hero — tek slayt, yavaşça sola kayarak ilerler, sonsuz döner.
*
* Kesme/fade yerine yatay kayma kullanılıyor; videoların zemini aynı koyu
* lacivert tema olduğu için geçiş dikişsiz görünüyor.
*
* Sonsuz döngü: şerit iki kez render edilir (16 slayt). `index` COUNT'a
* ulaştığında görünen slayt zaten baştaki slaytla aynı olduğundan, geçiş
* biter bitmez animasyonsuz 0'a snap ediyoruz — kullanıcı geri sarma görmez.
*/
function Hero({ slides }) {
	const COUNT = slides.length;
	const { bySlug } = useCatalog();
	const [index, setIndex] = (0, import_react.useState)(0);
	const [animate, setAnimate] = (0, import_react.useState)(true);
	const [pendingPrev, setPendingPrev] = (0, import_react.useState)(false);
	const [paused, setPaused] = (0, import_react.useState)(false);
	const [width, setWidth] = (0, import_react.useState)(0);
	const trackRef = (0, import_react.useRef)(null);
	const touchStartX = (0, import_react.useRef)(null);
	/**
	* Slayt genişliğini ölç. Yüzdeyle kaydırmak işe yaramaz: translateX'teki
	* yüzde öğenin KENDİ genişliğine göredir, şerit ise 16 slayt genişliğinde.
	* Slaytın kendisi de izlenmeli — yalnızca şerit izlenirse ilk ölçüm
	* slaytlar genişlik almadan yapılıyor ve 0 kalıyor.
	*/
	(0, import_react.useEffect)(() => {
		const el = trackRef.current;
		if (!el) return;
		const measure = () => {
			const first = el.children[0];
			if (first && first.offsetWidth > 0) setWidth(first.offsetWidth);
		};
		measure();
		const ro = new ResizeObserver(measure);
		ro.observe(el);
		if (el.children[0]) ro.observe(el.children[0]);
		window.addEventListener("resize", measure);
		return () => {
			ro.disconnect();
			window.removeEventListener("resize", measure);
		};
	}, []);
	const next = (0, import_react.useCallback)(() => setIndex((i) => i + 1), []);
	const prev = (0, import_react.useCallback)(() => {
		setIndex((i) => {
			if (i > 0) return i - 1;
			setAnimate(false);
			setPendingPrev(true);
			return COUNT;
		});
	}, []);
	/**
	* Snap sonrası animasyonu geri aç. requestAnimationFrame KULLANILMAZ:
	* arka plan sekmesinde kare üretilmediği için rAF tetiklenmiyor ve
	* carousel geçişi kapalı hâlde kilitleniyordu.
	*/
	(0, import_react.useEffect)(() => {
		if (animate) return;
		const t = setTimeout(() => {
			setAnimate(true);
			if (pendingPrev) {
				setIndex(COUNT - 1);
				setPendingPrev(false);
			}
		}, 40);
		return () => clearTimeout(t);
	}, [animate, pendingPrev]);
	(0, import_react.useEffect)(() => {
		if (index !== COUNT || pendingPrev) return;
		const t = setTimeout(() => {
			setAnimate(false);
			setIndex(0);
		}, SLIDE_MS);
		return () => clearTimeout(t);
	}, [index, pendingPrev]);
	(0, import_react.useEffect)(() => {
		if (paused) return;
		const t = setTimeout(next, AUTO_MS$1);
		return () => clearTimeout(t);
	}, [
		index,
		paused,
		next
	]);
	const active = COUNT > 0 ? index % COUNT : 0;
	const current = slides[active];
	if (!current) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative isolate w-full overflow-hidden bg-[#0a0a12]",
		style: { height: "min(92vh, 900px)" },
		onTouchStart: (e) => {
			touchStartX.current = e.changedTouches[0].clientX;
		},
		onTouchEnd: (e) => {
			if (touchStartX.current === null) return;
			const dx = e.changedTouches[0].clientX - touchStartX.current;
			if (Math.abs(dx) > SWIPE_THRESHOLD) (dx < 0 ? next : prev)();
			touchStartX.current = null;
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "sr-only",
				children: [
					SITE.name,
					" — ",
					SITE.tagline
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: trackRef,
				className: "flex h-full",
				style: {
					transform: `translateX(${-index * width}px)`,
					transition: animate ? `transform ${SLIDE_MS}ms cubic-bezier(0.65, 0, 0.35, 1)` : "none"
				},
				children: [...slides, ...slides].map((slide, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroSlideView, {
					slide,
					live: Math.abs(i - index) <= 1
				}, `${slide.id}-${i}`))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-x-0 bottom-0 z-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container mx-auto flex items-center gap-2 px-4 pb-8",
					children: [slides.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setIndex(i),
						"aria-label": bySlug[s.id]?.shortName ?? s.title,
						"aria-current": i === active,
						className: cn("pointer-events-auto h-1.5 rounded-full transition-all", i === active ? "w-9" : "w-4 bg-white/30 hover:bg-white/50"),
						style: i === active ? { backgroundColor: current.accent } : void 0
					}, s.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-auto text-sm tabular-nums text-white/40",
						children: [
							String(active + 1).padStart(2, "0"),
							" /",
							" ",
							String(COUNT).padStart(2, "0")
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: prev,
				onMouseEnter: () => setPaused(true),
				onMouseLeave: () => setPaused(false),
				"aria-label": "Önceki slayt",
				className: "absolute left-4 top-1/2 z-20 hidden h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-white/15 bg-black/30 text-white backdrop-blur-sm transition-colors hover:bg-black/50 md:flex",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-5 w-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: next,
				onMouseEnter: () => setPaused(true),
				onMouseLeave: () => setPaused(false),
				"aria-label": "Sonraki slayt",
				className: "absolute right-4 top-1/2 z-20 hidden h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-white/15 bg-black/30 text-white backdrop-blur-sm transition-colors hover:bg-black/50 md:flex",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-5 w-5" })
			})
		]
	});
}
/** Tek tam ekran slayt: video + çift gradient + alt sol içerik */
function HeroSlideView({ slide, live }) {
	const { bySlug } = useCatalog();
	const product = bySlug[slide.id];
	const src = useIsMobile() ? slide.videoMobile : slide.videoDesktop;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-full w-full shrink-0 overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: mediaUrl(slide.poster),
				alt: "",
				"aria-hidden": true,
				loading: "lazy",
				className: "absolute inset-0 h-full w-full object-cover"
			}),
			live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				src: mediaUrl(src),
				autoPlay: true,
				muted: true,
				loop: true,
				playsInline: true,
				preload: "auto",
				className: "absolute inset-0 h-full w-full object-cover"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "absolute inset-0",
				style: { backgroundImage: `radial-gradient(circle at 15% 20%, ${slide.accent}30, transparent 45%)` }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-transparent"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "container relative mx-auto flex h-full flex-col justify-end px-4 pb-24 md:pb-28",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-3xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "max-w-2xl text-4xl font-bold leading-[1.05] tracking-tight text-white sm:text-5xl md:text-6xl lg:text-7xl",
							children: product.motto
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-xl text-base leading-relaxed text-white/70 md:text-lg",
							children: slide.description
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/urunler/$slug",
								params: { slug: slide.id },
								className: "inline-flex items-center gap-2 rounded-full bg-white px-7 py-3.5 text-sm font-semibold text-black shadow-lg transition-transform hover:scale-105",
								children: [slide.ctaLabel, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/urunler",
								className: "inline-flex items-center rounded-full border border-white/15 px-7 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-white/10",
								children: "Tüm Seri"
							})]
						})
					]
				})
			})
		]
	});
}
/**
* İnce marka şeridi — hero'nun altında ayrı bir bant.
*
* Önce hero'nun içindeydi; 92vh'lik alanda başlık + sekiz sütun + panel ile
* birlikte fazla katman oluyordu. Kendi bandına alınınca hero nefes aldı.
*
* Chip listesi iki kez render edilir, şerit CSS ile -%50 kaydırılır.
* scrollLeft yaklaşımı, kaydırılabilir alan içeriğin yarısından kısa
* olduğunda sona yapışıp ileri-geri titriyordu.
*/
function TagStrip({ tags }) {
	const track = [...tags, ...tags];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-b border-white/[0.06] bg-[#0a0a12] py-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "group overflow-hidden",
			style: {
				maskImage: "linear-gradient(to right, transparent, black 5%, black 95%, transparent)",
				WebkitMaskImage: "linear-gradient(to right, transparent, black 5%, black 95%, transparent)"
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex w-max gap-2.5 animate-[marquee-slide_45s_linear_infinite] group-hover:[animation-play-state:paused]",
				children: track.map((tag, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "shrink-0 rounded-full border px-4 py-2 text-xs font-medium text-white",
					style: {
						borderColor: `${tag.accent}59`,
						backgroundColor: `${tag.accent}14`
					},
					children: tag.label
				}, `${tag.label}-${i}`))
			})
		})
	});
}
/**
* Dikey klip duvarı — hero'ya girmeyen dört ürün.
* Videolar sessizdir (ürün render'ları), bu yüzden ses kontrolü yok;
* ancak ekran dışındayken duraklatılır (boşuna decode etmesin).
*/
function VideoWall({ slugs }) {
	const { bySlug } = useCatalog();
	const products = slugs.flatMap((slug) => bySlug[slug] ?? []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden bg-[#0a0a12] py-20 md:py-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "pointer-events-none absolute -left-32 top-1/4 h-96 w-96 animate-[orb-drift-a_18s_ease-in-out_infinite] rounded-full bg-accent/20 blur-[120px]"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "pointer-events-none absolute -right-24 bottom-0 h-80 w-80 animate-[orb-drift-b_22s_ease-in-out_infinite] rounded-full bg-accent-soft/15 blur-[120px]"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container relative mx-auto px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KickerRuled, { children: "Serinin Diğer Yarısı" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
							dark: true,
							className: "mt-5",
							children: "Dört formül, dört farklı bileşim mantığı."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLead, {
							dark: true,
							className: "mt-4",
							children: "Tek bileşenli bir softgelden on bileşenli bir kompleks kapsüle kadar. Bitkisel bileşenler için yetkilendirilmiş sağlık beyanı bulunmadığından onları yalnızca bileşim olarak tanımlıyoruz."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid grid-cols-2 gap-3 md:gap-5 lg:grid-cols-4",
					children: products.map((product, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, {
						product,
						index: i
					}, product.slug))
				})]
			})
		]
	});
}
function VideoCard({ product, index }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		const observer = new IntersectionObserver(([entry]) => {
			if (entry.isIntersecting) el.play().catch(() => void 0);
			else el.pause();
		}, { threshold: .4 });
		observer.observe(el);
		return () => observer.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/urunler/$slug",
		params: { slug: product.slug },
		className: "group relative block overflow-hidden rounded-3xl border transition-transform duration-300 hover:scale-[1.02] animate-[showcase-rise-in_0.6s_ease-out_both]",
		style: {
			borderColor: `${product.accent}30`,
			aspectRatio: "9 / 16",
			animationDelay: `${index * 120}ms`
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: mediaUrl(CDN_PATHS.cover(product.slug)),
				alt: "",
				"aria-hidden": true,
				loading: "lazy",
				className: "absolute inset-0 h-full w-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				ref,
				src: mediaUrl(CDN_PATHS.videoMobile(product.slug)),
				muted: true,
				loop: true,
				playsInline: true,
				preload: "none",
				className: "absolute inset-0 h-full w-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "absolute inset-0 bg-gradient-to-t from-black/90 via-black/25 to-transparent"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-x-0 bottom-0 p-4 md:p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-base font-bold leading-tight text-white md:text-lg",
					children: product.shortName
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-semibold text-white/80",
						children: formatPrice(product.price)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "inline-flex h-8 w-8 items-center justify-center rounded-full border border-white/15 text-white transition-colors group-hover:bg-white group-hover:text-black",
						"aria-hidden": true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "h-4 w-4" })
					})]
				})]
			})
		]
	});
}
/**
* Set teklifi — fotoğraf arka planlı koyu bölüm.
* Fiyat matematiği gerçektir: liste fiyatlarının toplamı gösterilir.
* BUNDLE.discountRate 0 olduğu sürece indirim satırı hiç render edilmez.
*/
function BundleSection() {
	const catalog = useCatalog();
	const { bundle, commerce } = catalog;
	const { items, listTotal, total, saving } = bundleTotals(catalog);
	const hydrated = useCartHydrated();
	const add = useCart((s) => s.add);
	const threshold = commerce.freeShippingThreshold;
	const freeShipping = threshold !== null && total >= threshold;
	if (items.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden py-20 md:py-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: mediaUrl(CDN_PATHS.cover("omega3")),
				alt: "",
				"aria-hidden": true,
				loading: "lazy",
				className: "absolute inset-0 h-full w-full object-cover opacity-40"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "absolute inset-0 bg-gradient-to-b from-[#0a0a12]/95 via-[#0a0a12]/80 to-[#0a0a12]/95"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "container relative mx-auto px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid items-center gap-12 lg:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KickerRuled, { children: bundle.tagline }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
							dark: true,
							className: "mt-5",
							children: bundle.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-lg text-base leading-relaxed text-white/60 md:text-lg",
							children: "Serinin vitamin ve mineral tarafını tek sepette toplayan set: magnezyum kompleksi, omega-3, C vitamini ve D3K2 damla. Dördü de beyanı mevzuatça yetkilendirilmiş besin ögeleri içerir."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-8 space-y-3",
							children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full",
										style: { backgroundColor: `${item.accent}1f` },
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
											className: "h-3.5 w-3.5",
											style: { color: item.accent }
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-sm text-white/80",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold text-white",
											children: item.shortName
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-white/50",
											children: [" · ", item.unit]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-auto text-sm text-white/50",
										children: formatPrice(item.price)
									})
								]
							}, item.slug))
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-3xl border border-white/10 bg-white/[0.04] p-8 backdrop-blur-md animate-[bundle-glow-pulse_6s_ease-in-out_infinite] md:p-10",
						style: { backgroundImage: "linear-gradient(140deg, rgba(34,211,238,0.08), rgba(59,130,246,0.05) 60%, transparent)" },
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] font-semibold uppercase tracking-[0.25em] text-white/40",
								children: "Set Toplamı"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap items-baseline gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-4xl font-bold text-white md:text-5xl",
									children: formatPrice(total)
								}), saving > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-lg text-white/40 line-through",
									children: formatPrice(listTotal)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "rounded-full bg-emerald-500/15 px-3 py-1 text-xs font-semibold text-emerald-300",
									children: [formatPrice(saving), " avantaj"]
								})] }) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm text-white/50",
								children: [items.length, " ürünün liste fiyatı toplamı. Fiyatlar sipariş anında geçerli olan tutar üzerinden hesaplanır."]
							}),
							freeShipping ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 flex items-center gap-2.5 rounded-2xl border border-emerald-400/20 bg-emerald-400/[0.07] px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "h-4 w-4 shrink-0 text-emerald-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm text-emerald-200",
									children: [formatPrice(threshold ?? 0), " eşiğini geçtiği için kargo ücretsiz."]
								})]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: !hydrated,
								onClick: () => items.forEach((item) => add(item.slug, 1)),
								className: "mt-7 inline-flex w-full items-center justify-center gap-2 rounded-full bg-white px-7 py-4 text-sm font-semibold text-black shadow-lg transition-transform hover:scale-[1.02] disabled:opacity-50",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "h-4 w-4" }), "Seti Sepete Ekle"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Disclaimer, {
								dark: true,
								className: "mt-5",
								children: "Takviye edici gıdalar normal beslenmenin yerine geçmez. Birden fazla ürünü birlikte kullanmadan önce toplam günlük alımınızı kontrol edin ve hekiminize danışın."
							})
						]
					})]
				})
			})
		]
	});
}
function Philosophy({ content }) {
	if (!content) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-background py-20 md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "container mx-auto px-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:sticky lg:top-28 lg:self-start",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KickerPill, { children: content.kicker }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
							className: "mt-5 max-w-md text-4xl md:text-5xl",
							children: content.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLead, {
							className: "mt-5 max-w-md",
							children: content.intro
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-px overflow-hidden rounded-3xl bg-border sm:grid-cols-2",
					children: content.values.map((value, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "bg-card p-7 animate-[showcase-rise-in_0.5s_ease-out_both] md:p-8",
						style: { animationDelay: `${i * 100}ms` },
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-semibold tabular-nums text-accent",
								children: String(i + 1).padStart(2, "0")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 text-lg font-bold tracking-tight text-foreground",
								children: value.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2.5 text-sm leading-relaxed text-muted-foreground",
								children: value.detail
							})
						]
					}, value.title))
				})]
			})
		})
	});
}
/** Ken-burns animasyonlu fotoğraf banner'ı — bölümler arası nefes alanı. */
function Banner() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative h-[22rem] overflow-hidden md:h-[28rem]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: mediaUrl("/images/3lu.jfif"),
				alt: "Luzayn RO, Reishi Mushroom & Echinacea ve XSLS ürünleri",
				loading: "lazy",
				className: "absolute inset-0 h-full w-full origin-center object-cover object-[70%_center] animate-[wisdom-kenburns_24s_ease-in-out_infinite_alternate] md:object-center"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "absolute inset-0 bg-gradient-to-r from-[#0a0a12]/95 via-[#0a0a12]/75 to-[#0a0a12]/25"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container relative mx-auto flex h-full max-w-4xl flex-col justify-center px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KickerRuled, { children: "Luzayn" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-2xl font-bold leading-snug tracking-tight text-white sm:text-3xl md:text-4xl",
						children: "Bir formülün değeri, içindekilerin adında değil miktarında saklıdır."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-sm leading-relaxed text-white/60 md:text-base",
						children: "Bu yüzden her ambalajda bileşenin ne kadar olduğunu yazıyoruz ve her iddianın hangi bileşene ait olduğunu belirtiyoruz."
					})
				]
			})
		]
	});
}
var ICONS = [
	ShieldCheck,
	BadgeCheck,
	FlaskConical,
	FileText
];
/**
* Resmî güven bloğu. Yalnızca ambalajda işaretli olan sertifikalar listelenir;
* numara/kapsam bilgisi doğrulanmadan yazılmaz.
*/
function TrustSection() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-y border-border bg-muted/40 py-16 md:py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container mx-auto px-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KickerPill, { children: "Üretim ve Kayıt" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
						className: "mt-4",
						children: "Ambalajda işaretli olan ne varsa, burada da var."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
					children: CERTIFICATIONS.map((cert, i) => {
						const Icon = ICONS[i % ICONS.length];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-border bg-card p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5 text-accent" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-4 text-base font-bold tracking-tight text-foreground",
									children: cert.code
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1.5 text-sm leading-relaxed text-muted-foreground",
									children: cert.label
								})
							]
						}, cert.code);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 grid gap-4 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
							label: "Menşei",
							value: SITE.origin
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
							label: "İşletme Kayıt No",
							value: SITE.businessRegNo
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
							label: "Takviye Edici Gıda Onay No",
							value: SITE.supplementApprovalNo
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Disclaimer, {
					className: "mt-6 max-w-3xl",
					children: "Kayıt ve onay numaraları her ürünün ambalajında yer alır. Sitede doğrulanmamış hiçbir numara yayımlanmaz."
				})
			]
		})
	});
}
/** Değeri boş olan kart hiç render edilmez. */
function InfoRow({ label, value }) {
	if (!value) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-border bg-card px-5 py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-[11px] font-semibold uppercase tracking-wider text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-1 block text-sm font-medium text-foreground",
			children: value
		})]
	});
}
var AUTO_MS = 5e3;
/**
* Sayılar carousel'i. Her rakam ambalaj etiketinden okunur veya etiket
* verisinden hesaplanır — doğrulanamayan hiçbir veri buraya girmez.
* Kendi kendine ilerler; ok, dot ve swipe ile her an müdahale edilebilir.
*/
function EvidenceCarousel({ stats }) {
	const { bySlug } = useCatalog();
	const railRef = (0, import_react.useRef)(null);
	const [active, setActive] = (0, import_react.useState)(0);
	const [paused, setPaused] = (0, import_react.useState)(false);
	const scrollTo = (0, import_react.useCallback)((index) => {
		const rail = railRef.current;
		if (!rail) return;
		const card = rail.children[index];
		if (!card) return;
		rail.scrollTo({
			left: card.offsetLeft - rail.offsetLeft,
			behavior: "smooth"
		});
		setActive(index);
	}, []);
	(0, import_react.useEffect)(() => {
		if (paused) return;
		const t = setTimeout(() => scrollTo((active + 1) % stats.length), AUTO_MS);
		return () => clearTimeout(t);
	}, [
		active,
		paused,
		scrollTo
	]);
	(0, import_react.useEffect)(() => {
		const rail = railRef.current;
		if (!rail) return;
		let frame = 0;
		const onScroll = () => {
			cancelAnimationFrame(frame);
			frame = requestAnimationFrame(() => {
				const nearest = Array.from(rail.children).reduce((best, child, i) => {
					const distance = Math.abs(child.offsetLeft - rail.offsetLeft - rail.scrollLeft);
					return distance < best.distance ? {
						i,
						distance
					} : best;
				}, {
					i: 0,
					distance: Infinity
				});
				setActive(nearest.i);
			});
		};
		rail.addEventListener("scroll", onScroll, { passive: true });
		return () => {
			rail.removeEventListener("scroll", onScroll);
			cancelAnimationFrame(frame);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden bg-[#0a0a12] py-20 md:py-28",
		onPointerEnter: () => setPaused(true),
		onPointerLeave: () => setPaused(false),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			"aria-hidden": true,
			className: "pointer-events-none absolute inset-0 opacity-[0.04]",
			style: {
				backgroundImage: "radial-gradient(circle, #ffffff 1px, transparent 1px)",
				backgroundSize: "28px 28px"
			}
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container relative mx-auto px-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-2xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KickerRuled, { children: "Etiketten Okunan Sayılar" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
								dark: true,
								className: "mt-5",
								children: "Her rakamın bir kaynağı var."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLead, {
								dark: true,
								className: "mt-4",
								children: "Aşağıdaki sayılar ürün etiketlerinden okunur veya doğrudan etiket verisinden hesaplanır. Kaynağı gösterilemeyen bir istatistik bu sayfada yer almaz."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hidden items-center gap-2 md:flex",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
							label: "Önceki",
							onClick: () => scrollTo((active - 1 + stats.length) % stats.length),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-5 w-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
							label: "Sonraki",
							onClick: () => scrollTo((active + 1) % stats.length),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-5 w-5" })
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					ref: railRef,
					className: "no-scrollbar mt-12 flex snap-x snap-mandatory gap-4 overflow-x-auto pb-2",
					children: stats.map((stat, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						stat,
						index: i
					}, `${stat.slug}-${i}`))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 flex items-center gap-2",
					children: stats.map((stat, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => scrollTo(i),
						"aria-label": `${i + 1}. kart`,
						"aria-current": i === active,
						className: cn("h-1.5 rounded-full transition-all", i === active ? "w-8" : "w-3 bg-white/25 hover:bg-white/45"),
						style: i === active ? { backgroundColor: bySlug[stat.slug]?.accent } : void 0
					}, `dot-${stat.slug}-${i}`))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Disclaimer, {
					dark: true,
					className: "mt-8 max-w-3xl",
					children: CLAIM_DISCLAIMER
				})
			]
		})]
	});
}
function NavButton({ label, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		"aria-label": label,
		className: "inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/15 text-white transition-colors hover:bg-white/10",
		children
	});
}
function StatCard({ stat, index }) {
	const { bySlug } = useCatalog();
	const product = bySlug[stat.slug];
	if (!product) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex w-[82%] shrink-0 snap-start flex-col rounded-3xl border bg-white/[0.04] p-7 backdrop-blur-md sm:w-80 md:p-8",
		style: { borderColor: `${product.accent}30` },
		children: [
			stat.ring === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BigNumber, {
				stat,
				accent: product.accent
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ring, {
				stat,
				accent: product.accent,
				index
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-6 text-base font-bold text-white",
				children: stat.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 flex-1 text-sm leading-relaxed text-white/55",
				children: stat.context
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-5 inline-flex w-fit items-center gap-2 rounded-full px-3 py-1 text-[11px] font-medium uppercase tracking-wider",
				style: {
					backgroundColor: `${product.accent}1f`,
					color: product.accent
				},
				children: product.shortName
			})
		]
	});
}
function Ring({ stat, accent, index }) {
	const target = 100 - (stat.ring ?? 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-32 w-32",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 120 120",
			className: "h-32 w-32 -rotate-90",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "60",
				r: "52",
				fill: "none",
				stroke: "rgba(255,255,255,0.08)",
				strokeWidth: "10"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "60",
				r: "52",
				fill: "none",
				stroke: accent,
				strokeWidth: "10",
				strokeLinecap: "round",
				pathLength: 100,
				strokeDasharray: 100,
				strokeDashoffset: 100,
				className: "animate-[evidence-ring-fill_1.2s_ease-out_forwards]",
				style: {
					"--ring-target": target,
					animationDelay: `${index * 90}ms`
				}
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute inset-0 flex items-center justify-center text-2xl font-bold text-white",
			children: stat.value
		})]
	});
}
function BigNumber({ stat, accent }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-32 items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-6xl font-bold leading-none animate-[evidence-pop-in_0.5s_ease-out_both] md:text-7xl",
			style: { color: accent },
			children: stat.value
		}), stat.unit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "ml-2 self-end pb-2 text-lg font-medium text-white/50",
			children: stat.unit
		}) : null]
	});
}
/**
* Etkileşimli detay carousel'i: üstte chip satırı, altta seçili ürünün
* bileşen/beyan panelini gösteren glass panel. Panel key={aktif} ile
* remount edilip fade-in ile girer.
*/
function IngredientShowcase() {
	const { products } = useCatalog();
	const [active, setActive] = (0, import_react.useState)(0);
	const product = products[active];
	const go = (dir) => setActive((i) => (i + dir + products.length) % products.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden bg-[#0a0a12] py-20 md:py-28",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			"aria-hidden": true,
			className: "pointer-events-none absolute right-0 top-0 h-[28rem] w-[28rem] rounded-full blur-[140px] transition-colors duration-700",
			style: { backgroundColor: `${product.accent}25` }
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container relative mx-auto px-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KickerRuled, { children: "İçerik & Dayanak" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
							dark: true,
							className: "mt-5",
							children: "Hangi bileşen, hangi cümleyi taşıyor?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLead, {
							dark: true,
							className: "mt-4",
							children: "Bir ürün seçin: formüldeki her ana bileşeni ve o bileşene ait ifadeyi ayrı ayrı görün. Beyanı olmayan bileşenler için bunu açıkça yazıyoruz."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "no-scrollbar mt-10 flex gap-2 overflow-x-auto pb-1",
					children: products.map((p, i) => {
						const isActive = i === active;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setActive(i),
							"aria-pressed": isActive,
							className: "shrink-0 rounded-full border px-4 py-2 text-sm font-medium transition-colors",
							style: {
								borderColor: isActive ? `${p.accent}66` : "rgba(255,255,255,0.1)",
								backgroundColor: isActive ? `${p.accent}1f` : "transparent",
								color: isActive ? p.accent : "rgba(255,255,255,0.6)"
							},
							children: p.shortName
						}, p.slug);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 animate-[showcase-fade-in_0.4s_ease-out] rounded-3xl border border-white/10 bg-white/[0.04] p-7 backdrop-blur-md md:p-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-8 lg:grid-cols-[0.85fr_1.15fr] lg:gap-12",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative overflow-hidden rounded-2xl border",
							style: { borderColor: `${product.accent}30` },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: mediaUrl(CDN_PATHS.cover(product.slug)),
								alt: product.name,
								loading: "lazy",
								className: "aspect-[4/5] w-full object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								"aria-hidden": true,
								className: "absolute inset-0",
								style: { backgroundImage: `linear-gradient(to top, #0a0a12cc, transparent 55%)` }
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-5 flex flex-wrap gap-1.5",
							children: product.keyIngredients.map((ing) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full border px-2.5 py-1 text-[11px] text-white/70",
								style: { borderColor: `${product.accent}30` },
								children: ing
							}, ing))
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-2xl font-bold tracking-tight text-white",
										children: product.shortName
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "rounded-full px-3 py-1 text-[11px] font-medium uppercase tracking-wider",
										style: {
											backgroundColor: `${product.accent}1f`,
											color: product.accent
										},
										children: [product.servingSize, " için"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-relaxed text-white/60",
									children: product.description
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
									className: "mt-7 space-y-5",
									children: product.highlights.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "border-l pl-4",
										style: { borderColor: `${product.accent}66` },
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
												className: "text-[11px] font-semibold uppercase tracking-[0.18em] text-white/40",
												children: "Bileşen"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-sm font-semibold text-white",
												children: h.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
												className: "mt-2.5 text-[11px] font-semibold uppercase tracking-[0.18em] text-white/40",
												children: "İfade"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
												className: "mt-1 text-sm leading-relaxed text-white/60",
												children: h.detail
											})
										]
									}, h.title))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 flex flex-wrap items-center justify-between gap-4 border-t border-white/10 pt-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/urunler/$slug",
										params: { slug: product.slug },
										className: "inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold text-white transition-transform hover:scale-105",
										style: { backgroundColor: product.accent },
										children: ["Ürünü İncele", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-sm tabular-nums text-white/40",
												children: [
													String(active + 1).padStart(2, "0"),
													" /",
													" ",
													String(products.length).padStart(2, "0")
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => go(-1),
												"aria-label": "Önceki ürün",
												className: "inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/15 text-white transition-colors hover:bg-white/10",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => go(1),
												"aria-label": "Sonraki ürün",
												className: "inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/15 text-white transition-colors hover:bg-white/10",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })
											})
										]
									})]
								})
							]
						})]
					})
				}, product.slug),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Disclaimer, {
					dark: true,
					className: "mt-6 max-w-3xl",
					children: CLAIM_DISCLAIMER
				})
			]
		})]
	});
}
function FaqSection({ items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden py-20 md:py-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: mediaUrl(CDN_PATHS.cover("reishi")),
				alt: "",
				"aria-hidden": true,
				loading: "lazy",
				className: "absolute inset-0 h-full w-full object-cover opacity-40"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "absolute inset-0 bg-gradient-to-b from-[#0a0a12]/95 via-[#0a0a12]/85 to-[#0a0a12]/95"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "container relative mx-auto px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-10 lg:grid-cols-[0.8fr_1.2fr] lg:gap-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lg:sticky lg:top-28 lg:self-start",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KickerRuled, { children: "Sık Sorulanlar" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
								dark: true,
								className: "mt-5",
								children: "Merak edilenler."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionLead, {
								dark: true,
								className: "mt-4",
								children: "Kullanım, saklama, kargo ve iade hakkında en çok gelen sorular. Yanıtını bulamadığınız bir konu varsa bize yazın."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/iletisim",
								className: "mt-7 inline-flex items-center gap-2 rounded-full border border-white/15 px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-white/10",
								children: ["Soru Sorun", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqAccordion, {
						items,
						dark: true
					})]
				})
			})
		]
	});
}
/**
* Sade editoryal önizleme: çıplak görsel, üstünde rozet YOK.
* Kategori metni accent renginde, kart çerçevesi yok.
*/
function BlogPreview({ posts: all }) {
	const posts = all.slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-background py-20 md:py-28",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container mx-auto px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KickerPill, { children: "Yazılar" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
					className: "mt-4",
					children: "Etiketi birlikte okuyalım."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/blog",
					className: "inline-flex items-center gap-2 rounded-full border border-border px-5 py-2.5 text-sm font-semibold text-foreground transition-colors hover:bg-muted",
					children: ["Tüm Yazılar", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-8 md:grid-cols-3 md:gap-6",
				children: posts.map((post) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/blog/$slug",
					params: { slug: post.slug },
					className: "group block",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: mediaUrl(post.cover),
							alt: "",
							"aria-hidden": true,
							loading: "lazy",
							className: "aspect-[4/3] w-full rounded-xl object-cover transition-transform duration-300 group-hover:scale-[1.02]"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-5 block text-[11px] font-semibold uppercase tracking-[0.18em]",
							style: { color: post.categoryAccent },
							children: post.category
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-2 text-lg font-bold leading-snug tracking-tight text-foreground",
							children: post.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted-foreground",
							children: post.excerpt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-3 block text-xs text-muted-foreground/70",
							children: [
								formatBlogDate(post.date),
								" · ",
								post.readingMinutes,
								" dk okuma"
							]
						})
					]
				}, post.slug))
			})]
		})
	});
}
/**
* Dikkat eğrisi: heyecan → güven → detay → kanıt → dönüşüm.
* Koyu ve açık bölümler nöbetleşir; ritim scroll'da hissedilir.
*/
function HomePage() {
	const { home, faq, posts } = Route$11.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, { slides: home.heroSlides }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagStrip, { tags: home.heroTags }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductRail, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoWall, { slugs: home.videoWallSlugs }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BundleSection, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Philosophy, { content: home.philosophy }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banner, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrustSection, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidenceCarousel, { stats: home.evidenceStats }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IngredientShowcase, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqSection, { items: faq }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlogPreview, { posts })
	] });
}
//#endregion
export { HomePage as component };
