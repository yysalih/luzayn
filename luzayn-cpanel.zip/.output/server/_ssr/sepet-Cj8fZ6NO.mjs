import { i as SITE, r as CLAIM_DISCLAIMER } from "./cms-CSbzslKe.mjs";
import { _ as Link, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as ArrowRight, b as CircleAlert, d as Minus, g as Lock, i as ShoppingBag, n as Truck, r as Trash2, s as Plus } from "../_libs/lucide-react.mjs";
import { d as resolveCart, f as useCart, g as trackEvent, m as useCatalog, p as useCartHydrated, v as formatPrice, y as mediaUrl } from "./router-D6WmJc6q.mjs";
import { t as Disclaimer } from "./typography-1iJfy8Yl.mjs";
import { t as useShopifyCheckout } from "./use-shopify-checkout-DeH8SGWB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sepet-Cj8fZ6NO.js
var import_jsx_runtime = require_jsx_runtime();
function CartPage() {
	const hydrated = useCartHydrated();
	const lines = useCart((s) => s.lines);
	const setQty = useCart((s) => s.setQty);
	const remove = useCart((s) => s.remove);
	const catalog = useCatalog();
	const cart = resolveCart(catalog, hydrated ? lines : []);
	const { checkout, pending, error } = useShopifyCheckout();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-background py-12 md:py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container mx-auto px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-bold tracking-tight text-foreground md:text-4xl",
				children: "Sepetiniz"
			}), !hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-sm text-muted-foreground",
				children: "Sepet yükleniyor…"
			}) : cart.items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyCart, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 grid gap-10 lg:grid-cols-[1.6fr_1fr] lg:gap-14",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-border overflow-hidden rounded-3xl border border-border bg-card",
					children: cart.items.map(({ product, qty, lineTotal }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-4 p-4 md:p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/urunler/$slug",
								params: { slug: product.slug },
								className: "shrink-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: mediaUrl(product.cover),
									alt: product.name,
									loading: "lazy",
									className: "h-24 w-20 rounded-xl object-cover md:h-28 md:w-24"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex min-w-0 flex-1 flex-col",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] font-semibold uppercase tracking-[0.18em]",
										style: { color: product.accent },
										children: product.category
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/urunler/$slug",
										params: { slug: product.slug },
										className: "mt-1 text-sm font-bold text-foreground hover:underline md:text-base",
										children: product.shortName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mt-0.5 text-xs text-muted-foreground",
										children: [
											product.unit,
											" · ",
											formatPrice(product.price),
											" / adet"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-auto flex items-center gap-3 pt-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "inline-flex items-center rounded-full border",
											style: { borderColor: `${product.accent}30` },
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => setQty(product.slug, qty - 1),
													"aria-label": `${product.shortName} adet azalt`,
													className: "inline-flex h-9 w-9 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-muted",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "h-3.5 w-3.5" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "w-7 text-center text-sm font-semibold tabular-nums text-foreground",
													children: qty
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => setQty(product.slug, qty + 1),
													"aria-label": `${product.shortName} adet artır`,
													disabled: qty >= 20,
													className: "inline-flex h-9 w-9 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-muted disabled:opacity-40",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-3.5 w-3.5" })
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => remove(product.slug),
											className: "inline-flex items-center gap-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-3.5 w-3.5" }), "Kaldır"]
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "shrink-0 text-sm font-bold text-foreground md:text-base",
								children: formatPrice(lineTotal)
							})
						]
					}, product.slug))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/urunler",
					className: "mt-6 inline-flex items-center gap-2 text-sm font-semibold text-accent hover:underline",
					children: ["Alışverişe devam et", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
					className: "lg:sticky lg:top-28 lg:self-start",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-3xl border border-border bg-card p-6 md:p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg font-bold tracking-tight text-foreground",
								children: "Sipariş Özeti"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-6 space-y-3 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: `Ara toplam (${cart.count} ürün)`,
										children: formatPrice(cart.subtotal)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Kargo",
										children: !cart.shippingKnown ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-normal text-muted-foreground",
											children: "Ödeme adımında"
										}) : cart.shipping === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold text-emerald-600",
											children: "Ücretsiz"
										}) : formatPrice(cart.shipping ?? 0)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "border-t border-border pt-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
											label: cart.shippingKnown ? "Toplam" : "Ürün toplamı",
											strong: true,
											children: formatPrice(cart.total)
										})
									})
								]
							}),
							!cart.shippingKnown ? null : !cart.freeShipping ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FreeShippingProgress, {
								subtotal: cart.subtotal,
								remaining: cart.remainingForFreeShipping
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 flex items-center gap-2.5 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "h-4 w-4 shrink-0 text-emerald-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-emerald-800",
									children: "Kargonuz ücretsiz."
								})]
							}),
							error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								role: "alert",
								className: "mt-5 flex items-start gap-3 rounded-2xl border border-red-200 bg-red-50 p-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "mt-0.5 h-4 w-4 shrink-0 text-red-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm leading-relaxed text-red-800",
									children: error
								})]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									trackEvent("checkout_start");
									checkout(lines);
								},
								disabled: pending || !hydrated,
								className: "mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-accent px-7 py-4 text-sm font-semibold text-white shadow-lg shadow-accent/25 transition-transform hover:scale-[1.02] disabled:opacity-60",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "h-4 w-4" }), pending ? "Yönlendiriliyor…" : "Güvenli Ödemeye Geç"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-center text-[11px] leading-relaxed text-muted-foreground",
								children: [
									"Kargo tutarı ve nihai toplam, adresinizi girdikten sonra ödeme sayfasında kesinleşir. Kart bilgileri ",
									SITE.name,
									" sunucularına iletilmez."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Disclaimer, {
								className: "mt-5",
								children: CLAIM_DISCLAIMER
							})
						]
					})
				})]
			})]
		})
	});
}
function Row({ label, children, strong = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: strong ? "font-semibold text-foreground" : "text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: strong ? "text-lg font-bold text-foreground" : "font-medium text-foreground",
			children
		})]
	});
}
function FreeShippingProgress({ subtotal, remaining }) {
	const { commerce } = useCatalog();
	const threshold = commerce.freeShippingThreshold ?? 1;
	const percent = Math.min(100, Math.round(subtotal / threshold * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-5 rounded-2xl border border-border bg-muted/50 px-4 py-3.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-muted-foreground",
			children: [
				"Ücretsiz kargoya",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold text-foreground",
					children: formatPrice(remaining)
				}),
				" ",
				"kaldı."
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2.5 h-1.5 overflow-hidden rounded-full bg-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full rounded-full bg-accent transition-all duration-500",
				style: { width: `${percent}%` }
			})
		})]
	});
}
function EmptyCart() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-10 rounded-3xl border border-border bg-card px-6 py-16 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "mx-auto h-10 w-10 text-muted-foreground/40" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-5 text-lg font-bold text-foreground",
				children: "Sepetiniz henüz boş."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-2 max-w-sm text-sm text-muted-foreground",
				children: "Serideki sekiz formülü inceleyip size uygun olanı sepete ekleyebilirsiniz."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/urunler",
				className: "mt-7 inline-flex items-center gap-2 rounded-full bg-accent px-7 py-3.5 text-sm font-semibold text-white shadow-lg shadow-accent/25 transition-transform hover:scale-105",
				children: ["Ürünleri Keşfet", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
			})
		]
	});
}
//#endregion
export { CartPage as component };
