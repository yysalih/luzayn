import { v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as cn } from "./router-dqPFFXFI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/typography-YgNHFb6n.js
var import_jsx_runtime = require_jsx_runtime();
/** Başlığın üstündeki küçük etiket — pill varyantı (açık zeminde) */
function KickerPill({ children, accent, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-block rounded-full px-3 py-1 text-[11px] font-medium uppercase tracking-wider", accent ? void 0 : "bg-accent/10 text-accent", className),
		style: accent ? {
			backgroundColor: `${accent}1f`,
			color: accent
		} : void 0,
		children
	});
}
/** Başlığın üstündeki küçük etiket — çizgili varyant (koyu zeminde) */
function KickerRuled({ children, className, align = "left" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex items-center gap-3", align === "center" && "justify-center", className),
		children: [
			align === "center" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-hidden": true,
				className: "h-px w-10 bg-gradient-to-l from-white/30 to-transparent"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[11px] uppercase tracking-[0.25em] text-white/50",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-hidden": true,
				className: "h-px w-10 bg-gradient-to-r from-white/30 to-transparent"
			})
		]
	});
}
function SectionTitle({ children, className, dark = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: cn("text-3xl font-bold tracking-tight md:text-4xl", dark ? "text-white" : "text-foreground", className),
		children
	});
}
function SectionLead({ children, className, dark = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: cn("text-base leading-relaxed md:text-lg", dark ? "text-white/60" : "text-muted-foreground", className),
		children
	});
}
/** Her beyan bloğunun altına konan referans/uyarı satırı */
function Disclaimer({ children, dark = false, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: cn("text-xs leading-relaxed", dark ? "text-white/35" : "text-muted-foreground/70", className),
		children
	});
}
//#endregion
export { SectionTitle as a, SectionLead as i, KickerPill as n, KickerRuled as r, Disclaimer as t };
