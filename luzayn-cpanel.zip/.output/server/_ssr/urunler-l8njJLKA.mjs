import { i as SITE, r as CLAIM_DISCLAIMER, t as CDN_PATHS } from "./cms-Bdb4agUA.mjs";
import { _ as Link, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as ArrowRight } from "../_libs/lucide-react.mjs";
import { _ as mediaUrl, g as formatPrice, m as useCatalog } from "./router-dqPFFXFI.mjs";
import { t as Disclaimer } from "./typography-YgNHFb6n.mjs";
import { t as AddToCart } from "./add-to-cart-CNuvZoGo.mjs";
import { t as PageHero } from "./page-hero-CWvHg0SN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/urunler-l8njJLKA.js
var import_jsx_runtime = require_jsx_runtime();
function ProductsPage() {
	const { products } = useCatalog();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-[#0a0a12]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			kicker: SITE.name,
			title: "Sekiz formül, tek seri.",
			lead: "Her ürünün bileşenleri, miktarları ve iddiasının hangi bileşene dayandığı ayrı ayrı yazılıdır. Ne eksik ne fazla."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "pb-24 md:pb-32",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container mx-auto px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid items-start gap-5 sm:grid-cols-2 lg:grid-cols-3",
					children: products.map((product, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, {
						product,
						index: i
					}, product.slug))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Disclaimer, {
					dark: true,
					className: "mt-10 max-w-3xl",
					children: CLAIM_DISCLAIMER
				})]
			})
		})]
	});
}
function ProductCard({ product, index }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "group flex animate-[showcase-rise-in_0.5s_ease-out_both] flex-col overflow-hidden rounded-3xl border border-white/10 bg-white/[0.03] transition-colors",
		style: { animationDelay: `${index * 70}ms` },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/urunler/$slug",
			params: { slug: product.slug },
			className: "relative block overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: mediaUrl(CDN_PATHS.cover(product.slug)),
					alt: product.name,
					loading: "lazy",
					className: "aspect-[4/5] w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					"aria-hidden": true,
					className: "absolute inset-0 bg-gradient-to-t from-[#0a0a12] via-transparent to-transparent"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": true,
					className: "absolute inset-0 rounded-3xl opacity-0 transition-opacity duration-300 group-hover:opacity-100",
					style: { boxShadow: `inset 0 0 0 1.5px ${product.accent}66` }
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute left-4 top-4 rounded-full border border-white/15 bg-black/40 px-3 py-1 text-[11px] font-medium text-white/80 backdrop-blur-md",
					children: product.category
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold leading-tight text-white",
					children: product.shortName
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1.5 text-sm leading-snug text-white/55",
					children: product.subtitle
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex flex-wrap gap-1.5",
					children: product.keyIngredients.slice(0, 4).map((ing) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full border px-2.5 py-1 text-[11px] text-white/60",
						style: { borderColor: `${product.accent}30` },
						children: ing
					}, ing))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-auto flex items-end justify-between gap-3 pt-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xl font-bold text-white",
						children: formatPrice(product.price)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-[11px] text-white/40",
						children: product.unit
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddToCart, {
							product,
							variant: "icon"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/urunler/$slug",
							params: { slug: product.slug },
							className: "inline-flex items-center gap-1.5 rounded-full border border-white/15 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-white/10",
							children: ["İncele", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5" })]
						})]
					})]
				})
			]
		})]
	});
}
//#endregion
export { ProductsPage as component };
