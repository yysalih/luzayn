import { o as __toESM } from "../_runtime.mjs";
import { B as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-is-mobile-BjC0fk4G.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/** SSR'da false döner; hydration sonrası gerçek değere geçer. */
function useIsMobile(breakpoint = 768) {
	const [isMobile, setIsMobile] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia(`(max-width: ${breakpoint - 1}px)`);
		const update = () => setIsMobile(mq.matches);
		update();
		mq.addEventListener("change", update);
		return () => mq.removeEventListener("change", update);
	}, [breakpoint]);
	return isMobile;
}
//#endregion
export { useIsMobile as t };
