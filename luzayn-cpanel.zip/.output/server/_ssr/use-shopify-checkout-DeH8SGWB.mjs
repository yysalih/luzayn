import { o as __toESM } from "../_runtime.mjs";
import { B as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as createServerFn } from "./ssr.mjs";
import { t as createSsrRpc } from "./createSsrRpc-C1p7zOu_.mjs";
import { a as string, i as object, n as array, r as number } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-shopify-checkout-DeH8SGWB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/**
* Slug listesi artık modül yüklenirken bilinmiyor: katalog veritabanından
* geliyor. Bu yüzden z.enum yerine biçim kontrolü yapıyoruz; slug'ın GERÇEK
* doğrulaması handler içinde, katalogla karşılaştırılarak yapılıyor.
*
* Kontrolün zayıfladığı anlamına gelmez: eskiden de asıl güvence
* "slug katalogda var mı" idi, enum onu derleme anında sabitliyordu.
*/
var checkoutInputSchema = object({ items: array(object({
	slug: string().min(1).max(64).regex(/^[a-z0-9-]+$/, "Geçersiz ürün."),
	qty: number().int().min(1).max(20)
})).min(1, "Sepetiniz boş.").max(20) });
/**
* Sepeti Shopify'da oluşturur ve checkout adresini döndürür.
* Varyant kimlikleri istemciden DEĞİL, sunucudaki katalogdan okunur.
*/
var createShopifyCheckout = createServerFn({ method: "POST" }).validator((data) => checkoutInputSchema.parse(data)).handler(createSsrRpc("efbaee2a0ed33e2067d0fd6acff314829ebf1f6e468c5b8e9cda99af4efd8d05"));
/**
* Sepeti Shopify'da oluşturup kullanıcıyı Shopify checkout'una gönderir.
*
* Sitede ödeme formu yok: adres, kart ve fatura bilgilerini Shopify checkout
* topluyor, ödemeyi oraya bağlı iyzico alıyor.
*/
function useShopifyCheckout() {
	const [pending, setPending] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	return {
		checkout: (0, import_react.useCallback)(async (lines) => {
			if (lines.length === 0) return;
			setError(null);
			setPending(true);
			try {
				const result = await createShopifyCheckout({ data: { items: lines.map((l) => ({
					slug: l.slug,
					qty: l.qty
				})) } });
				if (result.ok) {
					window.location.href = result.checkoutUrl;
					return;
				}
				setError(result.message);
			} catch (err) {
				console.error("[ödeme] beklenmeyen hata:", err);
				setError("Ödeme sayfası açılamadı. Lütfen tekrar deneyin veya bizimle iletişime geçin.");
			} finally {
				setPending(false);
			}
		}, []),
		pending,
		error
	};
}
//#endregion
export { useShopifyCheckout as t };
