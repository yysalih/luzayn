//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BV2ciGKr.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/Melike/Desktop/Yeni Websiteler/luzayn.com/src/routes/__root.tsx",
		children: [
			"/",
			"/iletisim",
			"/kurumsal",
			"/robots.txt",
			"/sepet",
			"/sitemap.xml",
			"/blog/$slug",
			"/urunler/$slug",
			"/yasal/$slug",
			"/blog/",
			"/odeme/",
			"/urunler/"
		],
		preloads: [
			"/assets/index-BMyT35Vj.js",
			"/assets/link-DvOsKxs3.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/createLucideIcon-BaKsvvZZ.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BMyT35Vj.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/Melike/Desktop/Yeni Websiteler/luzayn.com/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-VaAddj9Q.js",
			"/assets/arrow-right-DH6JlM8M.js",
			"/assets/add-to-cart-ciFZ01n7.js",
			"/assets/chevron-right-Tm9wcNPg.js",
			"/assets/use-is-mobile-C7qHbRCu.js",
			"/assets/truck-BVPTt2DD.js",
			"/assets/content-Duhq1A_9.js",
			"/assets/typography-BqQga8L2.js",
			"/assets/product-rail-DpzKDBGM.js",
			"/assets/faq-accordion-XoSR6wFN.js"
		]
	},
	"/iletisim": {
		filePath: "C:/Users/Melike/Desktop/Yeni Websiteler/luzayn.com/src/routes/iletisim.tsx",
		children: void 0,
		preloads: [
			"/assets/iletisim-JWKCREf_.js",
			"/assets/schemas-AF7ZMwIj.js",
			"/assets/typography-BqQga8L2.js",
			"/assets/page-hero-C0mObTJK.js",
			"/assets/faq-accordion-XoSR6wFN.js"
		]
	},
	"/kurumsal": {
		filePath: "C:/Users/Melike/Desktop/Yeni Websiteler/luzayn.com/src/routes/kurumsal.tsx",
		children: void 0,
		preloads: [
			"/assets/kurumsal-CnjlwoL-.js",
			"/assets/arrow-right-DH6JlM8M.js",
			"/assets/add-to-cart-ciFZ01n7.js",
			"/assets/chevron-right-Tm9wcNPg.js",
			"/assets/typography-BqQga8L2.js",
			"/assets/page-hero-C0mObTJK.js"
		]
	},
	"/sepet": {
		filePath: "C:/Users/Melike/Desktop/Yeni Websiteler/luzayn.com/src/routes/sepet.tsx",
		children: void 0,
		preloads: [
			"/assets/sepet-CeXZb--x.js",
			"/assets/schemas-AF7ZMwIj.js",
			"/assets/arrow-right-DH6JlM8M.js",
			"/assets/use-shopify-checkout-CyKVemrC.js",
			"/assets/plus-C01Y5LV7.js",
			"/assets/truck-BVPTt2DD.js",
			"/assets/typography-BqQga8L2.js"
		]
	},
	"/blog/$slug": {
		filePath: "C:/Users/Melike/Desktop/Yeni Websiteler/luzayn.com/src/routes/blog/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-9dfW9LoN.js",
			"/assets/content-Duhq1A_9.js",
			"/assets/typography-BqQga8L2.js",
			"/assets/_slug-C7cN6W0a.js"
		]
	},
	"/urunler/$slug": {
		filePath: "C:/Users/Melike/Desktop/Yeni Websiteler/luzayn.com/src/routes/urunler/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-Bt74vFGn.js",
			"/assets/_slug-FOEGvmc0.js",
			"/assets/schemas-AF7ZMwIj.js",
			"/assets/arrow-right-DH6JlM8M.js",
			"/assets/add-to-cart-ciFZ01n7.js",
			"/assets/use-shopify-checkout-CyKVemrC.js",
			"/assets/plus-C01Y5LV7.js",
			"/assets/use-is-mobile-C7qHbRCu.js",
			"/assets/truck-BVPTt2DD.js",
			"/assets/typography-BqQga8L2.js"
		]
	},
	"/yasal/$slug": {
		filePath: "C:/Users/Melike/Desktop/Yeni Websiteler/luzayn.com/src/routes/yasal/$slug.tsx",
		children: void 0,
		preloads: ["/assets/_slug-ChDt-s_J.js", "/assets/_slug-GiP01lxJ.js"]
	},
	"/blog/": {
		filePath: "C:/Users/Melike/Desktop/Yeni Websiteler/luzayn.com/src/routes/blog/index.tsx",
		children: void 0,
		preloads: [
			"/assets/blog-DGicmUUt.js",
			"/assets/content-Duhq1A_9.js",
			"/assets/product-rail-DpzKDBGM.js"
		]
	},
	"/urunler/": {
		filePath: "C:/Users/Melike/Desktop/Yeni Websiteler/luzayn.com/src/routes/urunler/index.tsx",
		children: void 0,
		preloads: [
			"/assets/urunler-7MxGXZ9w.js",
			"/assets/arrow-right-DH6JlM8M.js",
			"/assets/add-to-cart-ciFZ01n7.js",
			"/assets/typography-BqQga8L2.js",
			"/assets/page-hero-C0mObTJK.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
