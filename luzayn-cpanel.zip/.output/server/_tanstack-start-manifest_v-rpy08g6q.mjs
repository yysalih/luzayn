//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-rpy08g6q.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/Melike/Desktop/Yeni Websiteler/luzayn.com/src/routes/__root.tsx",
		children: [
			"/",
			"/iletisim",
			"/kurumsal",
			"/robots.txt",
			"/sepet",
			"/sitemap.xml",
			"/blog/$slug",
			"/urunler/$slug",
			"/yasal/$slug",
			"/blog/",
			"/odeme/",
			"/urunler/"
		],
		preloads: [
			"/assets/index-anEYRrAJ.js",
			"/assets/supabase-DDk1pF9s.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/createLucideIcon-DacUZuz0.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-anEYRrAJ.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/Melike/Desktop/Yeni Websiteler/luzayn.com/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DuKXZoQq.js",
			"/assets/arrow-right-Bc9MCm_o.js",
			"/assets/add-to-cart-B1DBEzg7.js",
			"/assets/chevron-right-DsFv12Lf.js",
			"/assets/use-is-mobile-D65dDEU8.js",
			"/assets/truck-B6l8uPdA.js",
			"/assets/content-Duhq1A_9.js",
			"/assets/typography-CdhRjSv6.js",
			"/assets/product-rail-CuKqD_p5.js",
			"/assets/faq-accordion-BnvZHYxI.js"
		]
	},
	"/iletisim": {
		filePath: "C:/Users/Melike/Desktop/Yeni Websiteler/luzayn.com/src/routes/iletisim.tsx",
		children: void 0,
		preloads: [
			"/assets/iletisim-DXGPMQqg.js",
			"/assets/schemas-BbZEywog.js",
			"/assets/typography-CdhRjSv6.js",
			"/assets/page-hero-DR6QPir8.js",
			"/assets/faq-accordion-BnvZHYxI.js"
		]
	},
	"/kurumsal": {
		filePath: "C:/Users/Melike/Desktop/Yeni Websiteler/luzayn.com/src/routes/kurumsal.tsx",
		children: void 0,
		preloads: [
			"/assets/kurumsal-mv0NMsgD.js",
			"/assets/arrow-right-Bc9MCm_o.js",
			"/assets/add-to-cart-B1DBEzg7.js",
			"/assets/chevron-right-DsFv12Lf.js",
			"/assets/typography-CdhRjSv6.js",
			"/assets/page-hero-DR6QPir8.js"
		]
	},
	"/sepet": {
		filePath: "C:/Users/Melike/Desktop/Yeni Websiteler/luzayn.com/src/routes/sepet.tsx",
		children: void 0,
		preloads: [
			"/assets/sepet-D8RPfEj0.js",
			"/assets/schemas-BbZEywog.js",
			"/assets/arrow-right-Bc9MCm_o.js",
			"/assets/use-shopify-checkout-1odcw3nO.js",
			"/assets/plus-fzHvwUX4.js",
			"/assets/truck-B6l8uPdA.js",
			"/assets/typography-CdhRjSv6.js"
		]
	},
	"/blog/$slug": {
		filePath: "C:/Users/Melike/Desktop/Yeni Websiteler/luzayn.com/src/routes/blog/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-CcIPH64I.js",
			"/assets/_slug-CgbJLYiQ.js",
			"/assets/content-Duhq1A_9.js",
			"/assets/typography-CdhRjSv6.js"
		]
	},
	"/urunler/$slug": {
		filePath: "C:/Users/Melike/Desktop/Yeni Websiteler/luzayn.com/src/routes/urunler/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-6F-zJ2az.js",
			"/assets/schemas-BbZEywog.js",
			"/assets/arrow-right-Bc9MCm_o.js",
			"/assets/add-to-cart-B1DBEzg7.js",
			"/assets/use-shopify-checkout-1odcw3nO.js",
			"/assets/plus-fzHvwUX4.js",
			"/assets/use-is-mobile-D65dDEU8.js",
			"/assets/truck-B6l8uPdA.js",
			"/assets/typography-CdhRjSv6.js",
			"/assets/_slug-ZFiglAVj.js"
		]
	},
	"/yasal/$slug": {
		filePath: "C:/Users/Melike/Desktop/Yeni Websiteler/luzayn.com/src/routes/yasal/$slug.tsx",
		children: void 0,
		preloads: ["/assets/_slug-BHU6FHVj.js", "/assets/_slug-BwJrHSp6.js"]
	},
	"/blog/": {
		filePath: "C:/Users/Melike/Desktop/Yeni Websiteler/luzayn.com/src/routes/blog/index.tsx",
		children: void 0,
		preloads: [
			"/assets/blog-B5E99nBY.js",
			"/assets/content-Duhq1A_9.js",
			"/assets/product-rail-CuKqD_p5.js"
		]
	},
	"/urunler/": {
		filePath: "C:/Users/Melike/Desktop/Yeni Websiteler/luzayn.com/src/routes/urunler/index.tsx",
		children: void 0,
		preloads: [
			"/assets/urunler-BMyWDgHT.js",
			"/assets/arrow-right-Bc9MCm_o.js",
			"/assets/add-to-cart-B1DBEzg7.js",
			"/assets/typography-CdhRjSv6.js",
			"/assets/page-hero-DR6QPir8.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
