globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as NodeResponse, i as defineLazyEventHandler, l as serve, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/apple-touch-icon.png": {
		"type": "image/png",
		"etag": "\"e58-wdzp0kaDBoSQtxGXhyisTeVHj5I\"",
		"mtime": "2026-08-18T13:45:40.883Z",
		"size": 3672,
		"path": "../public/apple-touch-icon.png"
	},
	"/favicon-32.png": {
		"type": "image/png",
		"etag": "\"2d5-GKOEevrqywW7kCYimqXojugzLM4\"",
		"mtime": "2026-08-18T13:45:40.886Z",
		"size": 725,
		"path": "../public/favicon-32.png"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"8f5-O61bKUiOM7azXa4ojJwTO+QgW+g\"",
		"mtime": "2026-08-18T13:46:57.432Z",
		"size": 2293,
		"path": "../public/favicon.ico"
	},
	"/icon-512.png": {
		"type": "image/png",
		"etag": "\"2f77-4VopdOfJntyxc9D9RqE74yyVaKo\"",
		"mtime": "2026-08-18T13:45:40.862Z",
		"size": 12151,
		"path": "../public/icon-512.png"
	},
	"/assets/add-to-cart-ciFZ01n7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"73a-8LxNE/bPBvFGGaDRw4Ry4FqmuwY\"",
		"mtime": "2026-08-19T08:15:32.065Z",
		"size": 1850,
		"path": "../public/assets/add-to-cart-ciFZ01n7.js"
	},
	"/assets/arrow-right-DH6JlM8M.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-ayqdvmlNwOVgZpo4SXc+tM5DniA\"",
		"mtime": "2026-08-19T08:15:32.066Z",
		"size": 165,
		"path": "../public/assets/arrow-right-DH6JlM8M.js"
	},
	"/assets/blog-DGicmUUt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8a2-tUJPIdC2nDIXNF0jMSjTvR2FHgk\"",
		"mtime": "2026-08-19T08:15:32.066Z",
		"size": 2210,
		"path": "../public/assets/blog-DGicmUUt.js"
	},
	"/assets/chevron-right-Tm9wcNPg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cf-Sw7GTsxPXQlkMHWBQYhlr3HXbhY\"",
		"mtime": "2026-08-19T08:15:32.067Z",
		"size": 207,
		"path": "../public/assets/chevron-right-Tm9wcNPg.js"
	},
	"/assets/content-Duhq1A_9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"85-tVaYdj8OvebwTQzaJzL0K8C1WJA\"",
		"mtime": "2026-08-19T08:15:32.067Z",
		"size": 133,
		"path": "../public/assets/content-Duhq1A_9.js"
	},
	"/assets/createLucideIcon-BaKsvvZZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"562-JCppxAOwnMaJq/CQb+8Yf0VDB80\"",
		"mtime": "2026-08-19T08:15:32.067Z",
		"size": 1378,
		"path": "../public/assets/createLucideIcon-BaKsvvZZ.js"
	},
	"/assets/faq-accordion-XoSR6wFN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"492-izWd06Bsl93Ts8vbqs7kayBAkZI\"",
		"mtime": "2026-08-19T08:15:32.068Z",
		"size": 1170,
		"path": "../public/assets/faq-accordion-XoSR6wFN.js"
	},
	"/assets/iletisim-JWKCREf_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f4d-DCJGfEGxB8M1+yoLOucR1D32ccE\"",
		"mtime": "2026-08-19T08:15:32.068Z",
		"size": 8013,
		"path": "../public/assets/iletisim-JWKCREf_.js"
	},
	"/assets/kurumsal-CnjlwoL-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29e0-3l/2yMdZubSrFzcQf+sKdclo0GM\"",
		"mtime": "2026-08-19T08:15:32.069Z",
		"size": 10720,
		"path": "../public/assets/kurumsal-CnjlwoL-.js"
	},
	"/assets/link-DvOsKxs3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7457-rzxmRk8+au8ashXoEcZRfjE+nK4\"",
		"mtime": "2026-08-19T08:15:32.070Z",
		"size": 29783,
		"path": "../public/assets/link-DvOsKxs3.js"
	},
	"/assets/not-found-i5RsCZif.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"76-Trmr7GZIBZuvfg4uM18tBiRtOXg\"",
		"mtime": "2026-08-19T08:15:32.070Z",
		"size": 118,
		"path": "../public/assets/not-found-i5RsCZif.js"
	},
	"/assets/page-hero-C0mObTJK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"579-/VyJRJJxeopm984upvlZd31/8BE\"",
		"mtime": "2026-08-19T08:15:32.071Z",
		"size": 1401,
		"path": "../public/assets/page-hero-C0mObTJK.js"
	},
	"/assets/plus-C01Y5LV7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"99-JGbJzdisrX3S2iafMPkNToEg2vY\"",
		"mtime": "2026-08-19T08:15:32.071Z",
		"size": 153,
		"path": "../public/assets/plus-C01Y5LV7.js"
	},
	"/assets/product-rail-DpzKDBGM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e3e-S44bqHAf4gPxyPu33QXj1IjFi5Q\"",
		"mtime": "2026-08-19T08:15:32.072Z",
		"size": 3646,
		"path": "../public/assets/product-rail-DpzKDBGM.js"
	},
	"/assets/routes-VaAddj9Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"75ef-gyqNotx9LErI6y5dEQZHq52MY/k\"",
		"mtime": "2026-08-19T08:15:32.072Z",
		"size": 30191,
		"path": "../public/assets/routes-VaAddj9Q.js"
	},
	"/assets/schemas-AF7ZMwIj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10cb1-YSOXA9yRZEV5XU8ILp93Da1uuaY\"",
		"mtime": "2026-08-19T08:15:32.073Z",
		"size": 68785,
		"path": "../public/assets/schemas-AF7ZMwIj.js"
	},
	"/assets/sepet-CeXZb--x.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ea0-05W3bW9df2A1PWwuIpJrk3hlNGI\"",
		"mtime": "2026-08-19T08:15:32.073Z",
		"size": 7840,
		"path": "../public/assets/sepet-CeXZb--x.js"
	},
	"/assets/styles-6q2C97y3.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"eae8-bvL+dOLTyHpNwzw0CDyDob0XHns\"",
		"mtime": "2026-08-19T08:15:32.075Z",
		"size": 60136,
		"path": "../public/assets/styles-6q2C97y3.css"
	},
	"/assets/truck-BVPTt2DD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"196-q7WNQyOq6GGxkPLLFad1hPhFfVQ\"",
		"mtime": "2026-08-19T08:15:32.073Z",
		"size": 406,
		"path": "../public/assets/truck-BVPTt2DD.js"
	},
	"/assets/typography-BqQga8L2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"57e-4L/LHyOXzM317OvsN/cC/KdDL8A\"",
		"mtime": "2026-08-19T08:15:32.074Z",
		"size": 1406,
		"path": "../public/assets/typography-BqQga8L2.js"
	},
	"/assets/index-BMyT35Vj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"891fc-ZQish+xR2R1sc1oW/Uz2bD/g5hM\"",
		"mtime": "2026-08-19T08:15:32.062Z",
		"size": 561660,
		"path": "../public/assets/index-BMyT35Vj.js"
	},
	"/assets/urunler-7MxGXZ9w.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c7c-gYiEEWWAbo8taPkH/5Udyx/MaKg\"",
		"mtime": "2026-08-19T08:15:32.074Z",
		"size": 3196,
		"path": "../public/assets/urunler-7MxGXZ9w.js"
	},
	"/assets/use-is-mobile-C7qHbRCu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"26a-SxpFCOikwTIqPThMzblS7IzeS+A\"",
		"mtime": "2026-08-19T08:15:32.074Z",
		"size": 618,
		"path": "../public/assets/use-is-mobile-C7qHbRCu.js"
	},
	"/assets/use-shopify-checkout-CyKVemrC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3f1-+plx+jbbV2qp1LQka1l3tnV41QU\"",
		"mtime": "2026-08-19T08:15:32.075Z",
		"size": 1009,
		"path": "../public/assets/use-shopify-checkout-CyKVemrC.js"
	},
	"/assets/_slug-9dfW9LoN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b32-yIXDnRxsmosWBcQO/qmUXTYMpW0\"",
		"mtime": "2026-08-19T08:15:32.063Z",
		"size": 2866,
		"path": "../public/assets/_slug-9dfW9LoN.js"
	},
	"/assets/_slug-Bt74vFGn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4f-6CMhyMig0QP533RapU9JBqKwgxw\"",
		"mtime": "2026-08-19T08:15:32.063Z",
		"size": 79,
		"path": "../public/assets/_slug-Bt74vFGn.js"
	},
	"/assets/_slug-C7cN6W0a.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4f-6CMhyMig0QP533RapU9JBqKwgxw\"",
		"mtime": "2026-08-19T08:15:32.064Z",
		"size": 79,
		"path": "../public/assets/_slug-C7cN6W0a.js"
	},
	"/assets/_slug-ChDt-s_J.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4f-6CMhyMig0QP533RapU9JBqKwgxw\"",
		"mtime": "2026-08-19T08:15:32.064Z",
		"size": 79,
		"path": "../public/assets/_slug-ChDt-s_J.js"
	},
	"/assets/_slug-FOEGvmc0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3d0b-ZdDYw5m8CBpgwLqeVLlzrACxkuI\"",
		"mtime": "2026-08-19T08:15:32.064Z",
		"size": 15627,
		"path": "../public/assets/_slug-FOEGvmc0.js"
	},
	"/assets/_slug-GiP01lxJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6fc-kXQmmjFF8EuXO/xHlytfTKEN5xQ\"",
		"mtime": "2026-08-19T08:15:32.065Z",
		"size": 1788,
		"path": "../public/assets/_slug-GiP01lxJ.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_7AWi7O = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_7AWi7O
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
