globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as NodeResponse, i as defineLazyEventHandler, l as serve, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/apple-touch-icon.png": {
		"type": "image/png",
		"etag": "\"c8e-wvY2Z1Ij1XnCWq5H+ELLa+1cDSA\"",
		"mtime": "2026-08-28T07:13:29.092Z",
		"size": 3214,
		"path": "../public/apple-touch-icon.png"
	},
	"/favicon-32.png": {
		"type": "image/png",
		"etag": "\"216-cllSf8udy2O9cl+5W+OyY4uHCUg\"",
		"mtime": "2026-08-28T07:13:29.048Z",
		"size": 534,
		"path": "../public/favicon-32.png"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"676-IErQCpktd2jxted2Cr392IvG3Mk\"",
		"mtime": "2026-08-28T07:13:29.047Z",
		"size": 1654,
		"path": "../public/favicon.ico"
	},
	"/icon-512.png": {
		"type": "image/png",
		"etag": "\"28ba-qChTxLK3hXFl6dL1vRs/JeshTes\"",
		"mtime": "2026-08-28T07:13:29.690Z",
		"size": 10426,
		"path": "../public/icon-512.png"
	},
	"/assets/add-to-cart-B1DBEzg7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"756-Ch0naNzjSIU7mCHTqTCB855sVx8\"",
		"mtime": "2026-08-28T07:19:27.075Z",
		"size": 1878,
		"path": "../public/assets/add-to-cart-B1DBEzg7.js"
	},
	"/assets/arrow-right-Bc9MCm_o.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-R0oeOLpG/yLrNRrQGW6fKjR/Pso\"",
		"mtime": "2026-08-28T07:19:27.075Z",
		"size": 165,
		"path": "../public/assets/arrow-right-Bc9MCm_o.js"
	},
	"/assets/blog-B5E99nBY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8ab-1jUeZzvCu2BqxRZGYN6dUY+4diw\"",
		"mtime": "2026-08-28T07:19:27.075Z",
		"size": 2219,
		"path": "../public/assets/blog-B5E99nBY.js"
	},
	"/assets/chevron-right-DsFv12Lf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cf-OhHuiN1I70cKUW4aGMWX218yJn4\"",
		"mtime": "2026-08-28T07:19:27.075Z",
		"size": 207,
		"path": "../public/assets/chevron-right-DsFv12Lf.js"
	},
	"/assets/content-Duhq1A_9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"85-tVaYdj8OvebwTQzaJzL0K8C1WJA\"",
		"mtime": "2026-08-28T07:19:27.076Z",
		"size": 133,
		"path": "../public/assets/content-Duhq1A_9.js"
	},
	"/assets/createLucideIcon-DacUZuz0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"566-LN9xiq33U75GDdR4tyzU4NkJSko\"",
		"mtime": "2026-08-28T07:19:27.076Z",
		"size": 1382,
		"path": "../public/assets/createLucideIcon-DacUZuz0.js"
	},
	"/assets/faq-accordion-BnvZHYxI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"496-AniuajX6ZWA4jDgqmq32WIaDMUY\"",
		"mtime": "2026-08-28T07:19:27.076Z",
		"size": 1174,
		"path": "../public/assets/faq-accordion-BnvZHYxI.js"
	},
	"/assets/iletisim-DXGPMQqg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f51-cR8TLPJJZvkYlc+XSETNI7DfOdk\"",
		"mtime": "2026-08-28T07:19:27.076Z",
		"size": 8017,
		"path": "../public/assets/iletisim-DXGPMQqg.js"
	},
	"/assets/kurumsal-mv0NMsgD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2998-1z75nYQ5d7S45c09SiFUaRB34OU\"",
		"mtime": "2026-08-28T07:19:27.077Z",
		"size": 10648,
		"path": "../public/assets/kurumsal-mv0NMsgD.js"
	},
	"/assets/not-found-i5RsCZif.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"76-Trmr7GZIBZuvfg4uM18tBiRtOXg\"",
		"mtime": "2026-08-28T07:19:27.077Z",
		"size": 118,
		"path": "../public/assets/not-found-i5RsCZif.js"
	},
	"/assets/page-hero-DR6QPir8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5d9-S04nTIKtAdDcEUBF1RdARx33FMM\"",
		"mtime": "2026-08-28T07:19:27.078Z",
		"size": 1497,
		"path": "../public/assets/page-hero-DR6QPir8.js"
	},
	"/assets/index-anEYRrAJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"565ba-yjkEdguQ/waBcRk9/rWoEHh54eM\"",
		"mtime": "2026-08-28T07:19:27.073Z",
		"size": 353722,
		"path": "../public/assets/index-anEYRrAJ.js"
	},
	"/assets/plus-fzHvwUX4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"99-+3fJw4zcqCvC3teHUfFpNc0P6iw\"",
		"mtime": "2026-08-28T07:19:27.078Z",
		"size": 153,
		"path": "../public/assets/plus-fzHvwUX4.js"
	},
	"/assets/product-rail-CuKqD_p5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e34-Zn3c18apH53AJ1dLWVebTtuaHnw\"",
		"mtime": "2026-08-28T07:19:27.078Z",
		"size": 3636,
		"path": "../public/assets/product-rail-CuKqD_p5.js"
	},
	"/assets/routes-DuKXZoQq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7639-a7USR/rSYkAoNXN/rZ8ukRUejQc\"",
		"mtime": "2026-08-28T07:19:27.079Z",
		"size": 30265,
		"path": "../public/assets/routes-DuKXZoQq.js"
	},
	"/assets/schemas-BbZEywog.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10cb1-/f4JQ0TCMMj1y/K5tzhE+JvDZOk\"",
		"mtime": "2026-08-28T07:19:27.079Z",
		"size": 68785,
		"path": "../public/assets/schemas-BbZEywog.js"
	},
	"/assets/sepet-D8RPfEj0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1eb2-/lY5UUh0AEzPrfAx7SjsXGJ2exU\"",
		"mtime": "2026-08-28T07:19:27.079Z",
		"size": 7858,
		"path": "../public/assets/sepet-D8RPfEj0.js"
	},
	"/assets/styles-CSusYjYM.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"eca1-ov8PsILd8LymF5geVYhkq1pneZU\"",
		"mtime": "2026-08-28T07:19:27.081Z",
		"size": 60577,
		"path": "../public/assets/styles-CSusYjYM.css"
	},
	"/assets/truck-B6l8uPdA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"196-Pfry35GntK2gq0ZvYD83A9iV9Z4\"",
		"mtime": "2026-08-28T07:19:27.080Z",
		"size": 406,
		"path": "../public/assets/truck-B6l8uPdA.js"
	},
	"/assets/typography-CdhRjSv6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"582-8f6pWtY/skBVkpAWZARmUffDRwc\"",
		"mtime": "2026-08-28T07:19:27.080Z",
		"size": 1410,
		"path": "../public/assets/typography-CdhRjSv6.js"
	},
	"/assets/supabase-DDk1pF9s.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3a4b2-Na7Z4EV8btgrT+/tHRtfaQdnZ1w\"",
		"mtime": "2026-08-28T07:19:27.080Z",
		"size": 238770,
		"path": "../public/assets/supabase-DDk1pF9s.js"
	},
	"/assets/urunler-BMyWDgHT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c69-aW7Js3ck5XilteCs4deo3SQrAN4\"",
		"mtime": "2026-08-28T07:19:27.081Z",
		"size": 3177,
		"path": "../public/assets/urunler-BMyWDgHT.js"
	},
	"/assets/use-is-mobile-D65dDEU8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"26e-M2eMIgG4LwSGnjWqPOn4DAKkTzE\"",
		"mtime": "2026-08-28T07:19:27.081Z",
		"size": 622,
		"path": "../public/assets/use-is-mobile-D65dDEU8.js"
	},
	"/assets/use-shopify-checkout-1odcw3nO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3f5-QbvNjgdBKYOoYFLcfP4SddMskyQ\"",
		"mtime": "2026-08-28T07:19:27.081Z",
		"size": 1013,
		"path": "../public/assets/use-shopify-checkout-1odcw3nO.js"
	},
	"/assets/_slug-6F-zJ2az.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3cfd-CkJ+7PIm0wzy4qpvaCYg5v8vPXQ\"",
		"mtime": "2026-08-28T07:19:27.074Z",
		"size": 15613,
		"path": "../public/assets/_slug-6F-zJ2az.js"
	},
	"/assets/_slug-BHU6FHVj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4f-7446SqABMyTXcnL5e2YyNGw+kWs\"",
		"mtime": "2026-08-28T07:19:27.074Z",
		"size": 79,
		"path": "../public/assets/_slug-BHU6FHVj.js"
	},
	"/assets/_slug-BwJrHSp6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"705-hkxVqO4MTZEVufoi9zvTHvQF7Zw\"",
		"mtime": "2026-08-28T07:19:27.074Z",
		"size": 1797,
		"path": "../public/assets/_slug-BwJrHSp6.js"
	},
	"/assets/_slug-CcIPH64I.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4f-7446SqABMyTXcnL5e2YyNGw+kWs\"",
		"mtime": "2026-08-28T07:19:27.074Z",
		"size": 79,
		"path": "../public/assets/_slug-CcIPH64I.js"
	},
	"/assets/_slug-CgbJLYiQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b3b-cagelILPOTMaeA8+ml0IgSLKwsQ\"",
		"mtime": "2026-08-28T07:19:27.074Z",
		"size": 2875,
		"path": "../public/assets/_slug-CgbJLYiQ.js"
	},
	"/assets/_slug-ZFiglAVj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4f-7446SqABMyTXcnL5e2YyNGw+kWs\"",
		"mtime": "2026-08-28T07:19:27.074Z",
		"size": 79,
		"path": "../public/assets/_slug-ZFiglAVj.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_7AWi7O = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_7AWi7O
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
